<?php
include_once 'connection.php';
$conn;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{
 
    $id=$_POST["con_id"];
 //echo "id:".$_POST["con_id"];
    $sql = "UPDATE consultation SET con_subject='".$_POST["cons_subject"]."', amount_contract='".$_POST["cons_amount"]."', tax='".$_POST["cons_tax"]."', total_amount='".$_POST["cons_total"]."', start_date='".$_POST["cons_start"]."', end_date='".$_POST["cons_end"]."', con_detail_ar='".$_POST["cus_detail_ar"]."', con_detail_en='".$_POST["cus_detail_en"]."' WHERE con_id=".$id;
  //echo $sql;
if ($conn->query($sql) === TRUE) {
        header('Location: consultation.php');
  
} else {
    echo "Error updating record: " . $conn->error;
}

}

$conn->close();
?>


 