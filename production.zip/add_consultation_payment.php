<?php 
include_once 'header_file.php';

include_once 'connection.php';
$conn;
$id = $_GET['id'];
$conn = new mysqli($servername, $username, $password, $dbname);
$total_amount=0;
$paid=0;
$due=0;
$c_id=0;
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT c.c_id, con.cled_id, con.cled_paid, con.cled_du, c.total_amount from consultation_ledger con INNER JOIN consultation c ON con.con_id=c.con_id where con.con_id=".$id;
       
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $c_id=$row["c_id"];
        $total_amount=$row["total_amount"];
        $paid=$paid+$row["cled_paid"];
      }
} else {
    echo "0 results";
}
            $due=$total_amount-$paid;
            ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  
    <title>Add Payment</title>

    <!-- Bootstrap -->
<?php
    if($_SESSION["lang_option"]=="en"){
        
           ?>
              <link rel="stylesheet" href="navcode1.css">
             <?php
    }
    else{
        
          ?>
              <link rel="stylesheet" href="navcode2.css">
             <?php
    }
    ?>
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

 
        <?php include 'nav.php';  ?>

        <!-- page content -->
                 
<?php if(isset($_POST['change_submit'])) {
      $_SESSION["lang_option"]=$_POST["langoption"];}

              if($_SESSION["lang_option"]=="en"){
                  ?>

                  
                  <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
 
            <div class="clearfix"></div>
             
            <form action="" method="post">
            <div class="col-md-12 ">
<a href="consultation_profile.php?id=<?php echo $id; ?>" class="btn btn-dark btn-sm">Consultation Profile</a>
			 
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Add New Payment </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div dir="ltr" class="x_content">
                    <br />
                    

                      
                      
                      <div class="col-md-4 col-sm-6  form-group">
                          <label><b>Total Amount:</b> <?php echo $total_amount; ?></label>
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                          <label><b>Paid Amount:</b> <?php echo $paid; ?></label>
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                          <label><b>Receivable (To be Paid By Customer) Amount: </b><?php echo $due; ?></label>
                      </div>
                      
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>Pay Amount</label>
                    <input required  type="text" name="pay_paid" class="form-control" id="total" placeholder="<?php echo $row["total_amount"]; ?>">
                      </div>
                     
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>That About</label>
                    <input required  required type="text" name="pay_about" class="form-control" id="total" placeholder="">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                             <label>Payment Method</label>
                    <input required  type="text" name="pay_method" class="form-control" id="total" placeholder="">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                             <label>Date</label>
                    <input required  type="date" name="pay_date"  class="form-control" id="total" >
                      </div>
                   <div class="form-group row">
                        <div class="col-md-6 col-sm-9  offset-md-4"><br>
                          <button style="width:30%" type="submit" name="submit" class="btn btn-success">Add Payment</button>
                        </div>
                      </div>

                     
                  </div>
                </div>
 
              


          
              
            </div>
            </form> 
           
        </div>   
                   <?php
              }
                else
                {
                ?>
            
                     <div dir="" style="width:100%" lang="ar" class="right_col" role="main">
 
            <div class="clearfix"></div>
             
           <form dir="ltr" style="font-size:20px;" action="" method="post">
            <div dir="ltr" class="col-md-12 ">

			 <a style="float:right;font-size:20px;padding-left:20px;padding-right:20px;" href="consultation_profile.php?id=<?php echo $id; ?>" class="btn btn-dark btn-sm">الاستشارات</a>
                <div class="x_panel">
                  <div class="x_title">
                  <h2  style="float:right;font-size:24px;">اضافة دفعة مالية جديدة </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div dir="rtl" class="x_content">
                    <br />
                    

                      
                      
                      <div style="float:right"   class="col-md-4 col-sm-6  form-group">
                          <label style="float:right"  ><b>المبلغ الإجمالي:</b> <?php echo $total_amount; ?></label>
                      </div>
                       <div style="float:right"  class="col-md-4 col-sm-6  form-group">
                          <label style="float:right"  ><b>المبلغ المدفوع:</b> <?php echo $paid; ?></label>
                      </div>
                        <div style="float:right"   class="col-md-4 col-sm-6  form-group">
                          <label style="float:right"  ><b>بقية المبلغ: </b><?php echo $due; ?></label>
                      </div>
                      
                      <div class="col-md-6 col-sm-6  form-group">
                           <label style="float:right" >المبلغ</label>
                    <input dir="rtl" required  type="text" name="pay_paid" class="form-control" id="total" placeholder="<?php echo $row["total_amount"]; ?>">
                      </div>
                     
                      <div class="col-md-6 col-sm-6  form-group">
                           <label style="float:right" >وذلك عن</label>
                    <input  dir="rtl" required  type="text" name="pay_about" class="form-control" id="total" placeholder="">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                             <label style="float:right" >طريقة الدفع</label>
                    <input dir="rtl" required  type="text" name="pay_method" class="form-control" id="total" placeholder="">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                             <label style="float:right" >تاريخ الدفع</label>
                    <input dir="rtl" required  type="date" name="pay_date"  class="form-control" id="total" >
                      </div>
                   <div  class="form-group row">
                        <div class="col-md-12 col-sm-9  offset-md-4"><br>
                          <button  style="width:30%" type="submit" name="submit" class="btn btn-success">إضافة</button>
                        </div>
                      </div>

                     
                  </div>
                </div>
 
              


          
              
            </div>
            </form> 
           
        </div>
                 <?php
                }
            
            ?>
                
                           
     
        <script>
         
        </script>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
     

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>
    <!-- jQuery Tags Input -->
    <script src="../vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
    <!-- Switchery -->
    <script src="../vendors/switchery/dist/switchery.min.js"></script>
    <!-- Select2 -->
    <script src="../vendors/select2/dist/js/select2.full.min.js"></script>
    <!-- Parsley -->
    <script src="../vendors/parsleyjs/dist/parsley.min.js"></script>
    <!-- Autosize -->
    <script src="../vendors/autosize/dist/autosize.min.js"></script>
    <!-- jQuery autocomplete -->
    <script src="../vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
    <!-- starrr -->
    <script src="../vendors/starrr/dist/starrr.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
      </div>
  </body>
</html>
<?php
include_once 'connection.php';
$conn;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{
 	




/*



 */
    $paid=$paid+$_POST["pay_paid"];
    $due=$total_amount-$paid;
   if ($paid>$total_amount){
       echo "<script>alert('Paid amount is greater then Total Amount');</script>";
   }
    else{
    $sql = "INSERT INTO consultation_ledger (con_id, cled_paid, cled_du, cled_method, cled_about,cled_date) VALUES ('".$id."', '".$_POST["pay_paid"]."', '".$due."', '".$_POST["pay_method"]."', '".$_POST["pay_about"]."', '".$_POST["pay_date"]."')";
 
if ($conn->query($sql) === TRUE) {
  echo "New Payment Added";
}else{
	echo "New Payment Not Added";
} 
        $sql = "UPDATE customer SET  paid=paid+".$_POST["pay_paid"].", due=due-".$_POST["pay_paid"]." WHERE c_id=".$c_id;
echo $sql;
if (mysqli_query($conn, $sql)) {
     
} else {
   
}

    }
   
}

$conn->close();
?>