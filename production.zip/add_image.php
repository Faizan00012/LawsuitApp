<?php
include_once 'header_file.php';
include_once 'connection.php';
$conn;
$id = $_GET['id'];
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  
    <title>Add Image and File</title>

    <!-- Bootstrap -->
    <?php
    if($_SESSION["lang_option"]=="en"){
        
           ?>
              <link rel="stylesheet" href="navcode1.css">
             <?php
    }
    else{
        
          ?>
              <link rel="stylesheet" href="navcode2.css">
             <?php
    }
    ?>
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

   
        <?php include 'nav.php';  ?>

                  
<?php if(isset($_POST['change_submit'])) {
      $_SESSION["lang_option"]=$_POST["langoption"];}

              if($_SESSION["lang_option"]=="en"){
                  ?>

          
                    <form action="" method="post" enctype="multipart/form-data">
              
        <div dir="" style="width:100%" lang="ar" class="right_col" role="main">
 
            <div class="clearfix"></div>
            
                
            <div class="col-md-12 ">
              <a href="lawsuit_profile.php?id=<?php echo $id; ?>" class="btn btn-dark btn-sm">Lawsuit Profile</a>
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Add Image and File </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div dir="ltr" class="x_content">
                    <br />
                    

                        
                      
                      <div class="col-md-12 col-sm-6  form-group">
                          <label>Image Name</label>
                    <input type="text" name="image_name" class="form-control" id="inputSuccess2" placeholder="">
                          <input type="hidden" name="l_id" value="<?php echo $id; ?>">
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                          <label>Upload Image</label>
                        <input type="file"  class="form-control" name="fileToUpload" id="fileToUpload">
                        
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                             <label>Created At</label>
                    <input type="date" name="created_at"  class="form-control">
                      </div>
                      
                      <div class="form-group row">
                        <div class="col-md-9 col-sm-9  offset-md-4"><br>
                          <button style="width:30%" type="submit" name="submit" class="btn btn-success">Add Image</button>
                        </div>
                      </div>

                     
                  </div>
                </div>
 
              


          
              
            </div>

              </div>      
           </form>
                   <?php
              }
                else
                {
                ?>
                   <form style="font-size:20px;"  action="" method="post" enctype="multipart/form-data">
              
        <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
 
            <div class="clearfix"></div>
            
                
            <div class="col-md-12 ">
    <a style="float:right;font-size:20px;padding-left:20px;padding-right:20px;" href="lawsuit_profile.php?id=<?php echo $id; ?>" class="btn btn-dark btn-sm">القضايا</a>
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="float:right;font-size:24px;" >اضافة ملف جديد </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div dir="rtl" class="x_content">
                    <br />
                    

                        
                      
                      <div class="col-md-12 col-sm-6  form-group">
                          <label style="float:right;">الاسم</label>
                    <input type="text" name="image_name" class="form-control" id="inputSuccess2" placeholder="">
                          <input type="hidden" name="l_id" value="<?php echo $id; ?>">
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                          <label  style="float:right;">رفع ملف</label>
                        <input type="file"  class="form-control" name="fileToUpload" id="fileToUpload">
                        
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                             <label  style="float:right;">تاريخ الإنشاء</label>
                    <input type="date" name="created_at"  class="form-control">
                      </div>
                      
                      <div class="form-group row">
                        <div class="col-md-9 col-sm-9  offset-md-4"><br>
                          <button  style="float:right;width:30%" type="submit" name="submit" class="btn btn-success">إغلاق</button>
                        </div>
                      </div>

                     
                  </div>
                </div>
 
              


          
              
            </div>

              </div>      
           </form>  
                
                 <?php
                }
            
            ?>
                
                
          

        </div>
         <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
     

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>
    <!-- jQuery Tags Input -->
    <script src="../vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
    <!-- Switchery -->
    <script src="../vendors/switchery/dist/switchery.min.js"></script>
    <!-- Select2 -->
    <script src="../vendors/select2/dist/js/select2.full.min.js"></script>
    <!-- Parsley -->
    <script src="../vendors/parsleyjs/dist/parsley.min.js"></script>
    <!-- Autosize -->
    <script src="../vendors/autosize/dist/autosize.min.js"></script>
    <!-- jQuery autocomplete -->
    <script src="../vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
    <!-- starrr -->
    <script src="../vendors/starrr/dist/starrr.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
	
  </body>
</html>
<?php
include_once 'connection.php';
$conn;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{
$img=basename($_FILES["fileToUpload"]["name"]);
$target_dir = "upload_image/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        
        $uploadOk = 1;
    } else {
       
        $uploadOk = 0;
    }

// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
 
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        
    } else {
       
    }
}   
    
    
    
 $sql = "INSERT INTO image_file (l_id, fila_name,img_loc, created_at) VALUES ('".$_POST["l_id"]."','".$_POST["image_name"]."','".$img."','".$_POST["created_at"]."')";
  
if ($conn->query($sql) === TRUE) {
  echo "New Image Added";
}else{
	echo "New Image Not Added";
} 

}

$conn->close();
?>