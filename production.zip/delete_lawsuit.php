<?php
 
$id = $_GET['id'];
$arr=explode("-",$id);

include_once 'connection.php';
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// sql to delete a record
$sql = "DELETE FROM lawsuit WHERE l_id = {$arr[0]}";

if ($conn->query($sql) === TRUE) {
    
} else {
     
}

   $sql = "UPDATE customer_type SET no_lawsuit=no_lawsuit-1 WHERE ct_id = {$arr[1]}";
echo $sql;
if (mysqli_query($conn, $sql)) {
     
} else {
   
}  
 $sql = "UPDATE lawsuit_type SET no_lawsuit=no_lawsuit-1 WHERE lt_id = {$arr[2]}";
echo $sql;
if (mysqli_query($conn, $sql)) {
     
} else {
   
}  
 $sql = "UPDATE state SET no_lawsuit=no_lawsuit-1 WHERE state_id = {$arr[3]}";
echo $sql;
if (mysqli_query($conn, $sql)) {
     
} else {
   
}  
 $sql = "UPDATE stage SET no_lawsuit=no_lawsuit-1 WHERE stage_id = {$arr[4]}";
echo $sql;
if (mysqli_query($conn, $sql)) {
     
} else {
   
}  
 
 
header("Location: lawsuit.php");

mysqli_close($conn);

?>
