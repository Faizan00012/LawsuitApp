<?php
ob_start();
session_start();
include_once 'connection.php';
$conn;
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Login Customer| Omar Al Shamsi</title>

    <!-- Bootstrap -->
     
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="../vendors/animate.css/animate.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="login">
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
            <form action="" method="post">
              <h1>Login Form</h1>
              <div class="form-group">
                  <label>Choose Language</label>
             	<select class="form-control" name="customer_lang">
                    <option value="en">English</option>
                    <option value="ar">Arabic</option>
                  </select>  
              </div>
                <div class="form-group">
                  <label>Username</label>
                <input type="text" name="username" class="form-control" placeholder="Username" required=""/>
				  
              </div>
                <label>Password</label>
              <div class="form-group">
                <input type="password" name="password"  class="form-control" placeholder="Password" required="" />
				
              </div>
              <div>
                <input style="margin-left: 120px;width: 120px;" type="submit" name="submit" value="Log in" class="btn btn-app" >
                 
              </div>

              <div class="clearfix"></div>

              <div class="separator">
              
                <div class="clearfix"></div>
                <br />

                <div>
                  <h1><i class="fa fa-laptop"></i>  Omar Al Shamsi</h1>
              
                </div>
              </div>
            </form>
			  
			  <?php
			    if(isset($_POST['submit'])){
			 
					
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT c_id, c_username, c_password, roll FROM customer";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
if ($row["c_username"]==$_POST["username"] && $row["c_password"]==$_POST["password"])
		{
		    
		     $_SESSION["customer_lang"] =$_POST["customer_lang"];
           $_SESSION["customer_username"] = $row["c_username"];
           $_SESSION["favcolor"] = "green";
            $_SESSION["favanimal"] = "cat";
          
      //     echo  "<script>alert('".$_SESSION["customer_lang"]."' );</script>"; 
          
         
           header('Location: customer_section.php?id='.$row["c_id"]);
         	
	 
		 	
		}
        
    }
} else {
    echo "0 results";
}

$conn->close();	   
			ob_end_flush();				   
				   	   
				   
				   
				   
			   }
			  
			  
			  ?>
          </section>
        </div>

      </div>
    </div>
  </body>
</html>


 
