<?php
session_start();
$customer_lang=$_SESSION['customer_lang'];

if(empty($_SESSION['customer_username']) || $_SESSION['customer_username'] == ''){
    header("Location: customer_login.php");
    // die();
}

if ($customer_lang=="en"){
    $langoption="en";
               
}
else{
    $langoption="ar";
   
}
header("Expires: Thu, 19 Nov 1981 08:52:00 GMT"); //Date in the past
header("Cache-Control: no-store, no-cache, must-revalidate"); //HTTP/1.1include_once ( 'con_file.php' );
 $user=$_SESSION['customer_username'];

$id = $_GET['id'];
$l_id="";
$branch="";
$c_name="";
$c_address="";
$c_email="";
$c_nationality="";
$con_amount=0;
$con_tax=0;
$con_total=0;
$lw_amount=0;
$lw_tax=0;
$lw_total=0;
$amount=0;
$tax=0;
$total=0;
include_once 'connection.php';
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "Select c_name, c_address, c_email, c_nationality FROM customer WHERE c_id=".$id;
 
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      
$c_name=$row["c_name"];        
$c_address=$row["c_address"];
$c_email=$row["c_email"];
$c_nationality=$row["c_nationality"];

    }
} 

$sql = "SELECT l_id, amount_contact, tax, total_amount FROM lawsuit WHERE c_id=".$id;
 
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $l_id=$row["l_id"];
 
$lw_amount=$lw_amount+(int)$row["amount_contact"];
$lw_tax=$lw_tax+(int)$row["tax"];        
$lw_total=$lw_total+(int)$row["total_amount"];
    }
} 

$sql = "SELECT amount_contract,tax,total_amount FROM consultation WHERE c_id=".$id;
 
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
         
 
$con_amount=$con_amount+(int)$row["amount_contract"];
$con_tax=$con_tax+(int)$row["tax"];        
$con_total=$con_total+(int)$row["total_amount"];
    }
} 
$amount=$lw_amount+$con_amount;
$tax=$lw_tax+$con_tax;
$total=$lw_total+$con_total;
?>

<!DOCTYPE html>
<html lang="en">

  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Customer Profile</title>

    <!-- Bootstrap -->
  <?php
    if($_SESSION["lang_option"]=="en"){
        
           ?>
              <link rel="stylesheet" href="navcode1.css">
             <?php
    }
    else{
        
          ?>
              <link rel="stylesheet" href="navcode2.css">
             <?php
    }
    ?>
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="../vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- PNotify -->
    <link href="../vendors/pnotify/dist/pnotify.css" rel="stylesheet">
    <link href="../vendors/pnotify/dist/pnotify.buttons.css" rel="stylesheet">
    <link href="../vendors/pnotify/dist/pnotify.nonblock.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>
<body style="background-color:white;">                      
<?php 
        if($langoption=="en"){
                  ?>

             <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
         

            <div class="clearfix"></div>

  <div class="col-md-12">
                <div class="">
                    <div style="background-color:#00504d;width:100%;height:50px;padding:10px;">
                    <label style="color:white;font-size:20px;">Username: <?php echo $_SESSION['customer_username']; ?></label>
                       <a  style="float:right"  href="customer_login.php" class="btn btn-primary btn-sm">Log Out</a>
                        </div>
                  <div dir="ltr" class="x_content">
                                  
                       
                    <div class="row">
                      <div class="animated flipInY col-lg-4 col-md-3 col-sm-6  ">
                        <div class="tile-stats">
                            
                          <div class="icon"><i style="color:#030345" class="fa fa-money"></i>
                          </div>
                          <div style="color:#030345"class="count"><?php echo $amount; ?></div>

                           
                          <p>Total Contract Amount</p>
                        </div>
                      </div>
                           <div class="animated flipInY col-lg-4 col-md-3 col-sm-6  ">
                        <div class="tile-stats">
                          <div class="icon"><i style="color:#030345" class="fa fa-certificate"></i>
                          </div>
                          <div style="color:#030345" class="count"><?php echo $tax; ?>%</div>

                           
                          <p>Tax Value</p>
                        </div>
                      </div>
                           <div class="animated flipInY col-lg-4 col-md-3 col-sm-6  ">
                        <div class="tile-stats">
                          <div class="icon"><i style="color:#030345" class="fa fa-money"></i>
                          </div>
                          <div style="color:#030345" class="count"><?php echo $total; ?></div>

                           
                          <p>Total Amount Including Tax</p>
                        </div>
                      </div>
                            
                    
                    </div>

              


 
                  
                  </div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6 ">
                  <div  class="x_panel" style="background-color:white;border:solid;border-color:white;">
                <div class="x_content" style="background-color:#00504d;padding:20px;width:100%;height:20%">
                    <h1 style="text-align:center;color:white"><i class="fa fa-user"></i></h1>
                    <h2 style="color:white"> <?php echo $c_name; ?> </h2>  </div>
                                               <p>
                                                   <br>
                                <b>.</b><br><br>
                                <b>Nationality: <br></b><?php echo $c_nationality; ?> <br>
                           
                                   </p>
                                                   <hr>
                      <h6><u>Client Information</u></h6>
                 <p>
                     <b>Name: </b><br><?php echo $c_name; ?><br>
                     <b>Customer ID:<br> </b><?php echo $id; ?><br>
                                <b>Customer Email:<br> </b><?php echo $c_email; ?><br>
                     <b>Customer Nationality:</b><br><?php echo $c_nationality; ?><br>
                     <b>Customer Address:</b><br><?php echo $c_address; ?><br></p>  

              </div>
              </div>        
              <div class="col-md-9 col-sm-6  ">
                <div class="x_panel">
                 
                    <div class="x_content">

                    <ul class="nav nav-tabs bar_tabs" id="myTab" role="tablist">
                      <li class="nav-item">
                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#session" role="tab" aria-controls="home" aria-selected="true">Consultation</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#payment" role="tab" aria-controls="profile" aria-selected="false">Lawsuit</a>
                      </li>
                     

                        </ul>
                    <div class="tab-content" id="myTabContent">
                      <div class="tab-pane fade show active" id="session" role="tabpanel" aria-labelledby="home-tab">
                         
                           <div class="col-md-12 col-sm-6  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="color:#030345">Consultation Details</h2>
              
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                             <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th style="width:10%">Consultation File Number</th>
                         <th>Branch</th>
                            <th>Customer</th>
                          
                          <th>Start Date</th>
                          <th>End Date</th>
                          <th>Total Amount Incl Tax</th>
                             <th style="width:25%">Action</th>
                          
                    
                        </tr>
                      </thead>


                      <tbody>
                              <?php
						   
						  
						  
							include_once 'connection.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						  
						  
$sql1="SELECT c.con_id, b.b_ar, cu.c_name, c.start_date, c.end_date, c.total_amount from consultation c INNER JOIN branch b ON c.b_id=b.b_id INNER Join customer cu ON c.c_id=cu.c_id where c.c_id=".$id;
$result = $conn->query($sql1);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
 // <th>Customer ID</th>
                         
  
	   	echo "<tr><td>" . $row["con_id"]. "</td>";
        echo "<td>" . $row["b_ar"]. "</td>";
	   echo "<td>" . $row["c_name"]. "</td>";
          echo "<td>" . $row["start_date"]. "</td>";
	  echo "<td>" . $row["end_date"]. "</td>";
	 
        echo "<td>" . $row["total_amount"]. "</td>";
             

	   
     echo "<td>
   
     <a  type='button' href='customer_print.php?id=".$row["con_id"]."' class='btn btn-success btn-sm'><i class='fa fa-print'></i></a>
      
     
     </td>";
        
		
		
		 
		 
		
		 

		  }
} else {
   
}
						  $conn->close();
   
						?>
                        
                           
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
                      </div>
                      <div class="tab-pane fade" id="payment" role="tabpanel" aria-labelledby="profile-tab">
                        
                           <div class="col-md-12 col-sm-6  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="color:#030345">Lawsuits</h2>
              
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                   <table id="table" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th style="width:10%">Lawsuit File Number</th>
                    
                            <th>Customer</th>
                        
                             <th>Lawsuit Type</th>
                              <th>Stage</th>
                            <th>State</th>
                            <th>Location</th>
                          <th>Total Amount Incl Tax</th>
                             <th style="width:25%">Action</th>
                          
                    
                        </tr>
                      </thead>


                      <tbody>
                              <?php
						   
						  
						  
							include_once 'connection.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						  
						  
$sql1="SELECT l.l_id, b.b_en, c.c_name, ct.ct_en,lt.lt_en,stg.stage_en,sta.state_en, l.location, l.total_amount from lawsuit l INNER JOIN branch b ON l.b_id=b.b_id INNER Join customer c ON l.c_id=c.c_id INNER Join customer_type ct ON l.ct_id=ct.ct_id INNER Join lawsuit_type lt ON l.lt_id=lt.lt_id INNER Join stage stg ON l.stage_id=stg.stage_id INNER Join state sta ON l.state_id=sta.state_id where c.c_id=".$id;
$result = $conn->query($sql1);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
 // <th>Customer ID</th>
                         
  
	   	echo "<tr><td>" . $row["l_id"]. "</td>";
       
	   echo "<td>" . $row["c_name"]. "</td>";
          
	  echo "<td>" . $row["lt_en"]. "</td>";
	 
        echo "<td>" . $row["stage_en"]. "</td>";
	 
        echo "<td>" . $row["state_en"]. "</td>";
	 
        echo "<td>" . $row["location"]. "</td>";
         echo "<td>" . $row["total_amount"]. "</td>";
             

		 
	 //  echo  "<td class='last'><a style='color:green;' href='Payable_Backend.php?id=".$row["c_id"]."'>Select</a></td>";
	   
     echo "<td>
   
      <a  type='button' href='lawsuit_print.php?id=".$row["l_id"]."' class='btn btn-success btn-sm'><i class='fa fa-print'></i></a>
     
     </td>";
        
		
		
		 
		 
		
		 

		  }
} else {
   
}
						  $conn->close();
   
						?>
                        
                           
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
                      </div>
                     
                     
                    </div>
                  </div>
                </div>
              </div>


            <div class="clearfix"></div>
         
        </div>   
                   <?php
              }
                else
                {
                ?>
            <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main"> 
 
          

            <div class="clearfix"></div>
            
  <div class="col-md-12">
                <div class="">
                      <div style="background-color:#00504d;width:100%;height:50px;padding:10px;">
                    <label style="color:white;font-size:20px;">االمستخدم: <?php echo $_SESSION['customer_username']; ?></label>
                       <a  style="float:right"  href="customer_login.php" class="btn btn-primary btn-sm">تسجيل خروج</a>
                        </div>
                  <div class="x_content">
                    <div class="row">
                      <div class="animated flipInY col-lg-4 col-md-3 col-sm-6  ">
                        <div class="tile-stats">
                          <div class="icon"><i style="color:#030345" class="fa fa-money"></i>
                          </div>
                          <div style="color:#030345"class="count"><?php echo $amount; ?></div>

                           
                          <p>مبلغ</p>
                        </div>
                      </div>
                           <div class="animated flipInY col-lg-4 col-md-3 col-sm-6  ">
                        <div class="tile-stats">
                          <div class="icon"><i style="color:#030345" class="fa fa-certificate"></i>
                          </div>
                          <div style="color:#030345" class="count"><?php echo $tax; ?>%</div>

                           
                          <p>مبلغ الضريبة</p>
                        </div>
                      </div>
                           <div class="animated flipInY col-lg-4 col-md-3 col-sm-6  ">
                        <div class="tile-stats">
                          <div class="icon"><i style="color:#030345" class="fa fa-money"></i>
                          </div>
                          <div style="color:#030345" class="count"><?php echo $total; ?></div>

                           
                          <p>المبلغ الاجمالي شامل الضريبة</p>
                        </div>
                      </div>
                            
                    
                    </div>

              


 
                  
                  </div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6 ">
                  <div  class="x_panel" style="background-color:white;border:solid;border-color:white;">
                <div class="x_content" style="background-color:#00504d;padding:20px;width:100%;height:20%">
                    <h1 style="text-align:center;color:white"><i class="fa fa-user"></i></h1>
                    <h2 style="color:white"> <?php echo $c_name; ?> </h2>  </div>
                                               <p>
                                                   <br>
                                <b>.</b><br><br>
                                <b>جنسية العميل: <br></b><?php echo $c_nationality; ?> <br>
                           
                                   </p>
                                                   <hr>
                      <h6><u>بيانات العميل</u></h6>
                 <p>
                     <b>عميل : </b><br><?php echo $c_name; ?><br>
                     <b>معرف العميل:<br> </b><?php echo $id; ?><br>
                                <b>الإيميل:<br> </b><?php echo $c_email; ?><br>
                     <b>الجنسية :</b><br><?php echo $c_nationality; ?><br>
                     <b>العنوان     :</b><br><?php echo $c_address; ?><br></p>  

              </div>
              </div>        
              <div class="col-md-9 col-sm-6  ">
                <div class="x_panel">
                 
                    <div class="x_content">

                    <ul class="nav nav-tabs bar_tabs" id="myTab" role="tablist">
                      <li class="nav-item">
                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#session" role="tab" aria-controls="home" aria-selected="true">الاستشارات</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#payment" role="tab" aria-controls="profile" aria-selected="false">دعوى قضائية</a>
                      </li>
                     

                        </ul>
                    <div class="tab-content" id="myTabContent">
                      <div class="tab-pane fade show active" id="session" role="tabpanel" aria-labelledby="home-tab">
                         
                           <div class="col-md-12 col-sm-6  ">
                <div class="x_panel">
                  <div class="x_title">
                 <h2 style="float:right;font-size:24px;" >الاستشارات</h2>
              
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                             <table dir="rtl" id="datatable" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                        <th style="width:10%">رقم ملف الإستشارة</th>
                         <th>فرع</th>
                            <th>عميل</th>
                          
                          <th>تاريخ بداية</th>
                          <th>تاريخ الانتهاء</th>
                          <th>المبلغ الاجمالي شامل الضريبة</th>
                             <th style="width:25%">عمل</th>
                          
                    
                        </tr>
                      </thead>


                      <tbody>
                              <?php
						   
						  
						  
							include_once 'connection.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						  
						  
$sql1="SELECT c.con_id, b.b_ar, cu.c_name, c.start_date, c.end_date, c.total_amount from consultation c INNER JOIN branch b ON c.b_id=b.b_id INNER Join customer cu ON c.c_id=cu.c_id where c.c_id=".$id;
$result = $conn->query($sql1);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
 // <th>Customer ID</th>
                         
  
	   	echo "<tr><td>" . $row["con_id"]. "</td>";
        echo "<td>" . $row["b_ar"]. "</td>";
	   echo "<td>" . $row["c_name"]. "</td>";
          echo "<td>" . $row["start_date"]. "</td>";
	  echo "<td>" . $row["end_date"]. "</td>";
	 
        echo "<td>" . $row["total_amount"]. "</td>";
             

	   
     echo "<td>
   
     <a  type='button' href='customer_print.php?id=".$row["con_id"]."' class='btn btn-success btn-sm'><i class='fa fa-print'></i></a>
      
     
     </td>";
        
		
		
		 
		 
		
		 

		  }
} else {
   
}
						  $conn->close();
   
						?>
                        
                           
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
                      </div>
                      <div class="tab-pane fade" id="payment" role="tabpanel" aria-labelledby="profile-tab">
                       
                           <div class="col-md-12 col-sm-6  ">
                <div class="x_panel">
                  <div class="x_title">
                     <h2 style="float:right;font-size:24px;" >دعوى قضائية</h2>
                      
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                   <table dir="rtl" id="table" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                        <th style="width:10%">رقم ملف القضية</th>
                  
                            <th>عميل</th>
                    
                             <th>نوع القضية</th>
                              <th>مرحلة التقاضي</th>
                            <th>حالة القضية</th>
                            <th>مكان القضية</th>
                          <th style="width:15%">المبلغ الاجمالي شامل الضريبة</th>
                             <th style="width:25%">عمل</th>
                    
                        </tr>
                      </thead>


                      <tbody>
                              <?php
						   
						  
						  
							include_once 'connection.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						  
						  
$sql1="SELECT l.l_id, b.b_en, c.c_name, ct.ct_en,lt.lt_en,stg.stage_en,sta.state_en, l.location, l.total_amount from lawsuit l INNER JOIN branch b ON l.b_id=b.b_id INNER Join customer c ON l.c_id=c.c_id INNER Join customer_type ct ON l.ct_id=ct.ct_id INNER Join lawsuit_type lt ON l.lt_id=lt.lt_id INNER Join stage stg ON l.stage_id=stg.stage_id INNER Join state sta ON l.state_id=sta.state_id where c.c_id=".$id;
$result = $conn->query($sql1);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
 // <th>Customer ID</th>
                         
  
	   	echo "<tr><td>" . $row["l_id"]. "</td>";
       
	   echo "<td>" . $row["c_name"]. "</td>";
          
	  echo "<td>" . $row["lt_en"]. "</td>";
	 
        echo "<td>" . $row["stage_en"]. "</td>";
	 
        echo "<td>" . $row["state_en"]. "</td>";
	 
        echo "<td>" . $row["location"]. "</td>";
         echo "<td>" . $row["total_amount"]. "</td>";
             

		 
	 //  echo  "<td class='last'><a style='color:green;' href='Payable_Backend.php?id=".$row["c_id"]."'>Select</a></td>";
	   
     echo "<td>
    
      <a  type='button' href='lawsuit_print.php?id=".$row["l_id"]."' class='btn btn-success btn-sm'><i class='fa fa-print'></i></a>
     
     </td>";
        
		
		
		 
		 
		
		 

		  }
} else {
   
}
						  $conn->close();
   
						?>
                        
                           
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
                      </div>
                     
                     
                    </div>
                  </div>
                </div>
              </div>


            <div class="clearfix"></div>
         
        </div>  
                
                 <?php
                }
            
            ?>
                
                
          
          
          
          
        <footer>
          <div class="pull-right">

          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <div id="custom_notifications" class="custom-notifications dsp_none">
      <ul class="list-unstyled notifications clearfix" data-tabbed_notifications="notif-group">
      </ul>
      <div class="clearfix"></div>
      <div id="notif-group" class="tabbed_notifications"></div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- PNotify -->
    <script src="../vendors/pnotify/dist/pnotify.js"></script>
    <script src="../vendors/pnotify/dist/pnotify.buttons.js"></script>
    <script src="../vendors/pnotify/dist/pnotify.nonblock.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
	
  </body>
</html>
