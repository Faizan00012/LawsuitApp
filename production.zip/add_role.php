<?php
include_once 'header_file.php';
include_once 'connection.php';
$conn;
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  
    <title>Add Role</title>

    <!-- Bootstrap -->
    <?php
    if($_SESSION["lang_option"]=="en"){
        
           ?>
              <link rel="stylesheet" href="navcode1.css">
             <?php
    }
    else{
        
          ?>
              <link rel="stylesheet" href="navcode2.css">
             <?php
    }
    ?>
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

 
        <?php include 'nav.php';  ?>
    
                    
<?php if(isset($_POST['change_submit'])) {
      $_SESSION["lang_option"]=$_POST["langoption"];}

              if($_SESSION["lang_option"]=="en"){
                  ?>

                  <form action="" method="post">
        <div dir="" style="width:100%" lang="ar" class="right_col" role="main">
 
            <div class="clearfix"></div>
            
                
                   <div class="col-md-12 ">
                          <a href="role.php" class="btn btn-dark btn-sm">Role</a>
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Add New Role </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div dir="ltr" class="x_content">
                    <br />
                   

                        <div class="col-md-12 col-sm-6  form-group">
                    <input type="text" name="roll_name" class="form-control" id="inputSuccess2" placeholder="Name">
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                        <h6>Roles:</h6>
                      </div>
                    
                       
                    
                        <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox" name="dashboard"  value="dashboard"> Dashboard </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="customer" value="customer"> Customer </label></div></div>
                    <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="customer" value="add_customer"> Add Customer </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="customer" value="show_customer"> show Customer </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="edit_customer" value="customer"> Edit Customer </label></div></div>
                          <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="delete_customer" value="customer"> Delete Customer </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="customer_type" value="customer_type"> Customer Type </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="customer_type" value="add_customer_type"> Add Customer Type </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                               <input type="checkbox"  name="customer_type" value="show_customer_type"> show Customer Type </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                           <input type="checkbox"  name="edit_customer_type" value="customer_type"> Edit Customer Type </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                           <input type="checkbox"  name="delete_customer_type" value="customer_type"> Delete Customer Type </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="lawsuit" value="lawsuit"> Lawsuit </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox" name="add_lawsuit"  value="add_lawsuit"> Add Lawsuit </label></div></div>
                         <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                                           <input type="checkbox"  name="show_lawsuit" value="lawsuit"> show Lawsuit </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox" name="add_lawsuit"  value="edit_lawsuit"> Edit Lawsuit </label></div></div>
                         <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox" name="add_lawsuit"  value="delete_lawsuit"> Delete Lawsuit </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                             <input type="checkbox"  name="lawsuit_type" value="lawsuit_type"> Lawsuit Type </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                           <input type="checkbox"  name="lawsuit_type" value="add_lawsuit_type"> Add Lawsuit Type </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="lawsuit_type" value="show_lawsuit_type"> show Lawsuit Type </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="edit_lawsuit_type" value="lawsuit_type"> Edit Type </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="delete_lawsuit_type" value="lawsuit_type"> Delete Type </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="state" value="state"> State </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                                <input type="checkbox"  name="add_state" value="state"> Add State </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                                <input type="checkbox"  name="show_state" value="state"> show State </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                              <input type="checkbox"  name="edit_state" value="state"> Edit State </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                              <input type="checkbox"  name="delete_state" value="state"> Delete State </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="stage" value="stage"> Stage </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="add_stage" value="stage"> Add Stage </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="show_stage" value="stage"> show Stage </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="edit_stage" value="stage"> Edit Stage </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="delete_stage" value="stage"> Delete Stage </label></div></div>
                      
                        
                      <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox" name="task"  value="task"> Task </label></div></div>
                    <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox" name="add_task"  value="task"> Add Task </label></div></div>
                    <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox" name="show_task"  value="task"> show Task </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox" name="edit_task"  value="task"> Edit Task </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox" name="delete_task"  value="task"> Delete Task </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="apeal" value="apeal"> Apeal </label></div></div>
                      <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="add_apeal" value="apeal"> Add Apeal </label></div></div>
                      <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="show_apeal" value="apeal"> show Apeal </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="edit_apeal" value="apeal"> Edit Apeal </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="delete_apeal" value="apeal"> Delete Apeal </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="session_roll" value="session_roll"> Session </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                              <input type="checkbox"  name="" value="session_roll"> Add Session </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                              <input type="checkbox"  name="" value="session_roll"> show Session </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                             <input type="checkbox"  name="edit_session_roll" value="session_roll"> Edit Session </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                             <input type="checkbox"  name="delete_session_roll" value="session_roll"> Delete Session </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="payment_lawsuit" value="payment_lawsuit"> Payment Lawsuit </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="payment_lawsuit"> Add Payment Lawsuit </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="paper">Add Paper </label></div></div>
                        <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="paper">show Paper </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="paper" value="paper"> Paper </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                               <input type="checkbox"  name="edit_paper" value="paper"> Edit Paper </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                           <input type="checkbox"  name="delte_paper" value="paper"> Delete Paper </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="img" value="paper"> Image and File </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="paper"> Add Image and File </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="paper"> show Image and File </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="edit_img" value="paper"> Edit Image and File </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="delete_img" value="paper"> Delete image and File </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                             <input type="checkbox"  name="num" value="paper"> Number </label></div></div>
                               <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                             <input type="checkbox"  name="" value="paper"> Add Number </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                             <input type="checkbox"  name="" value="paper"> show Number </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="edit_num" value="paper"> Edit Number </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="delete_del" value="paper"> Delete Number </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                             <input type="checkbox"  name="" value="paper"> show Payment Lawsuit </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                             <input type="checkbox"  name="" value="paper"> Add Payment Lawsuit </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                             <input type="checkbox"  name="pl" value="paper"> Payment Lawsuit </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                             <input type="checkbox"  name="e_pl" value="paper"> Edit Payment Lawsuit </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                             <input type="checkbox"  name="d_pl" value="paper"> Delete Payment Lawsuit </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                           
                    <input type="checkbox"  name="add_consultation" value="add_consultation"> show Consultation </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label> 
                    <input type="checkbox"  name="add_consultation" value="add_consultation"> Add Consultation </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="consultation" value="consultation"> Consultation </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                            <input type="checkbox"  name="e_consultation" value="consultation"> Edit Consultation </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                            <input type="checkbox"  name="d_consultation" value="consultation"> Delete Consultation </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="payment_consultation" value="payment_consultation"> Payment Consultation </label></div></div>
                      <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="expense" value="expense"> Expense </label></div></div>
                    <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="expense"> Add Expense </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="expense"> show Expense </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                            <input type="checkbox"  name="e_expense" value="expense"> Edit Expense </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                            <input type="checkbox"  name="d_expense" value="expense"> Delete Expense </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="expense_section" value="expense_section"> Expense Section </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                               <input type="checkbox"  name="expense_section" value="expense_section"> Add Expense Section </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="expense_section" value="expense_section"> show Expense Section </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                              <input type="checkbox"  name="edit_expense_section" value="expense_section"> Edit Expense Section </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                              <input type="checkbox"  name="delete_expense_section" value="expense_section"> Delete Expense Section </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="annual_report" value="annual_report"> Annual Report </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="monthly_report" value="monthly_report"> Monthly Report </label></div></div>
                      
                      <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox" name="customer_report"  value="customer_report"> Customer Report </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="lawsuit_report" value="lawsuit_report"> Lawsuit Report </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="session_report" value="session_report"> Session Report </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="payment_lawsuit_report" value="payment_lawsuit_report"> Payment Lawsuit Report </label></div></div>
                      
                          <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="consultation_report" value="consultation_report"> Consultation Report </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="payment_consultation_report" value="payment_consultation_report"> Payment Consultation Report </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="expense_report" value="expense_report"> Expense Report </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="branches" value="branches"> Branches</label></div></div>
                    <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="branches" value="branches"> Add Branches</label></div></div>
                    <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="branches" value="branches"> show Branches</label></div></div>
                       
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="branches" value="branches"> Edit Branches</label></div></div>
                      
                        <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="branches" value="branches"> Delete Branches</label></div></div>
                      
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="users" value="users"> Users </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="role" value="role"> Role </label></div></div>
                    <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="role"> Print Consultation Voucher </label></div></div>
                    <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="role"> Print Lawsuit Voucher </label></div></div>
                    <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="role"> Finance </label></div></div>
                    <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="role"> HR </label></div></div>
                      
                      
                     <div class="form-group row">
                        <div class="col-md-12 col-sm-9  offset-md-4"><br>
                          <button style="width:30%" type="submit" name="submit" class="btn btn-success">Add Role</button>
                        </div>
                      </div>

                     
                  </div>
                </div>
 
              


              </div>
              
            </div>

            
           </form>   
                   <?php
              }
                else
                {
                ?>
                   <form style="font-size:20px;" action="" method="post">

       <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
 
 
            <div class="clearfix"></div>
            
                
                   <div class="col-md-12 ">
                 <a href="role.php" class="btn btn-dark btn-sm">الصلاحيات</a>
                <div class="x_panel">
                  <div class="x_title">
                    
                <h2 style="float:right;font-size:24px;" >إضافة دور جديد </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div  dir="rtl" class="x_content">
                    <br />
                   

                        <div class="col-md-12 col-sm-6  form-group">
                    <input type="text" name="roll_name" class="form-control" id="inputSuccess2" placeholder="اسم">
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                        <h6 style="float:right;">الأدوار:</h6>
                      </div>
                      
                    <div >
                                  
                                  
                                  <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox" name="dashboard"  value="dashboard"> الرئيسية </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="customer" value="customer"> العملاء </label></div></div>
                    <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="customer" value="add_customer"> إضافة العملاء </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="customer" value="show_customer"> عرض  العملاء </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="edit_customer" value="customer"> تعديل  العملاء </label></div></div>
                          <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="delete_customer" value="customer"> حذف  عميل </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="customer_type" value="customer_type"> Customer نوع العميل </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="add_customer_type" value="add_customer_type"> إضافة  نوع العميل </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                               <input type="checkbox"  name="customer_type" value="show_customer_type"> عرض نوع العميل </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                           <input type="checkbox"  name="edit_customer_type" value="customer_type"> تعديل نوع العميل</label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                           <input type="checkbox"  name="delete_customer_type" value="customer_type"> حذف  نوع العميل </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="lawsuit" value="lawsuit"> القضايا </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox" name="add_lawsuit"  value="add_lawsuit"> إضافة القضايا </label></div></div>
                         <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                                           <input type="checkbox"  name="show_lawsuit" value="lawsuit"> عرض القضايا </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox" name="add_lawsuit"  value="edit_lawsuit"> تعديل القضايا </label></div></div>
                         <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox" name="add_lawsuit"  value="delete_lawsuit"> حذف القضايا </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                             <input type="checkbox"  name="lawsuit_type" value="lawsuit_type"> أنواع القضايا </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                           <input type="checkbox"  name="lawsuit_type" value="add_lawsuit_type"> إضافة أنواع القضايا </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="lawsuit_type" value="show_lawsuit_type"> عرض أنواع القضايا </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="edit_lawsuit_type" value="lawsuit_type"> تعديل أنواع القضايا </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="delete_lawsuit_type" value="lawsuit_type"> حذف أنواع القضايا </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="state" value="state"> حالات القضية </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                                <input type="checkbox"  name="add_state" value="state"> إضافة حالات القضية </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                                <input type="checkbox"  name="show_state" value="state"> عرض حالات القضية </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                              <input type="checkbox"  name="edit_state" value="state"> تعديل حالات القضية </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                              <input type="checkbox"  name="delete_state" value="state"> حذف حالات القضية </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="stage" value="stage"> مرحلة  </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="add_stage" value="stage"> إضافة مرحلة </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="show_stage" value="stage"> عرض مرحلة </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="edit_stage" value="stage"> تعديل مرحلة </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="delete_stage" value="stage"> حذف مرحلة </label></div></div>
                      
                        
                      <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox" name="task"  value="task"> مهام </label></div></div>
                    <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox" name="add_task"  value="task"> إضافة مهام </label></div></div>
                    <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox" name="show_task"  value="task"> عرض مهام </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox" name="edit_task"  value="task"> تعديل مهام </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox" name="delete_task"  value="task"> حذف مهام </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="apeal" value="apeal"> الاستئناف </label></div></div>
                      <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="add_apeal" value="apeal"> إضافة الاستئناف </label></div></div>
                      <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="show_apeal" value="apeal"> عرض الاستئناف </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="edit_apeal" value="apeal"> تعديل الاستئناف </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="delete_apeal" value="apeal"> حذف الاستئناف </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="session_roll" value="session_roll"> الجلسات </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                              <input type="checkbox"  name="" value="session_roll"> إضافة الجلسات </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                              <input type="checkbox"  name="" value="session_roll"> عرض الجلسات </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                             <input type="checkbox"  name="edit_session_roll" value="session_roll"> تعديل الجلسات </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                             <input type="checkbox"  name="delete_session_roll" value="session_roll"> حذف الجلسات </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="payment_lawsuit" value="payment_lawsuit"> مدفوعات القضايا </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="payment_lawsuit"> إضافة فوعات القضايا </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="paper">Add صحائف الدعوى </label></div></div>
                        <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="paper">show صحائف الدعوى </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="paper" value="paper"> صحائف الدعوى </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                               <input type="checkbox"  name="edit_paper" value="paper"> تعديل صحائف الدعوى </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                           <input type="checkbox"  name="delte_paper" value="paper"> حذف صحائف الدعوى </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="img" value="paper"> صورة وملفات القضية </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="paper"> إضافة صورة وملفات القضية </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="paper"> عرض صورة وملفات القضية </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="edit_img" value="paper"> تعديل صورة وملفات القضية </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="delete_img" value="paper"> حذف صورة وملفات القضية </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                             <input type="checkbox"  name="num" value="paper"> أرقام القضية </label></div></div>
                               <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                             <input type="checkbox"  name="" value="paper"> إضافة أرقام القضية </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                             <input type="checkbox"  name="" value="paper"> عرض أرقام القضية </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="edit_num" value="paper"> تعديل أرقام القضية </label></div></div>
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="delete_del" value="paper"> حذف أرقام القضية </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                            <input type="checkbox"  name="pl" value="paper"> مدفوعات القضايا </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                             <input type="checkbox"  name="" value="paper"> عرض مدفوعات القضايا </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                             <input type="checkbox"  name="" value="paper"> إضافة مدفوعات القضايا </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                             <input type="checkbox"  name="e_pl" value="paper"> تعديل مدفوعات القضايا</label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                             <input type="checkbox"  name="d_pl" value="paper"> حذف مدفوعات القضايا </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                           
                    <input type="checkbox"  name="add_consultation" value="add_consultation"> عرض الاستشارات </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label> 
                    <input type="checkbox"  name="add_consultation" value="add_consultation"> إضافة الاستشارات </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="consultation" value="consultation"> الاستشارات </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                            <input type="checkbox"  name="e_consultation" value="consultation"> تعديل الاستشارات </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                            <input type="checkbox"  name="d_consultation" value="consultation"> حذف الاستشارات </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="payment_consultation" value="payment_consultation"> مدفوعات الاستشارات </label></div></div>
                      <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="expense" value="expense"> المصروفات </label></div></div>
                    <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="expense"> إضافة المصروفات </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="expense"> عرض المصروفات </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                            <input type="checkbox"  name="e_expense" value="expense"> تعديل المصروفات </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                            <input type="checkbox"  name="d_expense" value="expense"> حذف المصروفات </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="expense_section" value="expense_section"> أقسام المصروفات </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                               <input type="checkbox"  name="expense_section" value="expense_section"> إضافة أقسام المصروفات </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="expense_section" value="expense_section"> عرض أقسام المصروفات </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                              <input type="checkbox"  name="edit_expense_section" value="expense_section"> تعديل أقسام المصروفات </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                              <input type="checkbox"  name="delete_expense_section" value="expense_section"> حذف أقسام المصروفات </label></div></div>
                
                     <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="annual_report" value="annual_report"> التقرير السنوي</label></div></div>
                 <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="monthly_report" value="monthly_report"> التقرير الشهري </label></div></div>
                      
                      <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox" name="customer_report"  value="customer_report"> تقارير العملاء </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="lawsuit_report" value="lawsuit_report"> تقارير القضايا </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="session_report" value="session_report"> تقارير الجلسات </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="payment_lawsuit_report" value="payment_lawsuit_report"> تقارير مدفوعات القضايا </label></div></div>
                      
                          <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="consultation_report" value="consultation_report"> تقارير الاستشارة </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="payment_consultation_report" value="payment_consultation_report"> تقارير مدفوعات الاستشارات </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="expense_report" value="expense_report"> تقارير المصروفات </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="branches" value="branches"> الفروع</label></div></div>
                    <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="branches" value="branches"> إضافة الفروع</label></div></div>
                    <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="branches" value="branches"> عرض الفروع</label></div></div>
                       
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="branches" value="branches"> تعديل الفروع</label></div></div>
                      
                        <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="branches" value="branches"> حذف الفروع</label></div></div>
                      
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="users" value="users"> المستخدمين </label></div></div>
                       <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="role" value="role"> الصلاحيات </label></div></div>
                    <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="role"> طباعة عقد الاستشارة </label></div></div>
                    <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="role"> طباعة عقد القضية </label></div></div>
                    <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="role"> الماليات </label></div></div>
                    <div class="col-md-3 col-sm-6  form-group"><div class="checkbox"><label>
                    <input type="checkbox"  name="" value="role"> الموارد البشرية </label></div></div>
                     
                     </div>
                      
                      
                     <div class="form-group row">
                        <div class="col-md-12 col-sm-9  offset-md-4"><br>
                          <button style="width:30%" type="submit" name="submit" class="btn btn-success">أضف دورًا</button>
                        </div>
                      </div>

                     
                  </div>
                </div>
 
              


              </div>
              
            </div>

            
           </form>   
                
                 <?php
                }
            
            ?>
                
                
    
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
     

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>
    <!-- jQuery Tags Input -->
    <script src="../vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
    <!-- Switchery -->
    <script src="../vendors/switchery/dist/switchery.min.js"></script>
    <!-- Select2 -->
    <script src="../vendors/select2/dist/js/select2.full.min.js"></script>
    <!-- Parsley -->
    <script src="../vendors/parsleyjs/dist/parsley.min.js"></script>
    <!-- Autosize -->
    <script src="../vendors/autosize/dist/autosize.min.js"></script>
    <!-- jQuery autocomplete -->
    <script src="../vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
    <!-- starrr -->
    <script src="../vendors/starrr/dist/starrr.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
	
  </body>
</html>
<?php
include_once 'connection.php';
$conn;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{
 
 
 
  $sql = "INSERT INTO roll (roll_name,app_dashboard,  app_customer, app_customerType, app_lawsuit, app_add_lawsuit, app_lawsuit_type, app_stage, app_state, app_task, app_apeal, app_session, app_pament_ls, app_paper, app_add_consult, app_consultation, app_payment_consult, app_expense, app_expense_Section, app_annual_report, app_monthly_report, app_customer_report, app_lawsuit_report, app_session_report, app_payment_laysuit_report, app_consultation_report, app_payment_consultation_report, app_expernse_report, app_branches, created_at)
VALUES ('".$_POST["roll_name"]."','".isset($_POST["dashboard"])."', '".isset($_POST["customer"])."', '".isset($_POST["customer_type"])."', '".isset($_POST["lawsuit"])."', '".isset($_POST["add_lawsuit"])."', '".isset($_POST["lawsuit_type"])."', '".isset($_POST["stage"])."', '".isset($_POST["state"])."', '".isset($_POST["task"])."', '".isset($_POST["apeal"])."', '".isset($_POST["session_roll"])."', '".isset($_POST["payment_lawsuit"])."', '".isset($_POST["paper"])."', '".isset($_POST["add_consultation"])."', '".isset($_POST["consultation"])."', '".isset($_POST["payment_consultation"])."', '".isset($_POST["expense"])."', '".isset($_POST["expense_section"])."', '".isset($_POST["annual_report"])."', '".isset($_POST["monthly_report"])."', '".isset($_POST["customer_report"])."', '".isset($_POST["lawsuit_report"])."', '".isset($_POST["session_report"])."', '".isset($_POST["payment_lawsuit_report"])."', '".isset($_POST["consultation_report"])."', '".isset($_POST["payment_consultation_report"])."', '".isset($_POST["expense_report"])."', '".isset($_POST["branches"])."', '".date('Y-m-d')."')";
if ($conn->query($sql) === TRUE) {
  echo "New Roll Added";
}else{
	echo "New Roll Not Added";
} 
 
}

$conn->close();
?>


