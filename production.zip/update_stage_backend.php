<?php

include_once 'connection.php';
$conn;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{
 
    
        $id=$_POST["stage_id"];
    $sql = "UPDATE stage SET stage_ar='".$_POST["name_ar"]."', stage_en='".$_POST["name_en"]."', created_at='".$_POST["created_at"]."' WHERE stage_id=".$id;
  
if ($conn->query($sql) === TRUE) {
        header('Location: stages.php');
  
} else {
    echo "Error updating record: " . $conn->error;
}
   
 
 

}

$conn->close();
?>