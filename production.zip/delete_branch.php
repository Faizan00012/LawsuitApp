<?php
 
$id = $_GET['id'];

include_once 'connection.php';
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// sql to delete a record
$sql = "DELETE FROM branch WHERE b_id = {$id}";

if ($conn->query($sql) === TRUE) {
    
} else {
     
}
 
header("Location: branch.php");

mysqli_close($conn);

?>
