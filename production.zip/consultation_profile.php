<?php
include_once 'header_file.php';
$id = $_GET['id'];
$con_Subject="";
$con_Start="";
$con_end="";
$c_name="";
$c_address="";
$c_email="";
$c_nationality="";
$cl_amount="";
$cl_tax="";
$cl_total="";
include_once 'connection.php';
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM consultation con INNER Join customer c ON con.c_id=c.c_ID  where con.con_id=".$id;
 
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $con_Subject=$row["con_subject"];
$con_Start=$row["start_date"];
$con_end=$row["end_date"];
$c_name=$row["c_name"];
$c_address=$row["c_address"];
$c_email=$row["c_email"];
$c_nationality=$row["c_nationality"];
$cl_amount=$row["amount_contract"];
$cl_tax=$row["total_amount"]-$row["amount_contract"];
$cl_total=$row["total_amount"];
    }
}  
?>

<!DOCTYPE html>
<html lang="en">

  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Consultation Profile</title>

    <!-- Bootstrap -->
   <?php
    if($_SESSION["lang_option"]=="en"){
        
           ?>
              <link rel="stylesheet" href="navcode1.css">
             <?php
    }
    else{
        
          ?>
              <link rel="stylesheet" href="navcode2.css">
             <?php
    }
    ?>
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="../vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- PNotify -->
    <link href="../vendors/pnotify/dist/pnotify.css" rel="stylesheet">
    <link href="../vendors/pnotify/dist/pnotify.buttons.css" rel="stylesheet">
    <link href="../vendors/pnotify/dist/pnotify.nonblock.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>
  

  
               <?php include 'nav.php';  ?>

                    
<?php if(isset($_POST['change_submit'])) {
      $_SESSION["lang_option"]=$_POST["langoption"];}

              if($_SESSION["lang_option"]=="en"){
                  ?>

                  
                  <div dir="" style="width:100%" lang="ar" class="right_col" role="main">
          

            <div class="clearfix"></div>
            
  <div class="col-md-12">
                <div class="">
                  <div dir="ltr" class="x_content">
                    <div class="row">
                      <div class="animated flipInY col-lg-4 col-md-3 col-sm-6  ">
                                 <div style="border-radius:2px;width:100%;padding:10px;background-color:white">
                          <div class="icon"><i style="float:right;color:#030345;font-size:50px" class="fa fa-money"></i>
                          </div>
                          <div style="color:#030345;font-size:30px" class="count"><?php echo $cl_amount; ?></div>

                           
                          <p>Consultation Amount</p>
                        </div>
                      </div>
                           <div class="animated flipInY col-lg-4 col-md-3 col-sm-6  ">
                                 <div style="border-radius:2px;width:100%;padding:10px;background-color:white">
                          <div class="icon"><i style="float:right;color:#030345;font-size:50px" class="fa fa-certificate"></i>
                          </div>
                          <div style="color:#030345;font-size:30px" class="count"><?php echo $cl_tax; ?></div>

                           
                          <p>Tax Value</p>
                        </div>
                      </div>
                           <div class="animated flipInY col-lg-4 col-md-3 col-sm-6  ">
                                 <div style="border-radius:2px;width:100%;padding:10px;background-color:white">
                          <div class="icon"><i style="float:right;color:#030345;font-size:50px" class="fa fa-money"></i>
                          </div>
                          <div style="color:#030345;font-size:30px" class="count"><?php echo $cl_total; ?></div>

                           
                          <p>Consultation Amount Including Tax</p>
                        </div>
                      </div>
                            
                    
                    </div>

              


 
                  
                  </div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6 ">
                  <div  class="x_panel" style="background-color:white;border:solid;border-color:white;">
                <div class="x_content" style="background-color:#00504d;padding:20px;width:100%;height:20%">
                    <h1 style="text-align:center;color:white"><i class="fa fa-legal"></i></h1>
                    <h2 style="color:white">Consultation No: <?php echo $id; ?> </h2>  </div>
                                               <p>
                                                   <br>
                                <b>.</b><br><br>
                                <b>Subject/Title of Consultation: <br></b><?php echo $con_Subject; ?> <br>
                                <b>Consultation Start Date:  <br></b> <?php echo $con_Start; ?><br>
                                <b>Consultation End Date: <br></b> <?php echo $con_Subject; ?><br>
                                   </p>
                                                   <hr>
                      <h6><u>Client Information</u></h6>
                 <p>
                     <b>Name: </b><br><?php echo $c_name; ?><br>
                                <b>Customer Email:<br> </b><?php echo $c_email; ?><br>
                     <b>Customer Nationality:</b><br><?php echo $c_nationality; ?><br>
                     <b>Customer Address:</b><br><?php echo $c_address; ?><br></p>  

              </div>
              </div>        
              <div class="col-md-9 col-sm-6  ">
                <div class="x_panel">
                 
                  <div class="x_content">

                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                      <li class="nav-item">
                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Payment</a>
                      </li>
                         
                   
                    </ul>
                    <div  class="tab-content" id="myTabContent" >
                    
                          <div style="background-color:white;" class="tab-pane fade show active" id="add" role="tabpanel" aria-labelledby="add-tab"><br>
                    
                             &nbsp;&nbsp;<a href='add_consultation_payment.php?id=<?php echo $id; ?>' class="btn btn-dark btn-sm">+ Add New Payment</a><br><br>
                           <div class="col-md-12 col-sm-6  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="color:#030345">Account Ledger</h2>
              
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table class="table">
                      <thead>
                        <tr>
                          <th>Payment ID</th>
                          <th>Paid Amount</th>
                          <th>Receivable Amount</th>
                              <th>Payment Method</th>
                          <th>That About</th>
                          <th>Date</th>
                        </tr>
                      </thead>
                      <tbody>
                     <?php
                          include_once 'connection.php';
                          $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM consultation_ledger where con_id=".$id;
$paid=0;
$due=0;                          
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
         if($row["cled_paid"]!=0){
             $paid=$paid+$row["cled_paid"];
             $due=$row["cled_du"];
            
       ?>
          <tr><td><?php echo $row["cled_id"]; ?></td>
              <td><?php echo $row["cled_paid"]; ?></td>
               <td><?php echo $row["cled_du"]; ?></td>
                <td><?php echo $row["cled_method"]; ?></td>
               <td><?php echo $row["cled_about"]; ?></td>
               <td><?php echo $row["cled_date"]; ?></td>
                          
                          </tr>                
                          
  <?php } }
} else {
    echo "0 results";
}
                          ?>
                       <tr>
                          <th colspan="4">Total Amount Incl Tax</th>
                             <th colspan="4"><?php echo $cl_total; ?></th>
                          </tr>
                            <tr>
                          <th colspan="4">Total Paid Amount</th>
                             <th colspan="4"><?php echo $paid; ?></th>
                          </tr>
                            <tr>
                          <th colspan="4">Total Receivable Amount </th>
                            <th colspan="4"><?php echo $due; ?></th>
                          </tr>
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>

                      </div>
                       
                    </div>
                  </div>
                </div>
              </div>


            <div class="clearfix"></div>
         
        </div> 
                   <?php
              }
                else
                {
                ?>
                   <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
 
          

            <div class="clearfix"></div>
            
  <div class="col-md-12">
                <div class="">
                  <div class="x_content">
                    <div dir="rtl" class="row">
                     
                        
                           <div class="animated flipInY col-lg-4 col-md-3 col-sm-6  ">
                        <div dir="rtl" style="float:right;border-radius:2px;width:100%;padding:10px;background-color:white">
                          <div class="icon"><i style="float:right;color:#030345;font-size:50px" class="fa fa-money"></i>
                          </div>
                          <div style="color:#030345;font-size:30px" class="count"><?php echo $cl_amount; ?></div>

                           
                        <p>مبلغ الاستشارة</p>
                        </div>
                      </div>
                           <div class="animated flipInY col-lg-4 col-md-3 col-sm-6  ">
                        <div dir="rtl" style="float:right;border-radius:2px;width:100%;padding:10px;background-color:white">
                          <div class="icon"><i style="float:right;color:#030345;font-size:50px" class="fa fa-certificate"></i>
                          </div>
                          <div style="color:#030345;font-size:30px" class="count"><?php echo $cl_tax; ?></div>

                           
                          <p>مبلغ الضريبة</p>
                        </div>
                      </div>
                           <div class="animated flipInY col-lg-4 col-md-3 col-sm-6  ">
                                 <div style="border-radius:2px;width:100%;padding:10px;background-color:white">
                          <div class="icon"><i style="float:right;color:#030345;font-size:50px" class="fa fa-money"></i>
                          </div>
                          <div style="color:#030345;font-size:30px" class="count"><?php echo $cl_total; ?></div>

                           
                        <p>المبلغ الاجمالي شامل الضريبة</p>
                        </div>
                      </div>
                            
                    
                            
                    
                    </div>

              


 
                  
                  </div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6 ">
                  <div  class="x_panel" style="background-color:white;border:solid;border-color:white;">
                <div class="x_content" style="background-color:#00504d;padding:20px;width:100%;height:20%">
                    <h1 style="text-align:center;color:white"><i class="fa fa-legal"></i></h1>
                    <h2 style="color:white">رقم ملف الاستشارة: <?php echo $id; ?> </h2>  </div>
                                               <p>
                                                   <br>
                                <b>.</b><br><br>
                                <b>موضوع/عنوان الاستشارة: <br></b><?php echo $con_Subject; ?> <br>
                                <b>تاريخ بداية الاستشارة:  <br></b> <?php echo $con_Start; ?><br>
                                <b>تاريخ بداية الاستشارة: <br></b> <?php echo $con_Subject; ?><br>
                                   </p>
                                                   <hr>
                      <h6><u>بيانات العميل</u></h6>
                 <p>
                     <b>عميل : </b><br><?php echo $c_name; ?><br>
                                <b>إيميل العميلل:<br> </b><?php echo $c_email; ?><br>
                     <b>جنسية العميل:</b><br><?php echo $c_nationality; ?><br>
                     <b>عنوان العميل:</b><br><?php echo $c_address; ?><br></p>  

              </div>
              </div>        
              <div class="col-md-9 col-sm-6  ">
                <div class="x_panel">
                 
                  <div class="x_content">

                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                      <li class="nav-item">
                        <a style="float:right"  class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">مدفوعات الاستشارات</a>
                      </li>
                         
                   
                    </ul>
                    <div dir="rtl"   class="tab-content" id="myTabContent">
                    
                          <div style="background-color:white;" class="tab-pane fade show active" id="add" role="tabpanel" aria-labelledby="add-tab"><br>
                    
                             &nbsp;&nbsp;<a style="float:right"  href='add_consultation_payment.php?id=<?php echo $id; ?>' class="btn btn-dark btn-sm">+ اضافة دفعة مالية جديدة</a><br><br>
                           <div class="col-md-12 col-sm-6  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="float:right"  style="color:#030345">دفع الحساب</h2>
              
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table dir="rtl" class="table">
                      <thead>
                        <tr>
                          <th>معرف الدفع</th>
                          <th>المبلغ المدفوع</th>
                          <th>المبلغ الباقي</th>
                              <th>طريقة الدفع</th>
                          <th>وذلك عن</th>
                          <th>تاريخ الدفع</th>
                        </tr>
                      </thead>
                      <tbody>
                     <?php
                          include_once 'connection.php';
                          $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM consultation_ledger where con_id=".$id;
$paid=0;
$due=0;                          
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
         if($row["cled_paid"]!=0){
             $paid=$paid+$row["cled_paid"];
             $due=$row["cled_du"];
            
       ?>
          <tr><td><?php echo $row["cled_id"]; ?></td>
              <td><?php echo $row["cled_paid"]; ?></td>
               <td><?php echo $row["cled_du"]; ?></td>
                <td><?php echo $row["cled_method"]; ?></td>
               <td><?php echo $row["cled_about"]; ?></td>
               <td><?php echo $row["cled_date"]; ?></td>
                          
                          </tr>                
                          
  <?php } }
} else {
    echo "0 results";
}
                          ?>
                       <tr>
                          <th colspan="4">المبلغ الإجمالي شامل الضريبة</th>
                             <th colspan="4"><?php echo $cl_total; ?></th>
                          </tr>
                            <tr>
                          <th colspan="4">إجمالي المبلغ المدفوع</th>
                             <th colspan="4"><?php echo $paid; ?></th>
                          </tr>
                            <tr>
                          <th colspan="4">إجمالي المبلغ المستحق </th>
                            <th colspan="4"><?php echo $due; ?></th>
                          </tr>
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>

                      </div>
                       
                    </div>
                  </div>
                </div>
              </div>


            <div class="clearfix"></div>
         
        </div>   
                 <?php
                }
            
            ?>
                
                
          
          
          <footer>
          <div class="pull-right">
           </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <div id="custom_notifications" class="custom-notifications dsp_none">
      <ul class="list-unstyled notifications clearfix" data-tabbed_notifications="notif-group">
      </ul>
      <div class="clearfix"></div>
      <div id="notif-group" class="tabbed_notifications"></div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- PNotify -->
    <script src="../vendors/pnotify/dist/pnotify.js"></script>
    <script src="../vendors/pnotify/dist/pnotify.buttons.js"></script>
    <script src="../vendors/pnotify/dist/pnotify.nonblock.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
	
  </body>
</html>