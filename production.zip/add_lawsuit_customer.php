<?php
include_once 'header_file.php';
include_once 'connection.php';
$conn;
$c_id = $_GET['id'];
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  
    <title><?php 
                             if($_SESSION["lang_option"]=="en"){
                                echo "Add Lawsuit";
                            }
                            else{
                                 echo "إضافة قضية جديدة";
                            }
                            ?></title>

    <!-- Bootstrap -->
    <?php
    if($_SESSION["lang_option"]=="en"){
        
           ?>
              <link rel="stylesheet" href="navcode1.css">
             <?php
    }
    else{
        
          ?>
              <link rel="stylesheet" href="navcode2.css">
             <?php
    }
    ?>
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

   
         <?php include 'nav.php';  ?>
        
                     
                    
<?php if(isset($_POST['change_submit'])) {
      $_SESSION["lang_option"]=$_POST["langoption"];}

              if($_SESSION["lang_option"]=="en"){
                  ?>

                  
             <form action="" method="post">
              
        <div dir="" style="width:100%" lang="ar" class="right_col" role="main">
 
            <div class="clearfix"></div>
            
                
            <div class="col-md-12 ">

			      <a href="lawsuit.php" class="btn btn-dark btn-sm">Lawsuit</a>
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Add New Lawsuit </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div dir="ltr" class="x_content">
                    <br />
                    

                        <div class="col-md-4 col-sm-6  form-group">
                            <select class="form-control" name="ls_branch">
                             <option>Select Branch Name</option>
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from branch";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["b_id"]."'>".$row["b_en"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                     </div>
                      <div class="col-md-4 col-sm-6  form-group">
                            <select class="form-control" name="ls_customer">
                            <option>Select Customer Name</option>
                                 <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from customer";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["c_id"]."'>".$row["c_name"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                     </div>
               <div class="col-md-4 col-sm-6  form-group">
                            <select class="form-control" name="ls_customertype">
                            <option>Select Customer Type</option>
                                 <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from customer_type";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["ct_id"]."'>".$row["ct_en"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                     </div>
             
                      <div class="col-md-3 col-sm-6  form-group">
                    <input type="text" name="opp_name" class="form-control" id="inputSuccess2" placeholder="Opponent Name">
                      </div>
                      <div class="col-md-3 col-sm-6  form-group">
                    <input type="text" name="opp_phone" class="form-control" id="inputSuccess2" placeholder="Opponent Phone">
                      </div>
                      <div class="col-md-3 col-sm-6  form-group">
                    <input type="text" name="opp_nationality" class="form-control" id="inputSuccess2" placeholder="Opponent Nationality">
                      </div>
                      <div class="col-md-3 col-sm-6  form-group">
                    <input type="text" name="opp_address" class="form-control" id="inputSuccess2" placeholder="Opponent Address">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                    <input type="text" name="opp_lawyer" class="form-control" id="inputSuccess2" placeholder="Opponent Lawyer">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                    <input type="text" name="opp_lawyerphone" class="form-control" id="inputSuccess2" placeholder="Opponent Lawyer Phone">
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                   <h4 style="color:red;">Lawsuit and Contract Data</h4>
                      </div>
                        <div class="col-md-3 col-sm-6  form-group">
                       <select class="form-control" name="ls_lawsuittype">
                             <option>Select Lawsuit Type</option>
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from lawsuit_type";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["lt_id"]."'>".$row["lt_en"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                      </div>
                        <div class="col-md-3 col-sm-6  form-group">
                    <input type="text" name="ls_lawyer" class="form-control" id="inputSuccess2" placeholder="Lawsuit Lawyer">
                      </div>
                        <div class="col-md-6 col-sm-6  form-group">
                    <input type="text" name="ls_subject" class="form-control" id="inputSuccess2" placeholder="Subject Lawsuit">
                      </div>
                          <div class="col-md-6 col-sm-6  form-group">
                    <input type="text" required="required"  name="ls_consultant" class="form-control" id="inputSuccess2" placeholder="Consultant Lawsuit">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                    <input type="text" required="required"  name="ls_assistant" class="form-control" id="inputSuccess2" placeholder="Assistant Lawsuit">
                      </div>
                      <div class="col-md-3 col-sm-6  form-group">
                    <select class="form-control" name="ls_stage">
                             <option>Select Stage</option>
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from stage";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["stage_id"]."'>".$row["stage_en"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                      </div>
                      <div class="col-md-3 col-sm-6  form-group">
                    <select class="form-control" name="ls_state">
                             <option>Select State</option>
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from state";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["state_id"]."'>".$row["state_en"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                      </div>
                      <div class="col-md-2 col-sm-6  form-group">
                    <input type="text" onkeydown="AmountChange()" name="ls_amount" class="form-control" id="amount" placeholder="Amount Contract">
                      </div>
                      <div class="col-md-2 col-sm-6  form-group">
                    <input type="text" onkeydown="AmountChange()" name="ls_tax" class="form-control" id="tax" placeholder="Tax Value%">
                      </div>
                      <div class="col-md-2 col-sm-6  form-group">
                    <input type="text" name="ls_total" class="form-control" id="total" placeholder="Amount includ Tax">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                    <input type="text" name="ls_location" class="form-control" id="inputSuccess2" placeholder="Lawsuit location">
                      </div>
                      <div class="col-md-2 col-sm-6  form-group">
                    <h6 style="padding-top:12px;">Created At: </h6>
                      </div>
                        <div class="col-md-4 col-sm-6  form-group">
                    <input type="date" name="created_at" class="form-control" id="inputSuccess2" placeholder="">
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                   <h4 style="color:red;">Contract Preamble</h4>
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                        <textarea placeholder="Contract Preamble AR" name="cp_ar" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                        <textarea placeholder="Contract Preamble EN" name="cp_en" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                   <h4 style="color:red;">Fee and Payments Details</h4>
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                        <textarea placeholder="Fee and Payments Details AR" name="fee_ar" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                        <textarea placeholder="Fee and Payments Details EN" name="fee_en" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                   <h4 style="color:red;">Contract Terms</h4>
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                        <textarea placeholder="Contract Terms AR" name="contract_ar" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                        <textarea placeholder="Contract Terms EN" name="contract_en" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                         <div class="col-md-12 col-sm-6  form-group">
                   <h4 style="color:red;">Note</h4>
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                        <textarea placeholder="Note" name="note" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                      
                           </div>
                     <div class="form-group row">
                        
                        <div class="col-md-12 col-sm-2  offset-md-4"><br>
                          <button  type="submit" name="submit" class="btn btn-success">Add Lawsuit</button>
                        </div>
                      </div>

                 
                  </div>
                </div>
 
              


          
              
            </div>

            
           </form>
                   <?php
              }
                else
                {
                ?>
               <form style="font-size:20px;" action="" method="post">


              
     <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
 
            <div class="clearfix"></div>
            
                
            <div class="col-md-12 ">
           <a style="float:right;font-size:20px;padding-left:20px;padding-right:20px;" href="lawsuit.php" class="btn btn-dark btn-sm">القضايا </a>
			
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="float:right;font-size:24px;" >إضافة قضية جديدة</h2>
                 
                    <div class="clearfix"></div> 
                  </div>
                  <div dir="rtl" class="x_content">
                    <br />
                    

                        <div class="col-md-4 col-sm-6  form-group">
                            <select class="form-control" name="ls_branch">
                             <option>اختر فرع</option>
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from branch";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["b_id"]."'>".$row["b_ar"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                     </div>
                      <div class="col-md-4 col-sm-6  form-group">
                            <select class="form-control" name="ls_customer">
                            <option>اختر عميل</option>
                                 <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from customer";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["c_id"]."'>".$row["c_name"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                     </div>
               <div class="col-md-4 col-sm-6  form-group">
                            <select class="form-control" name="ls_customertype">
                            <option>اختر نوع العميل</option>
                                 <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from customer_type";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["ct_id"]."'>".$row["ct_ar"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                     </div>
             
                      <div class="col-md-3 col-sm-6  form-group">
                    <input type="text" name="opp_name" class="form-control" id="inputSuccess2" placeholder="اسم الخصم">
                      </div>
                      <div class="col-md-3 col-sm-6  form-group">
                    <input type="text" name="opp_phone" class="form-control" id="inputSuccess2" placeholder="هاتف الخصم">
                      </div>
                      <div class="col-md-3 col-sm-6  form-group">
                    <input type="text" name="opp_nationality" class="form-control" id="inputSuccess2" placeholder="جنسية الخصم">
                      </div>
                      <div class="col-md-3 col-sm-6  form-group">
                    <input type="text" name="opp_address" class="form-control" id="inputSuccess2" placeholder="عنوان الخصم">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                    <input type="text" name="opp_lawyer" class="form-control" id="inputSuccess2" placeholder="محامي الخصم">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                    <input type="text" name="opp_lawyerphone" class="form-control" id="inputSuccess2" placeholder="هاتف محامي الخصم">
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                   <h4 style="float:right;color:red;">بيانات القضية والعقد :</h4>
                      </div>
                        <div class="col-md-3 col-sm-6  form-group">
                       <select class="form-control" name="ls_lawsuittype">
                             <option>نوع القضية</option>
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from lawsuit_type";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["lt_id"]."'>".$row["lt_ar"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                      </div>
                        <div class="col-md-3 col-sm-6  form-group">
                    <input type="text" name="ls_lawyer" class="form-control" id="inputSuccess2" placeholder="محامي القضية">
                      </div>
                        <div class="col-md-6 col-sm-6  form-group">
                    <input type="text" name="ls_subject" class="form-control" id="inputSuccess2" placeholder="عنوان/موضوع الدعوى">
                      </div>
                       <div class="col-md-6 col-sm-6  form-group">
                    <input type="text" required="required"  name="ls_consultant" class="form-control" id="inputSuccess2" placeholder="مستشار القضية">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                    <input type="text" required="required"  name="ls_assistant" class="form-control" id="inputSuccess2" placeholder="مساعد القضية">
                      </div>
                      <div class="col-md-3 col-sm-6  form-group">
                    <select class="form-control" name="ls_stage">
                             <option>مرحلة التقاضي</option>
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from stage";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["stage_id"]."'>".$row["stage_ar"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                      </div>
                      <div class="col-md-3 col-sm-6  form-group">
                    <select class="form-control" name="ls_state">
                             <option>حالة القضية</option>
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from state";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["state_id"]."'>".$row["state_ar"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                      </div>
                      <div class="col-md-2 col-sm-6  form-group">
                    <input type="text" onkeydown="AmountChange()" name="ls_amount" class="form-control" id="amount" placeholder="مبلغ العقد">
                      </div>
                      <div class="col-md-2 col-sm-6  form-group">
                    <input type="text" onkeydown="AmountChange()" name="ls_tax" class="form-control" id="tax" placeholder="قيمة الصريبة٪">
                      </div>
                      <div class="col-md-2 col-sm-6  form-group">
                    <input type="text" name="ls_total" class="form-control" id="total" placeholder="المبلغمبلغ العقد شامل الضريبة">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                    <input type="text" name="ls_location" class="form-control" id="inputSuccess2" placeholder="مكان القضية">
                      </div>
                      <div class="col-md-2 col-sm-6  form-group">
                          
                    <h6 dir="rtl" style="float:right;padding-top:12px;">أنشئت في:</h6>
                      </div>
                        <div class="col-md-4 col-sm-6  form-group">
                    <input type="date" name="created_at" class="form-control" id="inputSuccess2" placeholder="تاريخ الإنشاء">
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                   <h4 style="float:right;color:red;">تمهيد العقد</h4>
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                        <textarea placeholder="تمهيد العقد عربي" name="cp_ar" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                        <textarea placeholder="تمهيد العقد انجليزي" name="cp_en" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                   <h4 style="float:right;color:red;">تفاصيل الأتعاب والدفعات</h4>
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                        <textarea placeholder="تفاصيل الأتعاب والدفعات عربي" name="fee_ar" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                        <textarea placeholder="تفاصيل الأتعاب والدفعات إنجليزي" name="fee_en" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                   <h4 style="float:right;color:red;">شروط العقد</h4>
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                        <textarea placeholder="شروط العقد عربي :" name="contract_ar" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                        <textarea placeholder="شروط العقد الإنجليزية" name="contract_en" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                         <div class="col-md-12 col-sm-6  form-group">
                   <h4 style="float:right;color:red;">ملحوظة</h4>
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                        <textarea placeholder="ملحوظة" name="note" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                      
                           </div>
                     <div class="form-group row">
                        
                        <div class="col-md-12 col-sm-2  offset-md-4"><br>
                          <button  type="submit" name="submit" class="btn btn-success">إضافة</button>
                        </div>
                      </div>

                 
                  </div>
                </div>
 
              


          
              
            </div>

            
           </form>
                
                 <?php
                }
            
            ?>
                
                  
        </div>
        <script>
        function AmountChange(){
      
            var amount=document.getElementById("amount").value;
           var tax=document.getElementById("tax").value;
            var per=parseInt(tax)/100*parseInt(amount);
             
              var total_amount=parseInt(document.getElementById("amount").value)+per;
            document.getElementById("total").value=total_amount;
        }
        </script>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
           
        </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
     

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>
    <!-- jQuery Tags Input -->
    <script src="../vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
    <!-- Switchery -->
    <script src="../vendors/switchery/dist/switchery.min.js"></script>
    <!-- Select2 -->
    <script src="../vendors/select2/dist/js/select2.full.min.js"></script>
    <!-- Parsley -->
    <script src="../vendors/parsleyjs/dist/parsley.min.js"></script>
    <!-- Autosize -->
    <script src="../vendors/autosize/dist/autosize.min.js"></script>
    <!-- jQuery autocomplete -->
    <script src="../vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
    <!-- starrr -->
    <script src="../vendors/starrr/dist/starrr.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
	
  </body>
</html>
<?php
include_once 'connection.php';
$conn;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{
$sql = "INSERT INTO lawsuit ( lt_id,b_id, c_id, ct_id, opp_name, opp_contact, opp_nationality, opp_address, opp_lawyer, opp_lawyer_contact, lawyer, subject, consultant, assistant, stage_id, state_id, amount_contact, tax, total_amount, location, contract_preamble_ar, contract_preamble_en, fee_detail_ar, fee_detail_en, contact_ar, contract_en, note, created_at) VALUES ('".$_POST["ls_lawsuittype"]."','".$_POST["ls_branch"]."','".$_POST["ls_customer"]."','".$_POST["ls_customertype"]."','".$_POST["opp_name"]."','".$_POST["opp_phone"]."','".$_POST["opp_nationality"]."','".$_POST["opp_address"]."','".$_POST["opp_lawyer"]."','".$_POST["opp_lawyerphone"]."','".$_POST["ls_lawyer"]."','".$_POST["ls_subject"]."','".$_POST["ls_consultant"]."','".$_POST["ls_assistant"]."','".$_POST["ls_stage"]."','".$_POST["ls_state"]."','".$_POST["ls_amount"]."','".$_POST["ls_tax"]."','".$_POST["ls_total"]."','".$_POST["ls_location"]."','".$_POST["cp_ar"]."','".$_POST["cp_en"]."','".$_POST["fee_ar"]."','".$_POST["fee_en"]."','".$_POST["contract_ar"]."','".$_POST["contract_en"]."','".$_POST["note"]."','".$_POST["created_at"]."')";

if ($conn->query($sql) === TRUE) {
  echo "New lawsuit Added";
}else{
	echo "New lawsuit Not Added";
}
$sql = "SELECT MAX(l_id) AS l_id FROM lawsuit";
$l_id=0;
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
  $l_id=$row["l_id"];
    }
} 
    
     $sql = "INSERT INTO lawsuit_ledger (l_id, led_paid, led_du, led_method, led_about, led_date) VALUES ('".$l_id."','0','".$_POST["ls_total"]."','no Payment','','".date('Y-m-d')."')";
 
if ($conn->query($sql) === TRUE) {
  
}else{
	 
} 

}

$conn->close();
?>

 