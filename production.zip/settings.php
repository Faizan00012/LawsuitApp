<?php
include_once 'header_file.php';
include_once 'connection.php';
$conn;
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  
     <title>Settings</title>

    <!-- Bootstrap -->
    <?php
    if($_SESSION["lang_option"]=="en"){
        
           ?>
              <link rel="stylesheet" href="navcode1.css">
             <?php
    }
    else{
        
          ?>
              <link rel="stylesheet" href="navcode2.css">
             <?php
    }
    ?>
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

 
 <?php include 'nav.php';  ?>
         
                       
<?php if(isset($_POST['change_submit'])) {
      $_SESSION["lang_option"]=$_POST["langoption"];}

              if($_SESSION["lang_option"]=="en"){
                  ?>

                  
                      
       <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
 
            <div class="clearfix"></div>
            
                
                   <div class="col-md-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Settings </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div dir="ltr" class="x_content">
                    <br />
                      <?php
                   
                      include_once 'connection.php';
  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
    $conn = new mysqli($servername, $username, $password, $dbname);
$sql = "SELECT * FROM settings where set_id= 1";
$result = $conn->query($sql);
          
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
          ?>
                   <form action="update_settings.php" method="post"  enctype="multipart/form-data">
                       <div class="col-md-6 col-sm-6  form-group">
                            <label>Change Logo</label>
                   <input type="file" name="fileToUpload1" id="fileToUpload1">
                      </div>
                     
                      <div class="col-md-6 col-sm-6  form-group">
                      
                    <img src="uploads/<?php echo $row['set_logo']; ?>" style="width:20%;height:20%">
                      </div>
                       <div class="col-md-6 col-sm-6  form-group">
                            <label>Change Header file</label>
                     <input type="file" name="fileToUpload2" id="fileToUpload2">
                      </div>
                      
                      <div class="col-md-6 col-sm-6  form-group">
                      
                    <img src="uploads/<?php echo $row['set_header']; ?>" style="width:20%;height:30%">
                      </div>



 
                        <div class="col-md-12 col-sm-6  form-group">
                            <label>Office Name</label>
                    <input type="text" name="Office_Name" value="<?php echo $row["Office_Name"]; ?>" class="form-control" id="inputSuccess2" placeholder="Office Name">
                     <input type="hidden" name="pre_logo" value="<?php echo $row["set_logo"]; ?>">
                      <input type="hidden" name="pre_header" value="<?php echo $row["set_header"]; ?>">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>ID NO</label>
                    <input type="text" name="id_no" value="<?php echo $row["id_no"]; ?>" class="form-control" id="inputSuccess2" placeholder="ID NO">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>CR Number</label>
                    <input type="text" name="cr_no" value="<?php echo $row["cr_no"]; ?>" class="form-control" id="inputSuccess2" placeholder="CR Number">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>Office Name</label>
                    <input type="text" name="post_box" value="<?php echo $row["post_box"]; ?>" class="form-control" id="inputSuccess2" placeholder="Post Box">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                          <label>City</label>
                    <input type="text" name="city" value="<?php echo $row["city"]; ?>" class="form-control" id="inputSuccess2" placeholder="City">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                          <label>Address</label>
                    <input type="text" name="address" value="<?php echo $row["address"]; ?>" class="form-control" id="inputSuccess2" placeholder="Address">
                      </div>
                      
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>Phone</label>
                    <input type="text" name="phone" value="<?php echo $row["phone"]; ?>" class="form-control" id="inputSuccess2" placeholder="Phone">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>Moblile No</label>
                    <input type="text" name="mobile" value="<?php echo $row["mobile"]; ?>" class="form-control" id="inputSuccess2" placeholder="Mobile No">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>Email</label>
                    <input type="text" name="email" value="<?php echo $row["email"]; ?>" class="form-control" id="inputSuccess2" placeholder="Email">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>Whatsapp</label>
                    <input type="text" name="whatsapp" value="<?php echo $row["whatsapp"]; ?>" class="form-control" id="inputSuccess2" placeholder="Whatsapp">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>currency</label>
                    <input type="text" name="currency" value="<?php echo $row["currency"]; ?>" class="form-control" id="inputSuccess2" placeholder="currency">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>Tax Value</label>
                    <input type="text" name="tax_value" value="<?php echo $row["tax_value"]; ?>" class="form-control" id="inputSuccess2" placeholder="Tax Value">
                      </div>
                       <div class="col-md-6 col-sm-6  form-group">
                            <label>Tax Number</label>
                    <input type="text" name="tax_no" value="<?php echo $row["tax_no"]; ?>" class="form-control" id="inputSuccess2" placeholder="Tax Number">
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                            <label>preface lawsuits ar</label>
                         <textarea name="preface_lawsuits_ar" class="form-control" style="width:100%;height:100px"><?php echo $row["preface_lawsuits_ar"]; ?></textarea>

                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                            <label>preface lawsuits en</label>
                         <textarea  name="preface_lawsuits_en" class="form-control" style="width:100%;height:100px"><?php echo $row["preface_lawsuits_en"]; ?></textarea>

                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                            <label>fee lawsuits ar</label>
                         <textarea  name="fee_lawsuits_ar" class="form-control" style="width:100%;height:100px"><?php echo $row["fee_lawsuits_ar"]; ?></textarea>

                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                            <label>fee lawsuits en</label>
                         <textarea  name="fee_lawsuits_en" class="form-control" style="width:100%;height:100px"><?php echo $row["fee_lawsuits_en"]; ?></textarea>

                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                            <label>contract lawsuits ar</label>
                         <textarea  name="contract_lawsuits_ar" class="form-control" style="width:100%;height:100px"><?php echo $row["contract_lawsuits_ar"]; ?></textarea>

                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                            <label>contract lawsuits en</label>
                         <textarea  name="contract_lawsuits_en" class="form-control" style="width:100%;height:100px"><?php echo $row["contract_lawsuits_en"]; ?></textarea>

                      </div>
                        <div class="col-md-12 col-sm-6  form-group">
                            <label>contract consultations ar</label>
                         <textarea  name="contract_consultations_ar" class="form-control" style="width:100%;height:100px"><?php echo $row["contract_consultations_ar"]; ?></textarea>

                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                            <label>contract consultations en</label>
                         <textarea name="contract_consultations_en" class="form-control" style="width:100%;height:100px"><?php echo $row["contract_consultations_en"]; ?></textarea>

                      </div>
                      
                      
                     <div class="form-group row">
                        <div class="col-md-9 col-sm-9  offset-md-4"><br>
                          <button style="width:30%" type="submit" name="submit" class="btn btn-success">save</button>
                        </div>
                      </div>
                      </form>
                       <?php  } } else {}?>
                  </div>
                </div>
 
              

              </div>
              
            </div>
            
          
                   <?php
              }
                else
                {
                ?>
               
                      
     <div dir="ltr" style="width:100%; text-align:right; " lang="ar" class="right_col" role="main">
 
 
            <div class="clearfix"></div>
            
                
                   <div class="col-md-12 ">
                <div class="x_panel">
                  <div class="x_title" >
                    <h2 style="float:right;">الإعدادات </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
                      <?php
                   
                      include_once 'connection.php';
  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
    $conn = new mysqli($servername, $username, $password, $dbname);
$sql = "SELECT * FROM settings where set_id= 1";
$result = $conn->query($sql);
          
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
          ?>
                   <form action="update_settings.php" method="post"  enctype="multipart/form-data" style="float:right;">
                       <div class="col-md-3 col-sm-3  form-group" >
                            <label >شعار</label>
                   <input type="file" name="fileToUpload1" id="fileToUpload">
                      </div>
                     
                      <div class="col-md-3 col-sm-3  form-group" >
                      
                    <img src="uploads/<?php echo $row['set_logo']; ?>" style="width:20%;height:20%">
                      </div>
                       <div class="col-md-3 col-sm-3  form-group">
                            <label>رأس الفواتير</label>
                     <input type="file" name="fileToUpload2" id="fileToUpload">
                      </div>
                      
                      <div class="col-md-3 col-sm-3  form-group">
                      
                    <img src="uploads/<?php echo $row['set_header']; ?>" style="width:20%;height:30%">
                      </div>



 
                        <div class="col-md-12 col-sm-6  form-group">
                            <label>اسم المكتب</label>
                    <input type="text" name="Office_Name" value="<?php echo $row["Office_Name"]; ?>" class="form-control" id="inputSuccess2" placeholder="Office Name">
                    <input type="hidden" name="pre_logo" value="<?php echo $row["set_logo"]; ?>">
                      <input type="hidden" name="pre_header" value="<?php echo $row["set_header"]; ?>">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>رقم البطاقة</label>
                    <input type="text" name="id_no" value="<?php echo $row["id_no"]; ?>" class="form-control" id="inputSuccess2" placeholder="ID NO">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>رقم السجل التجاري</label>
                    <input type="text" name="cr_no" value="<?php echo $row["cr_no"]; ?>" class="form-control" id="inputSuccess2" placeholder="CR Number">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>صندوق البريد</label>
                    <input type="text" name="post_box" value="<?php echo $row["post_box"]; ?>" class="form-control" id="inputSuccess2" placeholder="Post Box">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                          <label>المدينة</label>
                    <input type="text" name="city" value="<?php echo $row["city"]; ?>" class="form-control" id="inputSuccess2" placeholder="City">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                          <label>العنوان</label>
                    <input type="text" name="address" value="<?php echo $row["address"]; ?>" class="form-control" id="inputSuccess2" placeholder="Address">
                      </div>
                      
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>الهاتف</label>
                    <input type="text" name="phone" value="<?php echo $row["phone"]; ?>" class="form-control" id="inputSuccess2" placeholder="Phone">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>رقم الجوال</label>
                    <input type="text" name="mobile" value="<?php echo $row["mobile"]; ?>" class="form-control" id="inputSuccess2" placeholder="Mobile No">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>الإيميل</label>
                    <input type="text" name="email" value="<?php echo $row["email"]; ?>" class="form-control" id="inputSuccess2" placeholder="Email">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>الواتساب</label>
                    <input type="text" name="whatsapp" value="<?php echo $row["whatsapp"]; ?>" class="form-control" id="inputSuccess2" placeholder="Whatsapp">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>رمز العملة</label>
                    <input type="text" name="currency" value="<?php echo $row["currency"]; ?>" class="form-control" id="inputSuccess2" placeholder="currency">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>قيمة الصريبة</label>
                    <input type="text" name="tax_value" value="<?php echo $row["tax_value"]; ?>" class="form-control" id="inputSuccess2" placeholder="Tax Value">
                      </div>
                       <div class="col-md-6 col-sm-6  form-group">
                            <label>الرقم الضريبي</label>
                    <input type="text" name="tax_no" value="<?php echo $row["tax_no"]; ?>" class="form-control" id="inputSuccess2" placeholder="Tax Number">
                      </div>
                      
                        <div class="col-md-12 col-sm-6  form-group">
                            <label>التمهيد عقد القضايا عربي</label>
                         <textarea name="preface_lawsuits_ar" class="form-control" style="width:100%;height:100px"><?php echo $row["preface_lawsuits_ar"]; ?></textarea>

                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                            <label>التمهيد لعقد القضايا انجليزي</label>
                         <textarea  name="preface_lawsuits_en" class="form-control" style="width:100%;height:100px"><?php echo $row["preface_lawsuits_en"]; ?></textarea>

                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                            <label>نظام الأتعاب عربي</label>
                         <textarea  name="fee_lawsuits_ar" class="form-control" style="width:100%;height:100px"><?php echo $row["fee_lawsuits_ar"]; ?></textarea>

                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                            <label>نظام الأتعاب انجليزي</label>
                         <textarea  name="fee_lawsuits_en" class="form-control" style="width:100%;height:100px"><?php echo $row["fee_lawsuits_en"]; ?></textarea>

                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                            <label>شروط عقد القضايا عربي</label>
                         <textarea  name="contract_lawsuits_ar" class="form-control" style="width:100%;height:100px"><?php echo $row["contract_lawsuits_ar"]; ?></textarea>

                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                            <label> شروط عقد القضايا انجليزي</label>
                         <textarea  name="contract_lawsuits_en" class="form-control" style="width:100%;height:100px"><?php echo $row["contract_lawsuits_en"]; ?></textarea>

                      </div>
                        <div class="col-md-12 col-sm-6  form-group">
                            <label> شروط عقد الاستشارات عربي </label>
                         <textarea  name="contract_consultations_ar" class="form-control" style="width:100%;height:100px"><?php echo $row["contract_consultations_ar"]; ?></textarea>

                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                            <label>شروط عقد الاستشارات انجليزي</label>
                         <textarea name="contract_consultations_en" class="form-control" style="width:100%;height:100px"><?php echo $row["contract_consultations_en"]; ?></textarea>

                      </div>
                     <div class="form-group row">
                        <div class="col-md-9 col-sm-9  offset-md-4"><br>
                          <button style="width:30%" type="submit" name="submit" class="btn btn-success">حفظ</button>
                        </div>
                      </div>
                      </form>
                       <?php  } } else {}?>
                  </div>
                </div>
 
              


              </div>
              
            </div>
            
                   
                 <?php
                }
            
            ?>
                
                
          
          
        <footer>
          <div class="pull-right">
            </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>
    <!-- jQuery Tags Input -->
    <script src="../vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
    <!-- Switchery -->
    <script src="../vendors/switchery/dist/switchery.min.js"></script>
    <!-- Select2 -->
    <script src="../vendors/select2/dist/js/select2.full.min.js"></script>
    <!-- Parsley -->
    <script src="../vendors/parsleyjs/dist/parsley.min.js"></script>
    <!-- Autosize -->
    <script src="../vendors/autosize/dist/autosize.min.js"></script>
    <!-- jQuery autocomplete -->
    <script src="../vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
    <!-- starrr -->
    <script src="../vendors/starrr/dist/starrr.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
	
  </body>
</html>
 