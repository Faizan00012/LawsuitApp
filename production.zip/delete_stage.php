<?php


$id = $_GET['id'];

include_once 'connection.php';
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


$sql = "DELETE FROM stage WHERE stage_id = {$id}";
 
if ($conn->query($sql) === TRUE) {
    
} else {
     
}
 
header("Location: stages.php");

mysqli_close($conn);
 
?>
