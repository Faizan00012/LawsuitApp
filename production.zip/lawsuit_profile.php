<?php
include_once 'header_file.php';
$id = $_GET['id'];
$l_id="";
$branch="";
$c_name="";
$c_address="";
$c_email="";
$c_nationality="";
$cl_amount="";
$cl_tax="";
$cl_total="";
include_once 'connection.php';
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM lawsuit l INNER Join customer c ON l.c_id=c.c_ID INNER Join branch b ON l.b_id=b.b_ID INNER Join stage stg ON l.stage_id=stg.stage_id INNER Join state sta ON l.state_id=sta.state_id  where l.l_id=".$id;
 
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $l_id=$row["l_id"];
$branch=$row["b_en"];
$state=$row["state_en"];
$stage=$row["stage_en"];
$subject=$row["subject"];
$c_name=$row["c_name"];        
$c_address=$row["c_address"];
$c_email=$row["c_email"];
$c_nationality=$row["c_nationality"];
$cl_amount=$row["amount_contact"];
$cl_tax=$row["total_amount"]-$row["amount_contact"];
$cl_total=$row["total_amount"];
    }
}  
?>

<!DOCTYPE html>
<html lang="en">

  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Lawsuit Profile</title>

    <!-- Bootstrap -->
<?php
    if($_SESSION["lang_option"]=="en"){
        
           ?>
              <link rel="stylesheet" href="navcode1.css">
             <?php
    }
    else{
        
          ?>
              <link rel="stylesheet" href="navcode2.css">
             <?php
    }
    ?>
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="../vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- PNotify -->
    <link href="../vendors/pnotify/dist/pnotify.css" rel="stylesheet">
    <link href="../vendors/pnotify/dist/pnotify.buttons.css" rel="stylesheet">
    <link href="../vendors/pnotify/dist/pnotify.nonblock.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

 
               <?php include 'nav.php';  ?>
                   
<?php if(isset($_POST['change_submit'])) {
      $_SESSION["lang_option"]=$_POST["langoption"];}

              if($_SESSION["lang_option"]=="en"){
                  ?>

                  
             <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
          

            <div class="clearfix"></div>
            
  <div class="col-md-12">
                <div class="">
                  <div dir="ltr" class="x_content">
                    <div class="row">
                      <div class="animated flipInY col-lg-4 col-md-3 col-sm-6  ">
                        <div style="border-radius:2px;width:100%;padding:10px;background-color:white">
                          <div class="icon"><i style="float:right;color:#030345;font-size:50px" class="fa fa-money"></i>
                          </div>
                          <div style="color:#030345;font-size:30px" class="count"><?php echo $cl_amount; ?></div>

                           
                          <p>Lawsuit Amount</p>
                        </div>
                      </div>
                           <div class="animated flipInY col-lg-4 col-md-3 col-sm-6  ">
                        <div style="border-radius:2px;width:100%;padding:10px;background-color:white">
                          <div class="icon"><i style="float:right;color:#030345;font-size:50px" class="fa fa-certificate"></i>
                          </div>
                          <div style="color:#030345;font-size:30px" class="count"><?php echo $cl_tax; ?></div>

                           
                          <p>Tax Value</p>
                        </div>
                      </div>
                           <div class="animated flipInY col-lg-4 col-md-3 col-sm-6  ">
                        <div style="border-radius:2px;width:100%;padding:10px;background-color:white">
                          <div class="icon"><i style="float:right;color:#030345;font-size:50px" class="fa fa-money"></i>
                          </div>
                          <div style="color:#030345;font-size:30px" class="count"><?php echo $cl_total; ?></div>

                           
                          <p>Lawsuit Amount Including Tax</p>
                        </div>
                      </div>
                            
                    
                    </div>

              


 
                  
                  </div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6 ">
                  <div  class="x_panel" style="background-color:white;border:solid;border-color:white;">
                <div class="x_content" style="background-color:#00504d;padding:20px;width:100%;height:20%">
                    <h1 style="text-align:center;color:white"><i class="fa fa-legal"></i></h1>
                    <h2 style="color:white">Lawsuit File No: <?php echo $l_id; ?> </h2>  </div>
                                               <p>
                                                   <br>
                                <b>.</b><br><br>
                                <b>Branch: <br></b><?php echo $branch; ?> <br>
                                <b>State:  <br></b> <?php echo $state; ?><br>
                                <b>Subject<br></b> <?php echo $subject; ?><br>
                                <b>Stage<br></b> <?php echo $stage; ?><br>
                                   </p>
                                                   <hr>
                      <h6><u>Client Information</u></h6>
                 <p>
                     <b>Name: </b><br><?php echo $c_name; ?><br>
                                <b>Customer Email:<br> </b><?php echo $c_email; ?><br>
                     <b>Customer Nationality:</b><br><?php echo $c_nationality; ?><br>
                     <b>Customer Address:</b><br><?php echo $c_address; ?><br></p>  

              </div>
              </div>        
              <div class="col-md-9 col-sm-6  ">
                <div class="x_panel">
                 
                    <div class="x_content">

                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                      <li class="nav-item">
                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#session" role="tab" aria-controls="home" aria-selected="true">Session</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#payment" role="tab" aria-controls="profile" aria-selected="false">Payments</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" id="contact-tab" data-toggle="tab" href="#paper" role="tab" aria-controls="contact" aria-selected="false">Papers</a>
                      </li>
                         <li class="nav-item">
                        <a class="nav-link" id="contact-tab" data-toggle="tab" href="#number" role="tab" aria-controls="contact" aria-selected="false">Numbers</a>
                      </li>
                         <li class="nav-item">
                        <a class="nav-link" id="contact-tab" data-toggle="tab" href="#apeal" role="tab" aria-controls="contact" aria-selected="false">Rulings and Apeal Date</a>
                      </li>
                        <li class="nav-item">
                        <a class="nav-link" id="contact-tab" data-toggle="tab" href="#image" role="tab" aria-controls="contact" aria-selected="false">Image & Files</a>
                      </li>

                        </ul>
                    <div class="tab-content" id="myTabContent">
                      <div style="background-color:white;" class="tab-pane fade show active" id="session" role="tabpanel" aria-labelledby="home-tab">
                         &nbsp;&nbsp;<a href='add_session.php?id=<?php echo $id; ?>' class="btn btn-dark btn-sm">+ Add New Session</a><br><br>
                           <div class="col-md-12 col-sm-6  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="color:#030345">Session Details</h2>
              
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table class="table">
                      <thead>
                        <tr>
                          <th>Session ID</th>
                          <th>Session Name</th>
                          <th>Session Date</th>
                              <th>Session Place</th>
                          <th>Session Details</th>
                         
                          </tr>
                      </thead>
                      <tbody>
                     <?php
                          include_once 'connection.php';
                          $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM session where l_id=".$id;
$paid=0;
$due=0;                          
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
       
            
       ?>
          <tr><td><?php echo $row["session_id"]; ?></td>
              <td><?php echo $row["session_name"]; ?></td>
               <td><?php echo $row["session_date"]; ?></td>
                <td><?php echo $row["session_place"]; ?></td>
               <td><?php echo $row["session_detail"]; ?></td>
               
              
                          
                          </tr>                
                          
  <?php  }
} else {
    echo "0 results";
}
                          ?>
                       
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
                      </div>
                      <div style="background-color:white;" class="tab-pane fade" id="payment" role="tabpanel" aria-labelledby="profile-tab">
                        &nbsp;&nbsp;<a href='add_lawsuit_payment.php?id=<?php echo $id; ?>' class="btn btn-dark btn-sm">+ Add New Payment</a><br><br>
                           <div class="col-md-12 col-sm-6  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="color:#030345">Account Ledger</h2>
              
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table class="table">
                      <thead>
                        <tr>
                          <th>Payment ID</th>
                          <th>Paid Amount</th>
                          <th>Receivable Amount</th>
                              <th>Payment Method</th>
                          <th>That About</th>
                          <th>Date</th>
                            
                        </tr>
                      </thead>
                      <tbody>
                     <?php
                          include_once 'connection.php';
                          $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM lawsuit_ledger where l_id=".$id;
$paid=0;
$due=0;                          
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
         if($row["led_paid"]!=0){
             $paid=$paid+$row["led_paid"];
             $due=$row["led_du"];
            
       ?>
          <tr><td><?php echo $row["led_id"]; ?></td>
              <td><?php echo $row["led_paid"]; ?></td>
               <td><?php echo $row["led_du"]; ?></td>
                <td><?php echo $row["led_method"]; ?></td>
               <td><?php echo $row["led_about"]; ?></td>
               <td><?php echo $row["led_date"]; ?></td>
             
                          </tr>          
                      
                          
  <?php } }
    ?>
    <tr>
                          <th colspan="5">Total Amount Incl Tax</th>
                             <th colspan="5"><?php echo $cl_total; ?></th>
                          </tr>
                            <tr>
                          <th colspan="5">Total Paid Amount</th>
                             <th colspan="5"><?php echo $paid; ?></th>
                          </tr>
                            <tr>
                          <th colspan="5">Total Receivable Amount </th>
                            <th colspan="5"><?php echo $due; ?></th>
                          </tr>
<?php                          
} else {
    echo "No Data";
}
                          ?>
                       
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
                      </div>
                      <div style="background-color:white;" class="tab-pane fade" id="paper" role="tabpanel" aria-labelledby="contact-tab">
                         &nbsp;&nbsp;<a href='add_paper.php?id=<?php echo $id; ?>' class="btn btn-dark btn-sm">+ Add New Paper</a><br><br>
                           <div class="col-md-12 col-sm-6  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="color:#030345">Paper Details</h2>
              
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table class="table">
                      <thead>
                        <tr>
                          <th>Paper ID</th>
                          <th>Delete Title</th>
                          <th>Paper Date</th>
                              <th>Paper Details</th>
 
                           
                        </tr>
                      </thead>
                      <tbody>
                     <?php
                          include_once 'connection.php';
                          $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM paper where l_id=".$id;
$paid=0;
$due=0;                          
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
         
       ?>
          <tr><td><?php echo $row["paper_id"]; ?></td>
              <td><?php echo $row["delete_title"]; ?></td>
               <td><?php echo $row["created_at"]; ?></td>
                <td><?php echo $row["detail"]; ?></td>
               
                          
                          </tr>                
                          
  <?php  }
} else {
    echo "No Data";
}
                          ?>
                      
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
                      </div>
                         <div style="background-color:white;" class="tab-pane fade" id="number" role="tabpanel" aria-labelledby="contact-tab">
                         &nbsp;&nbsp;<a href='add_number.php?id=<?php echo $id; ?>' class="btn btn-dark btn-sm">+ Add New Number</a><br><br>
                           <div class="col-md-12 col-sm-6  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="color:#030345">Number Details</h2>
              
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table class="table">
                      <thead>
                        <tr>
                          <th>Number ID</th>
                          <th>Name</th>
                            <th>Number</th>
                            <th>Note</th>
                          <th>Date</th>
                          
                              
                           
                        </tr>
                      </thead>
                      <tbody>
                     <?php
                          include_once 'connection.php';
                          $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM numbertbl where l_id=".$id;
$paid=0;
$due=0;                          
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
         
       ?>
          <tr><td><?php echo $row["num_id"]; ?></td>
              <td><?php echo $row["name"]; ?></td>
               <td><?php echo $row["num_number"]; ?></td>
                <td><?php echo $row["note"]; ?></td>
              <td><?php echo $row["created_at"]; ?></td>
              
                          
                          </tr>                
                          
  <?php  }
} else {
    echo "No Data";
}
                          ?>
                      
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
                      </div>
                       <div style="background-color:white;" class="tab-pane fade" id="apeal" role="tabpanel" aria-labelledby="contact-tab">
                         &nbsp;&nbsp;<a href='add_apeal.php?id=<?php echo $id; ?>' class="btn btn-dark btn-sm">+ Add New Ruling </a><br><br>
                           <div class="col-md-12 col-sm-6  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="color:#030345">Number Details</h2>
              
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table class="table">
                      <thead>
                        <tr>
                          <th>Ruling ID</th>
                          <th>Date of Ruling</th>
                            <th>Ruling Details</th>
                          
                           
                        </tr>
                      </thead>
                      <tbody>
                     <?php
                          include_once 'connection.php';
                          $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM ruling where l_id=".$id;
$paid=0;
$due=0;                          
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
         
       ?>
          <tr><td><?php echo $row["rl_id"]; ?></td>
              <td><?php echo $row["apeal_date"]; ?></td>
               <td><?php echo $row["apeal_detail"]; ?></td>
               
                          </tr>                
                          
  <?php  }
} else {
    echo "No Data";
}
                          ?>
                      
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
                      </div>
                         <div style="background-color:white;" class="tab-pane fade" id="image" role="tabpanel" aria-labelledby="contact-tab">
                         &nbsp;&nbsp;<a href='add_image.php?id=<?php echo $id; ?>' class="btn btn-dark btn-sm">+ Add New Image </a><br><br>
                           <div class="col-md-12 col-sm-6  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="color:#030345">Image and File</h2>
              
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table class="table">
                      <thead>
                        <tr>
                           <th>Image ID</th>
                          <th>Image Name</th>
                          <th>Show Image</th>
                              <th>Created At</th>
                         
                           
                        </tr>
                      </thead>
                      <tbody>
                     <?php
                          include_once 'connection.php';
                          $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM image_file where l_id=".$id;
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
         
       ?>
          <tr><td><?php echo $row["img_id"]; ?></td>
              <td><?php echo $row["fila_name"]; ?></td>
               <td> <a href="upload_image/<?php echo $row["img_loc"]; ?>" alt="Image description" target="_blank"> Show</a></td>
              
               <td><?php echo $row["created_at"]; ?>  </td>
             
             
            
                          
                          </tr>               
                          
  <?php  }
} else {
    echo "No Data";
}
                          ?>
                      
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
                      </div>
               
                    </div>
                  </div>
                </div>
              </div>


            <div class="clearfix"></div>
         
        </div>   
                   <?php
              }
                else
                {
                ?>
       <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
 
          

            <div class="clearfix"></div>
            
  <div class="col-md-12">
                <div class="">
                  <div class="x_content">
                    <div class="row">
                     
                        
                        
                            <div class="animated flipInY col-lg-4 col-md-3 col-sm-6  ">
                        <div style="border-radius:2px;width:100%;padding:10px;background-color:white">
                          <div class="icon"><i style="float:right;color:#030345;font-size:50px" class="fa fa-money"></i>
                          </div>
                          <div style="color:#030345;font-size:30px" class="count"><?php echo $cl_amount; ?></div>

                           
                            <p>مبلغ الاستشارة</p>
                        </div>
                      </div>
                           <div class="animated flipInY col-lg-4 col-md-3 col-sm-6  ">
                        <div style="border-radius:2px;width:100%;padding:10px;background-color:white">
                          <div class="icon"><i style="float:right;color:#030345;font-size:50px" class="fa fa-certificate"></i>
                          </div>
                          <div style="color:#030345;font-size:30px" class="count"><?php echo $cl_tax; ?></div>

                          <p>مبلغ الضريبة</p>
                        </div>
                      </div>
                           <div class="animated flipInY col-lg-4 col-md-3 col-sm-6  ">
                        <div style="border-radius:2px;width:100%;padding:10px;background-color:white">
                          <div class="icon"><i style="float:right;color:#030345;font-size:50px" class="fa fa-money"></i>
                          </div>
                          <div style="color:#030345;font-size:30px" class="count"><?php echo $cl_total; ?></div>

                           
                                                  <p>المبلغ الاجمالي شامل الضريبة</p>
                        </div>
                      </div>
                            
                    
                    </div>

              


 
                  
                  </div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6 ">
                  <div  class="x_panel" style="background-color:white;border:solid;border-color:white;">
                <div class="x_content" style="background-color:#00504d;padding:20px;width:100%;height:20%">
                    <h1 style="text-align:center;color:white"><i class="fa fa-legal"></i></h1>
                    <h2 style="color:white">رقم ملف القضية  <?php echo $l_id; ?> </h2>  </div>
                                               <p>
                                                   <br>
                                <b>.</b><br><br>
                                <b>فرع: <br></b><?php echo $branch; ?> <br>
                                <b>حالة القضية:  <br></b> <?php echo $state; ?><br>
                                <b>عنوان/موضوع الدعوى:<br></b> <?php echo $subject; ?><br>
                                <b>مرحلة التقاضي<br></b> <?php echo $stage; ?><br>
                                   </p>
                                                   <hr>
                      <h6><u>بيانات العميل</u></h6>
                 <p>
                     <b>عميل: </b><br><?php echo $c_name; ?><br>
                                <b>إيميل العميل:<br> </b><?php echo $c_email; ?><br>
                     <b>جنسية العميل</b><br><?php echo $c_nationality; ?><br>
                     <b>عنوان العميل:</b><br><?php echo $c_address; ?><br></p>  

              </div>
              </div>        
              <div class="col-md-9 col-sm-6  ">
                <div class="x_panel">
                 
                    <div dir="rtl" class="x_content">






                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                      <li class="nav-item">
                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#session" role="tab" aria-controls="home" aria-selected="true">الجلسات</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#payment" role="tab" aria-controls="profile" aria-selected="false">مدفوعات القضايا</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" id="contact-tab" data-toggle="tab" href="#paper" role="tab" aria-controls="contact" aria-selected="false">صحائف الدعوى</a>
                      </li>
                         <li class="nav-item">
                        <a class="nav-link" id="contact-tab" data-toggle="tab" href="#number" role="tab" aria-controls="contact" aria-selected="false">أرقام القضية</a>
                      </li>
                         <li class="nav-item">
                        <a class="nav-link" id="contact-tab" data-toggle="tab" href="#apeal" role="tab" aria-controls="contact" aria-selected="false">حكم المحكمة وتاريخ الاستئناف</a>
                      </li>
                         <li class="nav-item">
                        <a class="nav-link" id="contact-tab" data-toggle="tab" href="#image" role="tab" aria-controls="contact" aria-selected="false">صورة وملفات القضية</a>
                      </li>

                        </ul>
                    <div dir="rtl" class="tab-content" id="myTabContent">
                      <div dir="rtl" style="background-color:white;" class="tab-pane fade show active" id="session" role="tabpanel" aria-labelledby="home-tab">
                         &nbsp;&nbsp;<a style="float:right;font-size:20px;padding-left:20px;padding-right:20px;" href='add_session.php?id=<?php echo $id; ?>' class="btn btn-dark btn-sm">+ إضافة جلسة جديدة</a><br><br>
                           <div class="col-md-12 col-sm-6  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="float:right;font-size:24px;" >الجلسات </h2>
              
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table dir="rtl" class="table">
                      <thead>
                        <tr>
                          <th>رقم الجلسة</th>
                          <th>اسم / سبب الجلسة</th>
                          <th>تاريخ الجلسة</th>
                              <th>مكان الجلسة</th>
                          <th>تفاصيل الجلسة</th>
                       
                          </tr>
                      </thead>
                      <tbody>
                     <?php
                          include_once 'connection.php';
                          $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM session where l_id=".$id;
$paid=0;
$due=0;                          
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
       
            
       ?>
          <tr><td><?php echo $row["session_id"]; ?></td>
              <td><?php echo $row["session_name"]; ?></td>
               <td><?php echo $row["session_date"]; ?></td>
                <td><?php echo $row["session_place"]; ?></td>
               <td><?php echo $row["session_detail"]; ?></td>
              
              
                          
                          </tr>                
                          
  <?php  }
} else {
    echo "0 results";
}
                          ?>
                       
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
                      </div>
                      <div style="background-color:white;" class="tab-pane fade" id="payment" role="tabpanel" aria-labelledby="profile-tab">
                        &nbsp;&nbsp;<a style="float:right;font-size:20px;padding-left:20px;padding-right:20px;" href='add_lawsuit_payment.php?id=<?php echo $id; ?>' class="btn btn-dark btn-sm">+ إضافة دفعة جديدة</a><br><br>
                           <div class="col-md-12 col-sm-6  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="float:right;font-size:24px;" >مدفوعات القضايا</h2>
              
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table dir="rtl" class="table">
                      <thead>
                        <tr>
                                <th>رقم الدفع</th>
                          <th>المبلغ المدفوع</th>
                          <th>المبلغ الباقي</th>
                              <th>طريقة الدفع</th>
                          <th>هذا عن</th>
                          <th>تاريخ الدفع</th>
                             
                        </tr>
                      </thead>
                      <tbody>
                     <?php
                          include_once 'connection.php';
                          $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM lawsuit_ledger where l_id=".$id;
$paid=0;
$due=0;                          
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
         if($row["led_paid"]!=0){
             $paid=$paid+$row["led_paid"];
             $due=$row["led_du"];
            
       ?>
          <tr><td><?php echo $row["led_id"]; ?></td>
              <td><?php echo $row["led_paid"]; ?></td>
               <td><?php echo $row["led_du"]; ?></td>
                <td><?php echo $row["led_method"]; ?></td>
               <td><?php echo $row["led_about"]; ?></td>
               <td><?php echo $row["led_date"]; ?></td>
             </tr>
                                           
  <?php } }
    ?>
    <tr>
                         <th colspan="4">المبلغ الإجمالي شامل الضريبة</th>
                             <th colspan="4"><?php echo $cl_total; ?></th>
                          </tr>
                            <tr>
                          <th colspan="4">إجمالي المبلغ المدفوع</th>
                             <th colspan="4"><?php echo $paid; ?></th>
                          </tr>
                            <tr>
                          <th colspan="4">إجمالي المبلغ المستحق </th>
                            <th colspan="4"><?php echo $due; ?></th>
                          </tr>
<?php                          
} else {
    echo "No Data";
}
                          ?>
                       
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
                      </div>
                      <div style="background-color:white;" class="tab-pane fade" id="paper" role="tabpanel" aria-labelledby="contact-tab">
                         &nbsp;&nbsp;<a  style="float:right;font-size:20px;padding-left:20px;padding-right:20px;" href='add_paper.php?id=<?php echo $id; ?>' class="btn btn-dark btn-sm">+ إضافة صحيفة جديدة</a><br><br>
                           <div class="col-md-12 col-sm-6  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="float:right;font-size:24px;" style="color:#030345">صحائف الدعوى</h2>
              
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table  dir="rtl" class="table">
                      <thead>
                        <tr>
                          <th>رقم صحيفة</th>
                          <th>صحيفة العنوان</th>
                          <th>تاريخ صحيفة</th>
                              <th>تفاصيل صحيفة</th>
                         
                           
                        </tr>
                      </thead>
                      <tbody>
                     <?php
                          include_once 'connection.php';
                          $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM paper where l_id=".$id;
$paid=0;
$due=0;                          
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
         
       ?>
          <tr><td><?php echo $row["paper_id"]; ?></td>
              <td><?php echo $row["delete_title"]; ?></td>
               <td><?php echo $row["created_at"]; ?></td>
                <td><?php echo $row["detail"]; ?></td>
             
            
                          
                          </tr>                
                          
  <?php  }
} else {
    echo "No Data";
}
                          ?>
                      
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
                      </div>
                         <div style="background-color:white;" class="tab-pane fade" id="number" role="tabpanel" aria-labelledby="contact-tab">
                         &nbsp;&nbsp;<a style="float:right;font-size:20px;padding-left:20px;padding-right:20px;" href='add_number.php?id=<?php echo $id; ?>' class="btn btn-dark btn-sm">+ إضافة رقم جديد</a><br><br>
                           <div class="col-md-12 col-sm-6  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="float:right;font-size:24px;" >أرقام القضية </h2>
              
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table dir="rtl" class="table">
                      <thead>
                        <tr>
                          <th>رقم معرف</th>
                          <th>اسم</th>
                            <th>رقم</th>
                            <th>ملحوظة</th>
                          <th>تاريخ</th>
                         
                              
                           
                        </tr>
                      </thead>
                      <tbody>
                     <?php
                          include_once 'connection.php';
                          $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM numbertbl where l_id=".$id;
$paid=0;
$due=0;                          
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
         
       ?>
          <tr><td><?php echo $row["num_id"]; ?></td>
              <td><?php echo $row["name"]; ?></td>
               <td><?php echo $row["num_number"]; ?></td>
                <td><?php echo $row["note"]; ?></td>
              <td><?php echo $row["created_at"]; ?></td>
              
            
                          
                          </tr>                
                          
  <?php  }
} else {
    echo "No Data";
}
                          ?>
                      
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
                      </div>
                       <div style="background-color:white;" class="tab-pane fade" id="apeal" role="tabpanel" aria-labelledby="contact-tab">
                         &nbsp;&nbsp;<a style="float:right;font-size:20px;padding-left:20px;padding-right:20px;"  href='add_apeal.php?id=<?php echo $id; ?>' class="btn btn-dark btn-sm">+إضافة حكم المحكمةا </a><br><br>
                           <div class="col-md-12 col-sm-6  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="float:right;font-size:24px;" >حكم المحكمة وتاريخ الاستئناف</h2>
              
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table dir="rtl" class="table">
                      <thead>
                        <tr>
                          <th>المعرف الحاكم/th>
                          <th>تاريخ الاستئناف إن وجد</th>
                            <th>تفاصيل حكم المحكمة/th>
                          
                        </tr>
                      </thead>
                      <tbody>
                     <?php
                          include_once 'connection.php';
                          $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM ruling where l_id=".$id;
$paid=0;
$due=0;                          
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
         
       ?>
          <tr><td><?php echo $row["rl_id"]; ?></td>
              <td><?php echo $row["apeal_date"]; ?></td>
               <td><?php echo $row["apeal_detail"]; ?></td>
               
                          </tr>                
                          
  <?php  }
} else {
    echo "No Data";
}
                          ?>
                      
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
                      </div>
                         <div style="background-color:white;" class="tab-pane fade" id="image" role="tabpanel" aria-labelledby="contact-tab">
                         &nbsp;&nbsp;<a style="float:right;font-size:20px;padding-left:20px;padding-right:20px;"  href='add_image.php?id=<?php echo $id; ?>' class="btn btn-dark btn-sm">+اضافة ملف جديد </a><br><br>
                           <div class="col-md-12 col-sm-6  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="float:right;font-size:24px;">صورة وملفات القضية</h2>
              
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table  dir="rtl" class="table">
                      <thead>
                        <tr>
                        <th>معرف الملف</th>
                          <th>اسم الملف</th>
                          <th>عرض ملف</th>
                              <th>تاريخ الإنشاء</th>
                             
                           
                        </tr>
                      </thead>
                      <tbody>
                     <?php
                          include_once 'connection.php';
                          $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM image_file where l_id=".$id;
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
         
       ?>
          <tr><td><?php echo $row["img_id"]; ?></td>
              <td><?php echo $row["fila_name"]; ?></td>
               <td> <a href="upload_image/<?php echo $row["img_loc"]; ?>" alt="Image description" target="_blank"> عرض ملف</a></td>
              
               <td><?php echo $row["created_at"]; ?>  </td>
              
            
                          
                          </tr>           
                          
  <?php  }
} else {
    echo "No Data";
}
                          ?>
                      
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
                      </div>
                     
                    </div>
                  </div>
                </div>
              </div>


            <div class="clearfix"></div>
         
        </div> 
                
                 <?php
                }
            
            ?>
                
                
          
          
          
          
        <footer>
          <div class="pull-right">

          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <div id="custom_notifications" class="custom-notifications dsp_none">
      <ul class="list-unstyled notifications clearfix" data-tabbed_notifications="notif-group">
      </ul>
      <div class="clearfix"></div>
      <div id="notif-group" class="tabbed_notifications"></div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- PNotify -->
    <script src="../vendors/pnotify/dist/pnotify.js"></script>
    <script src="../vendors/pnotify/dist/pnotify.buttons.js"></script>
    <script src="../vendors/pnotify/dist/pnotify.nonblock.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
	
  </body>
</html>