<?php

include_once 'connection.php';
$conn;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{
 
    
        $id=$_POST["user_id"];
    $sql = "UPDATE users SET name='".$_POST["name"]."', email='".$_POST["email"]."', password='".$_POST["password"]."', roll='".$_POST["roll"]."', created_at='".$_POST["created_at"]."' WHERE user_id=".$id;
  
if ($conn->query($sql) === TRUE) {
        header('Location: users.php');
  
} else {
    echo "Error updating record: " . $conn->error;
}
   
 
 

}

$conn->close();
?>