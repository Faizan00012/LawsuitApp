   <?php
if ($_SESSION["lang_option"]==""){
    $_SESSION["lang_option"]="en";
    
}
       
if(isset($_POST['change_submit_ar'])) {
      $_SESSION["lang_option"]="en";
   
}
if(isset($_POST['change_submit_en'])) {
      $_SESSION["lang_option"]="ar";
     
}
 
?>