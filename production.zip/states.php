<?php
include_once 'header_file.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  
    <title>States</title>

    <!-- Bootstrap -->
<?php
    if($_SESSION["lang_option"]=="en"){
        
           ?>
              <link rel="stylesheet" href="navcode1.css">
             <?php
    }
    else{
        
          ?>
              <link rel="stylesheet" href="navcode2.css">
             <?php
    }
    ?>
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
  <link href="../vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
    
        <style>
          
          footer {
    background: #00504d;
    padding: 10px 20px;
    display: block;
}

 .btn-sm{
        padding: 0.28rem 0.8rem;
    font-size: .875rem;
    line-height: 1.5;
    border-radius: 0.15rem;
    }
    body {margin:0;font-family:'Almarai',sans-serif;line-height: 1.2;
   
    font-size: .8rem;}
   .btn-success {
    color: #fff;
    background-color: #10c469;
    border-color: #10c469;
}
.btn-success {
    color: #fff;
    background-color: #10c469;
    border-color: #10c469;
}
.btn-purple {
    color: #fff;
    background-color: #5b69bc;
    border-color: #5b69bc;
}
    .btn-xs {
    padding: 0.2rem 0.6rem;
    font-size: .75rem;
    border-radius: 0.15rem;
}
.btn-danger {
   
    background-color: #ff5b5b;
    border-color: #ff5b5b;
}
      </style>
  </head>

 
         <?php include 'nav.php';  ?>
                            
<?php if(isset($_POST['change_submit'])) {
      $_SESSION["lang_option"]=$_POST["langoption"];}

              if($_SESSION["lang_option"]=="en"){
                  ?>

              <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
          <div class="">
      <a href="add_state.php" class="btn btn-primary btn-sm">+ Add New State</a>
						  
                <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>States </h2>
              
                    <div class="clearfix"></div>
                  </div>
                  <div dir="ltr" class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                   
                    <table id="datatable" class="table table-bordered dataTable no-footer table-sm" style="width:100%; text-align:center;">
                      <thead>
                        <tr>
                          <th style="width: 5%">#</th>
                            <th style="width: 5%">Name AR</th>
                            <th style="width: 5%">Back Color</th>
                         <th style="width: 5%">Name EN</th>
                            <th style="width: 5%">No of Lawsuit</th>
                         
                            <th style="width: 5%">Action</th>
                               <th style="width: 5%">Created At</th>
                           <th style="width: 5%">User</th>
                        </tr>
                      </thead>

 
                               <tbody>
                              <?php
						   
						  
						  
							include_once 'connection.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						  
						  
$sql1="SELECT * from state";
$result = $conn->query($sql1);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
 // <th>Customer ID</th>
                         
  
	   	echo "<tr><td>" . $row["state_id"]. "</td>";
	   echo "<td>" . $row["state_ar"]. "</td>";
        echo "<td style='background-color:".$row["state_backcolor"].";color:white'>" . $row["state_backcolor"]. "</td>";
          echo "<td>" . $row["state_en"]. "</td>";
          echo "<td>" . $row["no_lawsuit"]. "</td>";
     
        
             echo "<td>
    <a  type='button' href='update_state.php?id=".$row["state_id"]."' class='btn btn-secondary  btn-xs'>Edit</a>
    <a  type='button' href='delete_state.php?id=".$row["state_id"]."' class='btn btn-danger btn-xs'>Delete</a></td>";
          echo "<td>" . $row["created_at"]. "</td>";
          echo "<td> Admin</td></tr>";
   

		 
		 
		 
		
		 

		  }
} else {
   
}
						  $conn->close();
   
						?>
                        
                           
                      </tbody>
                        
                    </table>
                  </div>
                  </div>
              </div>
            </div>
                </div>
              </div>

       
            </div>

      
         
          </div>
        </div>
                   <?php
              }
                else
                {
                ?>
             <div dir="ltr" style="width:100%; text-align:right;" lang="ar" class="right_col" role="main"> 
          <div class=""><div class="row">
              <div class="col-md-12 col-sm-12 ">
                  
      <a style="float:right;font-size:20px;padding-left:20px;padding-right:20px;"  href="add_state.php" class="btn btn-primary btn-sm">+ أضف ولاية جديدة</a>
						  
                
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="float:right;font-size:24px;" >حالات القضية : </h2>
              
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                   
                    <table dir="rtl" id="datatable" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th style="width: 5%">#</th>
                            <th style="width: 20%">اسم عربي</th>
                            <th style="width: 20%">اللون الخلفي</th>
                         <th style="width: 20%">اسم انجليزي</th>
                             <th style="width: 20%">عدد  القضائية</th>
                        
                          <th style="width: 20%">تاريخ</th>
                         <th style="width:30%">عمل</th>
                            <th style="width:30%">مستخدم</th>
                    
                        </tr>
                      </thead>

     <tbody>
                              <?php
						   
						  
						  
							include_once 'connection.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						  
						  
$sql1="SELECT * from state";
$result = $conn->query($sql1);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
 // <th>Customer ID</th>
                         
  
	   	echo "<tr><td>" . $row["state_id"]. "</td>";
	   echo "<td>" . $row["state_ar"]. "</td>";
        echo "<td style='background-color:".$row["state_backcolor"].";color:white'>" . $row["state_backcolor"]. "</td>";
          echo "<td>" . $row["state_en"]. "</td>";
          echo "<td>" . $row["no_lawsuit"]. "</td>";
     
        
             echo "<td>
    <a  type='button' href='update_state.php?id=".$row["state_id"]."' class='btn btn-secondary  btn-xs'>تعديل </a>
    <a  type='button' href='delete_state.php?id=".$row["state_id"]."' class='btn btn-danger btn-xs'>حذف </a></td>";
          echo "<td>" . $row["created_at"]. "</td>";
          echo "<td> Admin</td></tr>";
   

		 
		 
		 
		
		 

		  }
} else {
   
}
						  $conn->close();
   
						?>
                        
                           
                      </tbody>
                       
                        
                    </table>
                  </div>
                  </div>
              </div>
            </div>
                </div>
              </div>

       
            </div>

      
         
          </div>
        </div>  
                
                 <?php
                }
            
            ?>
                
                 
        <footer>
          <div class="pull-right">
           </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>
    <!-- jQuery Tags Input -->
    <script src="../vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
    <!-- Switchery -->
    <script src="../vendors/switchery/dist/switchery.min.js"></script>
    <!-- Select2 -->
    <script src="../vendors/select2/dist/js/select2.full.min.js"></script>
    <!-- Parsley -->
    <script src="../vendors/parsleyjs/dist/parsley.min.js"></script>
    <!-- Autosize -->
    <script src="../vendors/autosize/dist/autosize.min.js"></script>
    <!-- jQuery autocomplete -->
    <script src="../vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
    <!-- starrr -->
    <script src="../vendors/starrr/dist/starrr.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
    <script src="../vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="../vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="../vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="../vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="../vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="../vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="../vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="../vendors/jszip/dist/jszip.min.js"></script>
    <script src="../vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="../vendors/pdfmake/build/vfs_fonts.js"></script>
  </body>
</html>
