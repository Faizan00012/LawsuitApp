<?php
include_once 'header_file.php';
     $langoption="en";
$id = $_GET['id'];

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	   
    <title>Customer</title>

    <!-- Bootstrap -->
    <?php
    if($_SESSION["lang_option"]=="en"){
        
           ?>
              <link rel="stylesheet" href="navcode1.css">
             <?php
    }
    else{
        
          ?>
              <link rel="stylesheet" href="navcode2.css">
             <?php
    }
    ?>
 
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
  <link href="../vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
      <style>
          
          footer {
    background: #00504d;
    padding: 10px 20px;
    display: block;
}

 .btn-sm{
        padding: 0.28rem 0.8rem;
    font-size: .875rem;
    line-height: 1.5;
    border-radius: 0.15rem;
    }
    body {margin:0;font-family:'Almarai',sans-serif;line-height: 1.2;
   
    font-size: .8rem;}
   .btn-success {
    color: #fff;
    background-color: #10c469;
    border-color: #10c469;
}
.btn-success {
    color: #fff;
    background-color: #10c469;
    border-color: #10c469;
}
.btn-purple {
    color: #fff;
    background-color: #5b69bc;
    border-color: #5b69bc;
}
      </style>
  </head>
   
    
  
      <?php
       if ($_SESSION["alert"]=="true"){
     echo "<script>alert('".$_SESSION["alert_msg"]."');</script>";
     $_SESSION["alert"]="false";
       }
  include 'nav.php'; ?>
                   
<?php if(isset($_POST['change_submit'])) {
      $_SESSION["lang_option"]=$_POST["langoption"];}

              if($_SESSION["lang_option"]=="en"){
                  ?>

                    <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
          <div class="">
              <h2 style="color:black;">Customers</h2>
      <a href="add_customer.php" class="btn btn-success btn-sm">+ Add New Customer</a>
               <a href="add_customertype.php" class="btn btn-purple btn-sm">+ Add New Customer Type</a>
						  
                <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Settings 1</a>
                            <a class="dropdown-item" href="#">Settings 2</a>
                          </div>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div dir="ltr" class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                   
                    <table id="datatable" class="table table-bordered dataTable no-footer table-sm" style="width:100%;text-align: center;">
                      <thead>
                        <tr>
                          <th>Customer ID</th>
                               <th>Customer Type</th>
                         <th>Name</th>
                            <th>Company</th>
                          
                          <th>Username</th>
                          <th>Phone</th>
                          <th>Address</th>
                             <th>Passport</th>
                             <th style="width:20%">Action</th>
                          
                    
                        </tr>
                      </thead>


                      <tbody>
                              <?php
						   
						  
						  
							include_once 'connection.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						  
						  
$sql1="SELECT c.c_id, c.c_name, c.c_company, c.c_username, c.c_phone, c.c_address, c.c_passport, ct.ct_en from customer c INNER JOIN customer_type ct ON c.ct_id=ct.ct_id where c.c_id=".$id;
$result = $conn->query($sql1);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
 // <th>Customer ID</th>
                         
  
	   	echo "<tr><td><a style='color:blue;' type='button' href='customer_profile.php?id=".$row["c_id"]."' >". $row["c_id"]. "</a></td>";
	   echo "<td>" . $row["ct_en"]. "</td>";
          echo "<td><a style='color:blue;' type='button' href='customer_profile.php?id=".$row["c_id"]."' >" . $row["c_name"]. "</a></td>";
          echo "<td>" . $row["c_company"]. "</td>";
	  echo "<td>" . $row["c_username"]. "</td>";
		echo "<td><a style='color:blue;' type='button' href='https://wa.me/".$row["c_phone"]."' >" . $row["c_phone"]. "</a></td>";
        echo "<td>" . $row["c_address"]. "</td>";
               echo "<td>" . $row["c_passport"]. "</td>";

		 
	 //  echo  "<td class='last'><a style='color:green;' href='Payable_Backend.php?id=".$row["c_id"]."'>Select</a></td>";
	   
       echo "<td>
       <a type='button' style='width:auto;padding: 0.2rem 0.6rem; font-size: .75rem;border-radius: 0.15rem;background-color: #71b6f9; border-color: #71b6f9;' href='customer_profile.php?id=".$row["c_id"]."' class='btn btn-primary btn-sm'><i class='fa fa-eye'></i></a>
       <a  type='button' style='width:auto;padding: 0.2rem 0.6rem; font-size: .75rem;border-radius: 0.15rem;background-color: #10c469; border-color: #10c469;' href='update_customer.php?id=".$row["c_id"]."' class='btn btn-info btn-sm'><i class='fa fa-edit'></i></a>
       <a type='button' style='width:auto;padding: 0.2rem 0.6rem; font-size: .75rem;border-radius: 0.15rem;background-color: #ff5b5b; border-color: #ff5b5b;' href='delete_customer.php?id=".$row["c_id"]."' class='btn btn-danger btn-sm'><i class='fa fa-trash'></i></a></td>
         
       
       </tr>";
     
		
		
		 
		 
		
		 

		  }
} else {
   
}
						  $conn->close();
   
						?>
                        
                           
                      </tbody>
                    </table>
                  </div>
                  </div>
              </div>
            </div>
                </div>
              </div>

       
            </div>

      
         
          </div>
        </div>
          <?php
              }
                else{?>
            <div dir="rtl" style="width:100%; text-align:right; font-size: .8rem;" lang="ar" class="right_col" role="main"> 
 
          <div class="">
						  
                <div class="row">
              <div class="col-md-12 col-sm-12 ">
                  <div class="x_title">
                   <h2 style="float:right;" >العملاء</h2><br><br>
                   </div>
      <a  style="float:right;    padding: 0.3rem;" href="add_customer.php" class="btn btn-success btn-sm">+ إضافة عميل جديد</a>
               <a  style="float:right;" href="add_customertype.php" class="btn btn-purple btn-sm">+ إضافة نوع عميل جديد</a>
                <div class="x_panel">
                  
                   
                    <ul style="float:left"  class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Settings 1</a>
                            <a class="dropdown-item" href="#">Settings 2</a>
                          </div>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                 
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                   
                    <table dir="rtl" id="datatable" class="table table-bordered dataTable no-footer table-sm" style="width:100%;text-align: center;">
                      <thead>
                        <tr>
                          <th>#</th>
                               <th>نوع العميل</th>
                         <th>اسم</th>
                            <th>شركة</th>
                          
                          <th>اسم المستخدم</th>
                          <th>هاتف</th>
                          <th>العنوان</th>
                             <th>جواز سفر</th>
                             <th style="width:20%">عمل</th>
                          
                    
                        </tr>
                      </thead>


                      <tbody>
                              <?php
						   
						  
						  
							include_once 'connection.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						  
						  
$sql1="SELECT c.c_id, c.c_name, c.c_company, c.c_username, c.c_phone, c.c_address, c.c_passport, ct.ct_ar from customer c INNER JOIN customer_type ct ON c.ct_id=ct.ct_id where c.c_id=".$id;
$result = $conn->query($sql1);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
 // <th>Customer ID</th>
                         
  
	   	echo "<tr><td><a style='color:blue;' type='button' href='customer_profile.php?id=".$row["c_id"]."' >". $row["c_id"]. "</a></td>";
	   echo "<td><a style='color:blue;' type='button' href='customer_profile.php?id=".$row["c_id"]."' >" . $row["ct_ar"]. "</a></td>";
          echo "<td><a style='color:blue;' type='button' href='customer_profile.php?id=".$row["c_id"]."' >" . $row["c_name"]. "</a></td>";
          echo "<td>" . $row["c_company"]. "</td>";
	  echo "<td>" . $row["c_username"]. "</td>";
		echo "<td><a style='color:blue;' type='button' href='customer_profile.php?id=".$row["c_id"]."' >" . $row["c_phone"]. "</a></td>";
        echo "<td>" . $row["c_address"]. "</td>";
               echo "<td>" . $row["c_passport"]. "</td>";

		 
 
	   
        echo "<td>
       <a type='button' style='width:auto;padding: 0.2rem 0.6rem; font-size: .75rem;border-radius: 0.15rem;background-color: #71b6f9; border-color: #71b6f9;' href='customer_profile.php?id=".$row["c_id"]."' class='btn btn-primary btn-sm'><i class='fa fa-eye'></i></a>
       <a  type='button' style='width:auto;padding: 0.2rem 0.6rem; font-size: .75rem;border-radius: 0.15rem;background-color: #10c469; border-color: #10c469;' href='update_customer.php?id=".$row["c_id"]."' class='btn btn-info btn-sm'><i class='fa fa-edit'></i></a>
       <a type='button' style='width:auto;padding: 0.2rem 0.6rem; font-size: .75rem;border-radius: 0.15rem;background-color: #ff5b5b; border-color: #ff5b5b;' href='delete_customer.php?id=".$row["c_id"]."' class='btn btn-danger btn-sm'><i class='fa fa-trash'></i></a></td>
       
       </tr>";
     
		
		
		 
		 
		
		 

		  }
} else {
   
}
						  $conn->close();
   
						?>
                        
                           
                      </tbody>
                    </table>
                  </div>
                  </div>
              </div>
            </div>
                </div>
              </div>

       
            </div>

      
         
          </div>
        </div>     
          <?php
                }
            
            ?>

        <!-- /top navigation -->
  
          
        
       
             
          
        <!-- /page content -->

        <!-- footer content -->
        <footer style="">
          <div class="pull-right">
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>
    <!-- jQuery Tags Input -->
    <script src="../vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
    <!-- Switchery -->
    <script src="../vendors/switchery/dist/switchery.min.js"></script>
    <!-- Select2 -->
    <script src="../vendors/select2/dist/js/select2.full.min.js"></script>
    <!-- Parsley -->
    <script src="../vendors/parsleyjs/dist/parsley.min.js"></script>
    <!-- Autosize -->
    <script src="../vendors/autosize/dist/autosize.min.js"></script>
    <!-- jQuery autocomplete -->
    <script src="../vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
    <!-- starrr -->
    <script src="../vendors/starrr/dist/starrr.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
    <script src="../vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="../vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="../vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="../vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="../vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="../vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="../vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="../vendors/jszip/dist/jszip.min.js"></script>
    <script src="../vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="../vendors/pdfmake/build/vfs_fonts.js"></script>
  </body>
</html>
