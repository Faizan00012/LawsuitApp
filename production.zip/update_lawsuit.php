<?php
include_once 'header_file.php';
include_once 'connection.php';
$conn;
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  
    <title>Update Lawsuit</title>

    <!-- Bootstrap -->
<?php
    if($_SESSION["lang_option"]=="en"){
        
           ?>
              <link rel="stylesheet" href="navcode1.css">
             <?php
    }
    else{
        
          ?>
              <link rel="stylesheet" href="navcode2.css">
             <?php
    }
    ?>
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
         <?php include 'nav.php';  ?>
        <!-- /top navigation -->

        <!-- page content -->
          <?php 
                    $conn = new mysqli($servername, $username, $password, $dbname);
                    $l_id = $_GET['id'];
                    $sql1="SELECT * from lawsuit where l_id= {$l_id}";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {
                $amount_contact=$row["amount_contact"];
                $tax=$row["tax"];
                $total_amount=$row["total_amount"];
                $location=$row["location"];
                $created_at=$row["created_at"];
                $contract_preamble_ar=$row["contract_preamble_ar"];
                $contract_preamble_en=$row["contract_preamble_en"];
                $fee_detail_ar=$row["fee_detail_ar"];
                $fee_detail_en=$row["fee_detail_en"];
                $contact_ar=$row["contact_ar"];
                $contract_en=$row["contract_en"];
                $note=$row["note"];
                 
                 
     
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                 $langoption=$_POST["langoption"];
                }
              if($langoption=="en"){
                  ?>
                  
                     <form action="update_lawsuit_backend.php" method="post">
              
       <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
 
           
                    <div class="col-md-12 ">
              
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Update Lawsuit </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div dir="ltr" class="x_content">
                    <br />
                    

                     
                      <div class="col-md-3 col-sm-6  form-group">
                          <label>Opponent Name</label>
                    <input type="text" name="opp_name" value="<?php echo $row["opp_name"]; ?>" class="form-control" id="inputSuccess2" placeholder="Opponent Name">
                          <input type="hidden" value="<?php echo $row['l_id']; ?>" name="l_id">
                      </div>
                      <div class="col-md-3 col-sm-6  form-group">
                          <label>Opponent Phone</label>
                    <input type="text" value="<?php echo $row["opp_contact"]; ?>" name="opp_phone" class="form-control" id="inputSuccess2" placeholder="Opponent Phone">
                      </div>
                      <div class="col-md-3 col-sm-6  form-group">
                          <label>Opponent Nationality</label>
                    <input type="text" value="<?php echo $row["opp_nationality"]; ?>" name="opp_nationality" class="form-control" id="inputSuccess2" placeholder="Opponent Nationality">
                      </div>
                      <div class="col-md-3 col-sm-6  form-group">
                          <label>Opponent Address</label>
                    <input type="text" value="<?php echo $row["opp_address"]; ?>" name="opp_address" class="form-control" id="inputSuccess2" placeholder="Opponent Address">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                          <label>Opponent Lawyer</label>
                    <input type="text" value="<?php echo $row["opp_lawyer"]; ?>" name="opp_lawyer" class="form-control" id="inputSuccess2" placeholder="Opponent Lawyer">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                          <label>Opponent  Lawyer Phone</label>
                    <input type="text" value="<?php echo $row["opp_lawyer_contact"]; ?>" name="opp_lawyerphone" class="form-control" id="inputSuccess2" placeholder="Opponent Lawyer Phone">
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                   <h4 style="color:red;">Lawsuit and Contract Data</h4>
                      </div>
                      
                        <div class="col-md-6 col-sm-6  form-group">
                            <label>Lawsuit Lawyer</label>
                    <input type="text" value="<?php echo $row["lawyer"]; ?>"  name="ls_lawyer" class="form-control" id="inputSuccess2" placeholder="Lawsuit Lawyer">
                      </div>
                        <div class="col-md-6 col-sm-6  form-group">
                            <label>Subject Lawsuit</label>
                    <input type="text" value="<?php echo $row["subject"]; ?>"  name="ls_subject" class="form-control" id="inputSuccess2" placeholder="Subject Lawsuit">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                            <label>Consultant</label>
                    <input type="text" required="required" value="<?php echo $row["consultant"]; ?>"   name="ls_consultant" class="form-control" id="inputSuccess2" placeholder="Consultant Lawsuit">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                            <label>Assistant</label>
                    <input type="text" required="required" value="<?php echo $row["assistant"]; ?>"   name="ls_assistant" class="form-control" id="inputSuccess2" placeholder="Assistant Lawsuit">
                      </div>
                         
                          <div class="col-md-6 col-sm-6  form-group">
                                <label>Select Stage</label>
                    <select class="form-control" name="ls_stage">
                            
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql4="SELECT * from stage";
                    $result = $conn->query($sql4);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["stage_id"]."'>".$row["stage_en"]."</option>";
             }}  ?>
                            </select>
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                            <label>Select State</label>
                    <select class="form-control" name="ls_state">
                          
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql5="SELECT * from state";
                    $result = $conn->query($sql5);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["state_id"]."'>".$row["state_en"]."</option>";
             }} ?>
                            </select>
                      </div>
                         
                         
                         
                         
                      <div class="col-md-6 col-sm-6  form-group">
                          <label>Amount Contract</label>
                    <input type="text" value="<?php echo $amount_contact; ?>"  name="ls_amount" class="form-control" id="amount" placeholder="Amount Contract">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                          <label>Tax Value%</label>
                    <input type="text" value="<?php echo $tax; ?>"  name="ls_tax" class="form-control" id="tax" placeholder="Tax Value%">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                          <label>Amount includ Tax</label>
                    <input type="text" value="<?php echo $total_amount; ?>"  name="ls_total" class="form-control" id="total" placeholder="Amount includ Tax">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                          <label>Lawsuit location</label>
                    <input type="text" value="<?php echo $location; ?>"  name="ls_location" class="form-control" id="inputSuccess2" placeholder="Lawsuit location">
                      </div>
                     
                        <div class="col-md-12 col-sm-6  form-group">
                            <label>created_at</label>
                    <input type="date" value="<?php echo $created_at; ?>"  name="created_at" class="form-control" id="inputSuccess2" placeholder="">
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                   <h4 style="color:red;">Contract Preamble</h4>
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                           <label>Contract Preamble AR</label>
                        <textarea placeholder=""  name="cp_ar" class="form-control" style="width:100%;height:100px"><?php echo $contract_preamble_ar; ?></textarea>
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                           <label>Contract Preamble EN</label>
                        <textarea placeholder="" name="cp_en" class="form-control" style="width:100%;height:100px"><?php echo $contract_preamble_en; ?></textarea>
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                   <h4 style="color:red;">Fee and Payments Details</h4>
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                           <label>Fee and Payments Details AR</label>
                        <textarea placeholder="Fee and Payments Details AR" name="fee_ar" class="form-control" style="width:100%;height:100px"><?php echo $fee_detail_ar; ?></textarea>
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                          <label>Fee and Payments Details EN</label>
                        <textarea placeholder="Fee and Payments Details EN" name="fee_en" class="form-control" style="width:100%;height:100px"><?php echo $fee_detail_en; ?></textarea>
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                   <h4 style="color:red;">Contract Terms</h4>
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                           <label>Contract Terms AR</label>
                        <textarea placeholder="Contract Terms AR" name="contract_ar" class="form-control" style="width:100%;height:100px"><?php echo $contact_ar; ?></textarea>
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                          <label>Contract Terms EN</label>
                        <textarea placeholder="Contract Terms EN" name="contract_en" class="form-control" style="width:100%;height:100px"><?php echo $contract_en; ?></textarea>
                      </div>
                         <div class="col-md-12 col-sm-6  form-group">
                   <h4 style="color:red;">Note</h4>
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                           
                        <textarea name="note" class="form-control" style="width:100%;height:100px"><?php echo $note; ?></textarea>
                      </div>
                      
                           </div>
                     <div class="form-group row">
                        
                        <div class="col-md-12 col-sm-2  offset-md-4"><br>
                          <button  type="submit" name="submit" class="btn btn-success">Update Lawsuit </button>
                        </div>
                      </div>

                 
                  </div>
                </div>
                
    
 
              
 <div class="clearfix"></div>

          
              
            </div>

            
           </form>  
                   <?php
              }
                else
                {
                ?>
              <form action="update_lawsuit_backend.php" method="post">
              
        <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
 
           
                    <div class="col-md-12 ">
              
                <div class="x_panel">
                  <div class="x_title">
                    <h2>تحديث الدعوى </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
                    

                     
                      <div class="col-md-3 col-sm-6  form-group">
                          <label>اسم الخصم</label>
                    <input type="text" name="opp_name" value="<?php echo $row["opp_name"]; ?>" class="form-control" id="inputSuccess2" placeholder="Opponent Name">
                          <input type="hidden" value="<?php echo $row['l_id']; ?>" name="l_id">
                      </div>
                      <div class="col-md-3 col-sm-6  form-group">
                          <label>هاتف الخصم</label>
                    <input type="text" value="<?php echo $row["opp_contact"]; ?>" name="opp_phone" class="form-control" id="inputSuccess2" placeholder="Opponent Phone">
                      </div>
                      <div class="col-md-3 col-sm-6  form-group">
                          <label>جنسية الخصم</label>
                    <input type="text" value="<?php echo $row["opp_nationality"]; ?>" name="opp_nationality" class="form-control" id="inputSuccess2" placeholder="Opponent Nationality">
                      </div>
                      <div class="col-md-3 col-sm-6  form-group">
                          <label>عنوان الخصم</label>
                    <input type="text" value="<?php echo $row["opp_address"]; ?>" name="opp_address" class="form-control" id="inputSuccess2" placeholder="Opponent Address">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                          <label>المحامي الخصم</label>
                    <input type="text" value="<?php echo $row["opp_lawyer"]; ?>" name="opp_lawyer" class="form-control" id="inputSuccess2" placeholder="Opponent Lawyer">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                          <label>هاتف المحامي الخصم</label>
                    <input type="text" value="<?php echo $row["opp_lawyer_contact"]; ?>" name="opp_lawyerphone" class="form-control" id="inputSuccess2" placeholder="Opponent Lawyer Phone">
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                   <h4 style="color:red;">بيانات الدعوى والعقود</h4>
                      </div>
                      
                        <div class="col-md-6 col-sm-6  form-group">
                            <label>محامي دعوى</label>
                    <input type="text" value="<?php echo $row["lawyer"]; ?>"  name="ls_lawyer" class="form-control" id="inputSuccess2" placeholder="Lawsuit Lawyer">
                      </div>
                        <div class="col-md-6 col-sm-6  form-group">
                            <label>موضوع الدعوى</label>
                    <input type="text" value="<?php echo $row["subject"]; ?>"  name="ls_subject" class="form-control" id="inputSuccess2" placeholder="Subject Lawsuit">
                      </div>
                       <div class="col-md-6 col-sm-6  form-group">
                    <input type="text" required="required" value="<?php echo $row["consultant"]; ?>"  name="ls_consultant" class="form-control" id="inputSuccess2" placeholder="مستشار القضية">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                    <input type="text" required="required" value="<?php echo $row["assistant"]; ?>"  name="ls_assistant" class="form-control" id="inputSuccess2" placeholder="مساعد القضية">
                      </div>
                       <div class="col-md-6 col-sm-6  form-group">
                                <label>حالة القضية</label>
                    <select class="form-control" name="ls_stage">
                            
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from stage";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["stage_id"]."'>".$row["stage_ar"]."</option>";
             }} else {}?>
                            </select>
                      </div>
                      
                      <div class="col-md-6 col-sm-6  form-group">
                            <label>مرحلة التقاضي</label>
                    <select class="form-control" name="ls_state">
                          
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from state";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["state_id"]."'>".$row["state_ar"]."</option>";
             }} else {}?>
                            </select>
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                          <label>عقد المبلغ</label>
                    <input type="text" value="<?php echo $amount_contact; ?>"  name="ls_amount" class="form-control" id="amount" placeholder="Amount Contract">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                          <label>قيمة الضريبة ٪</label>
                    <input type="text" value="<?php echo $tax; ?>"  name="ls_tax" class="form-control" id="tax" placeholder="Tax Value%">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                          <label>Amount including Tax</label>
                    <input type="text" value="<?php echo $total_amount; ?>"  name="ls_total" class="form-control" id="total" placeholder="Amount includ Tax">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                          <label>موقع الدعوى</label>
                    <input type="text" value="<?php echo $location; ?>"  name="ls_location" class="form-control" id="inputSuccess2" placeholder="Lawsuit location">
                      </div>
                     
                        <div class="col-md-12 col-sm-6  form-group">
                            <label>أنشئت في</label>
                    <input type="date" value="<?php echo $created_at; ?>"  name="created_at" class="form-control" id="inputSuccess2" placeholder="">
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                   <h4 style="color:red;">ديباجة العقد</h4>
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                           <label>مقدمة العقد باللغة العربية</label>
                        <textarea placeholder=""  name="cp_ar" class="form-control" style="width:100%;height:100px"><?php echo $contract_preamble_ar; ?></textarea>
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                           <label>مقدمة العقد باللغة الإنجليزية</label>
                        <textarea placeholder="" name="cp_en" class="form-control" style="width:100%;height:100px"><?php echo $contract_preamble_en; ?></textarea>
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                   <h4 style="color:red;">تفاصيل الرسوم والمدفوعات</h4>
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                           <label>تفاصيل الرسوم والمدفوعات باللغة العربية</label>
                        <textarea placeholder="Fee and Payments Details AR" name="fee_ar" class="form-control" style="width:100%;height:100px"><?php echo $fee_detail_ar; ?></textarea>
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                          <label>تفاصيل الرسوم والمدفوعات باللغة الإنجليزية</label>
                        <textarea placeholder="Fee and Payments Details EN" name="fee_en" class="form-control" style="width:100%;height:100px"><?php echo $fee_detail_en; ?></textarea>
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                   <h4 style="color:red;">شروط العقد</h4>
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                           <label>شروط العقد باللغة العربية</label>
                        <textarea placeholder="Contract Terms AR" name="contract_ar" class="form-control" style="width:100%;height:100px"><?php echo $contact_ar; ?></textarea>
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                          <label>شروط العقد باللغة الإنجليزية</label>
                        <textarea placeholder="Contract Terms EN" name="contract_en" class="form-control" style="width:100%;height:100px"><?php echo $contract_en; ?></textarea>
                      </div>
                         <div class="col-md-12 col-sm-6  form-group">
                   <h4 style="color:red;">ملحوظة</h4>
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                           
                        <textarea name="note" class="form-control" style="width:100%;height:100px"><?php echo $note; ?></textarea>
                      </div>
                      
                           </div>
                     <div class="form-group row">
                        
                        <div class="col-md-12 col-sm-2  offset-md-4"><br>
                          <button  type="submit" name="submit" class="btn btn-success">تحديث الدعوى </button>
                        </div>
                      </div>

                 
                  </div>
                </div>
                
    
 
              
 <div class="clearfix"></div>

          
              
            </div>

            
           </form> 
                
                 <?php
                }
            
            
                }} else {} $conn->close();?>
          
        </div>
      
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
           
        </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
     

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>
    <!-- jQuery Tags Input -->
    <script src="../vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
    <!-- Switchery -->
    <script src="../vendors/switchery/dist/switchery.min.js"></script>
    <!-- Select2 -->
    <script src="../vendors/select2/dist/js/select2.full.min.js"></script>
    <!-- Parsley -->
    <script src="../vendors/parsleyjs/dist/parsley.min.js"></script>
    <!-- Autosize -->
    <script src="../vendors/autosize/dist/autosize.min.js"></script>
    <!-- jQuery autocomplete -->
    <script src="../vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
    <!-- starrr -->
    <script src="../vendors/starrr/dist/starrr.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
	
  </body>
</html>
