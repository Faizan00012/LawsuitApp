<?php
include_once 'connection.php';
$conn;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{
 
        $id=$_POST["ct_id"];
    $sql = "UPDATE customer_type SET ct_ar='".$_POST["name_ar"]."', ct_en='".$_POST["name_en"]."' WHERE ct_id=".$id;
  
if ($conn->query($sql) === TRUE) {
        header('Location: customertype.php');
  
} else {
    echo "Error updating record: " . $conn->error;
}
   
 
 

}

$conn->close();
?>