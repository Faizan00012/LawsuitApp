<?php
include_once 'header_file.php';
include_once 'connection.php';
$conn;
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  
     <title>Add Customer</title>
  <?php
    if($_SESSION["lang_option"]=="en"){
        
           ?>
              <link rel="stylesheet" href="navcode1.css">
             <?php
    }
    else{
        
          ?>
              <link rel="stylesheet" href="navcode2.css">
             <?php
    }
    ?>
    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  
 <?php include 'nav.php';  ?>
         
                       
<?php if(isset($_POST['change_submit'])) {
      $_SESSION["lang_option"]=$_POST["langoption"];}

              if($_SESSION["lang_option"]=="en"){
                  ?>

                  
                      <form action="" method="post">
           <div dir="" style="width:100%" lang="ar" class="right_col" role="main">
 
            <div class="clearfix"></div>
            
                  <a href="customer.php" class="btn btn-dark btn-sm">Customer</a>
                   <div class="col-md-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Add New Customer </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div dir="ltr" class="x_content">
                    <br />
                   

                        <div class="col-md-4 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_name" class="form-control" id="inputSuccess2" placeholder="Name">
                      </div>
                      <div class="col-md-8 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_company" class="form-control" id="inputSuccess2" placeholder="Company Name">
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_passport" class="form-control" id="inputSuccess2" placeholder="ID No. passport No.">
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_cr" class="form-control" id="inputSuccess2" placeholder="CR.No">
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_city" class="form-control" id="inputSuccess2" placeholder="City">
                      </div>
                      <div class="col-md-8 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_address" class="form-control" id="inputSuccess2" placeholder="Address">
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_post" class="form-control" id="inputSuccess2" placeholder="Post Box">
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                    <input type="text" required="required" required="required" name="cus_phone" class="form-control" id="inputSuccess2" placeholder="Telephone No">
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                    <input type="text" required="required" required="required" name="cus_mobile" class="form-control" id="inputSuccess2" placeholder="Mobile No">
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                    <input type="text" required="required" required="required" name="cus_email" class="form-control" id="inputSuccess2" placeholder="Email">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_nationality" class="form-control" id="inputSuccess2" placeholder="Nationality">
                      </div>
                           <div class="col-md-6 col-sm-6  form-group">
                            <select class="form-control" name="ct_id">
                             <option>Select Customer Type</option>
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from customer_type";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["ct_id"]."'>".$row["ct_en"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                     </div>
                      <div class="col-md-6 col-sm-6  form-group">
                    <input  required="required" type="text" name="cus_username" class="form-control" id="inputSuccess2" placeholder="User Name">
                      </div>
                       <div class="col-md-6 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_password" class="form-control" id="inputSuccess2" placeholder="Password">
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                   
                           <textarea placeholder="Note" name="cus_note" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                     <div class="form-group row">
                        <div class="col-md-6 col-sm-9  offset-md-4"><br>
                          <button style="width:30%" type="submit" name="submit" class="btn btn-success">Add Customer</button>
                        </div>
                      </div>

                     
                  </div>
                </div>
 
              


              </div>
              
            </div>

            
           </form>
                   <?php
              }
                else
                {
                ?>
                 <form style="font-size:20px;" action="" method="post">

         <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
 
 
            <div class="clearfix"></div>
            
                   <div class="col-md-12 ">
                          <a style="float:right;font-size:20px;padding-left:20px;padding-right:20px;" href="customer.php" class="btn btn-dark btn-sm">عميل </a>
                
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="float:right;font-size:24px;">إضافة عميل جديد </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div dir="rtl" class="x_content">
                    <br />
                   

                        <div class="col-md-4 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_name" class="form-control" id="inputSuccess2" placeholder="الاسم">
                      </div>
                      <div class="col-md-8 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_company" class="form-control" id="inputSuccess2" placeholder="الاسم 
اسم الشركة">
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_passport" class="form-control" id="inputSuccess2" placeholder="رقم الإقامة / الهوية/ جواز السفر">
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_cr" class="form-control" id="inputSuccess2" placeholder="رقم السجل التجاري">
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_city" class="form-control" id="inputSuccess2" placeholder="المدينة">
                      </div>
                      <div class="col-md-8 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_address" class="form-control" id="inputSuccess2" placeholder="العنوان">
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_post" class="form-control" id="inputSuccess2" placeholder="صندوق البريد">
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_phone" class="form-control" id="inputSuccess2" placeholder="رقم الهاتف">
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_mobile" class="form-control" id="inputSuccess2" placeholder="رقم الجوال">    
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_email" class="form-control" id="inputSuccess2" placeholder="الإيميل">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_nationality" class="form-control" id="inputSuccess2" placeholder="الجنسية">
                      </div>
                           <div class="col-md-6 col-sm-6  form-group">
                            <select class="form-control" name="ct_id">
                             <option>اسم المستخدم</option>
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from customer_type";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["ct_id"]."'>".$row["ct_en"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                     </div>
                      <div class="col-md-6 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_username" class="form-control" id="inputSuccess2" placeholder="اسم االمستخدم">
                      </div>
                       <div class="col-md-6 col-sm-6  form-group">
                    <input type="text" required="required" name="cus_password" class="form-control" id="inputSuccess2" placeholder="كلمة المرورر">
                      </div>
                       <div class="col-md-12 col-sm-6  form-group">
                   
                           <textarea placeholder="ملاحظات" name="cus_note" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                     <div class="form-group row">
                        <div class="col-md-12 col-sm-9  offset-md-4"><br>
                          <button style="width:30%" type="submit" name="submit" class="btn btn-success">إضافة</button>
                        </div>
                      </div>

                     
                  </div>
                </div>
 
              


              </div>
              
            </div>

            
           </form>
                
                 <?php
                }
            
            ?>
                
                
          
          
       
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>
    <!-- jQuery Tags Input -->
    <script src="../vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
    <!-- Switchery -->
    <script src="../vendors/switchery/dist/switchery.min.js"></script>
    <!-- Select2 -->
    <script src="../vendors/select2/dist/js/select2.full.min.js"></script>
    <!-- Parsley -->
    <script src="../vendors/parsleyjs/dist/parsley.min.js"></script>
    <!-- Autosize -->
    <script src="../vendors/autosize/dist/autosize.min.js"></script>
    <!-- jQuery autocomplete -->
    <script src="../vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
    <!-- starrr -->
    <script src="../vendors/starrr/dist/starrr.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
	
  </body>
</html>
 <?php
include_once 'connection.php';
$conn;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{
 
 
    
   
   $sql = "INSERT INTO customer (c_name, c_company, c_passport, c_cr, c_city, c_address, c_postbox, c_phone, c_mobile, c_email, c_nationality, c_username, c_password, c_notes, roll, ct_id)
VALUES ('".$_POST["cus_name"]."','".$_POST["cus_company"]."','".$_POST["cus_passport"]."','".$_POST["cus_cr"]."','".$_POST["cus_city"]."','".$_POST["cus_address"]."','".$_POST["cus_post"]."','".$_POST["cus_phone"]."','".$_POST["cus_mobile"]."','".$_POST["cus_email"]."','".$_POST["cus_nationality"]."','".$_POST["cus_username"]."','".$_POST["cus_password"]."','".$_POST["cus_note"]."', 17,'".$_POST["ct_id"]."')";
 
if ($conn->query($sql) === TRUE) {
  echo "New Customer Added";
}else{
	echo "New Customer Not Added";
} 

}

$conn->close();
?>