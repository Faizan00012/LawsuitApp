<?php
session_start();
include_once 'connection.php';
$conn;
$conn = new mysqli($servername, $username, $password, $dbname);
               if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                } 

$sql = "INSERT INTO track_end (user_id) VALUES ('".$_SESSION["user_id"]."')";

if ($conn->query($sql) === TRUE) {
     header('Location: login.php');
} else {
}
mysqli_close($conn);

?>
