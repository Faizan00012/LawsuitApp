<?php
$lw_id = $_GET['id'];
	include_once 'connection.php';
			  $conn;
$owner_office="";
$owner_lic="";
$owner_tax_no="";
$owner_address="";
$owner_mobile="";
$owner_email="";
$client_name="";
$client_address="";
$client_mobile="";
$client_email="";
$owner_office="";
$owner_logo="";
$owner_header="";
 
                         
?>
<!DOCTYPE html>
<!-- saved from url=(0065)https://demo-ar-en.mueen-law.com/en/consultation/print_contract/4 -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <title>Report</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Coderthemes" name="author">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <style>body,h1,h2,h3,h4,h5,h6,p{font-family:Calibri,serif}body{font-size:22px;color:#0b0b0b;text-align:right;direction:rtl}ul{padding-right:20px}</style>

</head>

    <body>
         <div style="background-color: #fafafa;padding:50px;">
         <div>
                         
         <?php   
      $conn = new mysqli($servername, $username, $password, $dbname);
      if ($conn->connect_error) {
           die("Connection failed: " . $conn->connect_error);
       } 
      $sql = "SELECT * from settings";
 
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $owner_office=$row["Office_Name"];
$owner_lic=$row["id_no"];
$owner_tax_no=$row["tax_no"];
$owner_address=$row["address"];
$owner_mobile=$row["mobile"];
$owner_email=$row["email"];
$owner_office=$row["Office_Name"];
$owner_logo=$row["set_logo"];
$owner_header=$row["set_header"];

       ?>
        <div style="text-align: center;">
                                      <table style="width:100%"><tr>
              <td style="text-align:center;">  <img style="width:100%;" src="uploads/<?php echo $owner_header; ?>"></td>
            </tr></table>
 
                                      
                                    <h3 style="">عقد خدمات قانونية وأتعاب محاماة</h3>
                                  
                                </div>
    
    <?php
  
  
         }
} else {
    echo "No Consultation results";
}
     $sql = "SELECT * from lawsuit lw INNER JOIN customer c ON lw.c_id=c.c_id where lw.l_id=".$lw_id;
 
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
       ?>
        
                
                                

                                <div style="float: left;padding: 10px;">
                                  
                                        <strong> تاريخ العقد : </strong>
                                        <?php echo $row["created_at"]; ?>
                                  
                                </div>

                                <div style="float-right;padding: 10px;">
                                    <p><strong> رقم العقد : </strong> <?php echo $row["l_id"]; ?></p>
                                </div>

                            </div>
                       

                        <div class="">
                            <div style="padding: 10px;">
                                <p style="font-size: 22px; font-family: Calibri,serif; !important; line-height: 30px; color: #0b0b0b ">
                                   بعون الله وتوفيقه في يوم : <?php echo $row["created_at"]; ?> تم توقيع هذا العقد، بين كل من:
                                    <br>
                                    1- : مكتب :
                                    المحامي منير بن صالح الجهني
                                    - ترخيص محاماة رقم :
                                    <?php echo $owner_lic; ?>
                                    -
                                    رقم ضريبي لضريبة القيمة المضافة :
                                      <?php echo $owner_tax_no; ?>
                                   <br>
                                    
                                    عنوان المكتب الرئيسي :
                                    <?php echo $owner_address; ?>
                                    -
                                    ويمثله في هذا العقد المحامي :
                                    <?php echo $owner_office; ?>
                                    بصفته صاحب المكتب
                                    -
                                    بريد إلكتروني :
                                    <?php echo $owner_email; ?>
                                    -
                                    جوال :
                                    <?php echo $owner_mobile; ?>
                                    ( طرف أول )
                                      <br>

                                     
                                    2 - :
                                    <?php echo $row["c_name"]; ?>
                                    هوية رقم :
                                    <?php echo $row["c_passport"]; ?>
                                    جوال رقم :
                                    <?php echo $row["c_phone"]; ?>
                                    <br>
                                    Address :
                                    <?php echo $row["c_address"]; ?>
                                    ( طرف ثاني )
                                    <br>
                                </p>
                                 <h4 class="font-weight-bold"> مقدمة العقد :</h4>
                                <p style="font-size: 22px; font-family: Calibri,serif; !important; line-height: 33px; color: #0b0b0b ">
                                    بما أن الطرف الأول مكتب مختص في المحاماة والاستشارات الشرعية والنظامية وبما أن الطرف الثاني
                                    <br>
                                    
                                    
                                </p>
                                  <p style="font-size: 22px; font-family: Calibri,serif; !important; line-height: 33px; color: #0b0b0b ">
                                    لذا فقد اتفق الطرفان -بعد أن أقرا بأهليتهما النظامية والشرعية للتعاقد والتصرف على تحرير هذا العقد وفقاً للشروط التالية:
                                    <br>
                                    البند الأول/ مقدمة هذا العقد جزء لا يتجزأ منه
                                    <br>
                                    البند الثاني/ موضوع العقد:
                                    <br>
                                    بموجب هذا العقد قام الطرف الثاني بتوكيل الطرف الأول وكيلاً شرعيا يتولى الأمور القانونية والقضائية العائدة للطرف الثاني بالترافع لدى الجهات النظامية والشرعية في المطالبات المشار إليها مقدمة العقد.
                                </p>
                                
 
                                
                                <p style="font-size: 22px; font-family: Calibri,serif; !important; line-height: 30px; color: #0b0b0b ">
                                    
                                </p>

                            </div>
                        </div>

                        <div calss="">
                            <table style="width: 100%; text-align: center; font-weight: bold">
                                <tbody><tr>
                                    <td width="50%">الطرف الأول</td>
                                    <td width="50%">الطرف الثاني</td>
                                </tr>
                                <tr>
                                    <td>
                                        <?php echo $owner_office ?>
                                        <br>
                                        <br>
                                        <small>
                                        ----------------------------------
                                        </small>
                                    </td>
                                    <td>
                                        <?php echo $row["c_name"]; ?>
                                        <br>
                                        <br>
                                        <small>
                                            ----------------------------------
                                        </small>
                                    </td>
                                </tr>
                            </tbody></table>
                        </div></div>
                           <div style="float:right;color:#0b0b0b;">
            <button onclick="window.print()"><i class="fa fa-print" style="font-size:24px"></i></button><br><br><br></div>
 
                   <?php
  
  
         }
} else {
    echo "No Consultation results";
}
             ?>
 
            
    

</body></html>