<?php
include_once 'header_file.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  
  <title>Lawsuit</title>

    <!-- Bootstrap -->
   <?php
    if($_SESSION["lang_option"]=="en"){
        
           ?>
              <link rel="stylesheet" href="navcode1.css">
             <?php
    }
    else{
        
          ?>
              <link rel="stylesheet" href="navcode2.css">
             <?php
    }
    ?>
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
  <link href="../vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
    
    <style>
          
          footer {
    background: #00504d;
    padding: 10px 20px;
    display: block;
}

 .btn-sm{
        padding: 0.28rem 0.8rem;
    font-size: .875rem;
    line-height: 1.5;
    border-radius: 0.15rem;
    }
    .btn-xs {
    padding: 0.2rem 0.6rem;
    font-size: .75rem;
    border-radius: 0.15rem;
}
    body {margin:0;font-family:'Almarai',sans-serif;line-height: 1.2;
   
    font-size: .8rem;}
   .btn-success {
    color: #fff;
    background-color: #10c469;
    border-color: #10c469;
}
.btn-success {
    color: #fff;
    background-color: #10c469;
    border-color: #10c469;
}
.btn-purple {
    color: #fff;
    background-color: #5b69bc;
    border-color: #5b69bc;
}
.btn-danger
{
    background-color: #ff5b5b;
    border-color: #ff5b5b;
    
}
      </style>
         <script>
function selectElementContents(el) {
	var body = document.body, range, sel;
	if (document.createRange && window.getSelection) {
		range = document.createRange();
		sel = window.getSelection();
		sel.removeAllRanges();
		try {
			range.selectNodeContents(el);
			sel.addRange(range);
		} catch (e) {
			range.selectNode(el);
			sel.addRange(range);
		}
	} else if (body.createTextRange) {
		range = body.createTextRange();
		range.moveToElementText(el);
		range.select();
	}
}
          
          function exportTableToExcel(tableID, filename = ''){
    var downloadLink;
    var dataType = 'application/vnd.ms-excel';
    var tableSelect = document.getElementById(tableID);
    var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
    
    // Specify file name
    filename = filename?filename+'.xls':'excel_data.xls';
    
    // Create download link element
    downloadLink = document.createElement("a");
    
    document.body.appendChild(downloadLink);
    
    if(navigator.msSaveOrOpenBlob){
        var blob = new Blob(['\ufeff', tableHTML], {
            type: dataType
        });
        navigator.msSaveOrOpenBlob( blob, filename);
    }else{
        // Create a link to the file
        downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
    
        // Setting the file name
        downloadLink.download = filename;
        
        //triggering the function
        downloadLink.click();
    }
}
      </script>
  </head>

 
       <?php include 'nav.php';  ?>
        
                                
<?php if(isset($_POST['change_submit'])) {
      $_SESSION["lang_option"]=$_POST["langoption"];}

              if($_SESSION["lang_option"]=="en"){
                  ?>

          
          
           <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
          <div class="">
                 <h2>Lawsuit</h2>
      <a href="add_lawsuit.php" class="btn btn-primary btn-sm">+ Add New Lawsuit</a>
               <a href="add_lawsuittype.php" class="btn btn-dark btn-sm">+ Add New Lawsuit Type</a>
              <a href="add_customer.php" class="btn btn-danger btn-sm">+ Add New Customer</a>
              <a href="add_customertype.php" class="btn btn-success btn-sm">+ Add New Customer Type</a>
						  
                <div class="row">
                 
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    
                         <button style="color:white" onclick="selectElementContents( document.getElementById('datatable') );" class="btn btn-dark btn-sm">Copy</button>
                       <button style="color:white" onclick="exportTableToExcel('datatable', 'lawsuit')" class="btn btn-dark btn-sm">Export</button>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Settings 1</a>
                            <a class="dropdown-item" href="#">Settings 2</a>
                          </div>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div dir="ltr" class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                   
                    <table dir="ltr" id="datatable" class="table table-striped table-bordered table-sm" style="width:100%;text-align:center;">
                      <thead>
                        <tr>
                                     <th style="width:10%">Lawsuit File Number</th>
                       <th style="width:10%">Branch</th>
                          <th style="width:14%">Customer</th>
                        <th style="width:14%">Customer Type</th>
                           <th style="width:14%">Lawsuit Type</th>
                               <th style="width:14%">Stage</th>
                            <th style="width:14%">Location</th>
                           <th style="width:14%">Number of Sessions</th>
                          <th style="width:14%">Amount</th>
                          <th style="width:14%">Tax Amount</th>
                              <th style="width:14%">Total Amount Incl Tax</th>
                           <th style="width:14%">Amount Paid</th>
                           <th style="width:14%">Rest Amount</th>
                             <th style="width:14%">State</th>
                             <th style="width:30%">Action</th>
                             <th style="width:14%">Created At</th>
                    <th style="width:14%">User</th>
                            
                           
                    
                        </tr>
                      </thead>


                      <tbody>
                              <?php
						   
						  
						  
							include_once 'connection.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						  
						  
$sql1="SELECT l.l_id, b.b_en, c.c_name,stg.stage_id, sta.state_id, ct.ct_id, ct.ct_en,lt.lt_en,stg.stage_en, sta.state_backcolor, sta.state_en,l.consultant, lt.lt_id,  l.assistant, l.location, l.no_session,l.amount_contact, l.tax, l.total_amount,l.paid, l.due, l.created_at  from lawsuit l INNER JOIN branch b ON l.b_id=b.b_id INNER Join customer c ON l.c_id=c.c_id INNER Join customer_type ct ON l.ct_id=ct.ct_id INNER Join lawsuit_type lt ON l.lt_id=lt.lt_id INNER Join stage stg ON l.stage_id=stg.stage_id INNER Join state sta ON l.state_id=sta.state_id";
$result = $conn->query($sql1);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
 // <th>Customer ID</th>
                         
   $tax=(int)$row["total_amount"]-(int)$row["amount_contact"];
	   	echo "<tr><td><a style='color:blue;' type='button' href='lawsuit_profile.php?id=".$row["l_id"]."' >" . $row["l_id"]. "</a></td>";
        echo "<td>" . $row["b_en"]. "</td>";
	   echo "<td><a style='color:blue;' type='button' href='lawsuit_profile.php?id=".$row["l_id"]."' >" . $row["c_name"]. "</a></td>";
          echo "<td>" . $row["ct_en"]. "</td>";
	  echo "<td>" . $row["lt_en"]. "</td>";
        echo "<td>" . $row["stage_en"]. "</td>";
          echo "<td>" . $row["location"]. "</td>";
          echo "<td>" . $row["no_session"]. "</td>";
         echo "<td>" . $row["amount_contact"]. "</td>";
         echo "<td>" . $tax. "</td>";
         echo "<td>" . $row["total_amount"]. "</td>";
           echo "<td>" . $row["paid"]. "</td>";
           echo "<td>" . $row["due"]. "</td>";
	 
      
	 
        echo "<td><a style='vertical-align: -webkit-baseline-middle;padding:8px;border-radius:4px;text-decoration:none;color:white; background-color:".$row["state_backcolor"].";'> ".$row["state_en"]." </a></td>";
	 
  
	   
     echo "<td>
     <a  type='button' href='lawsuit_profile.php?id=".$row["l_id"]."' class='btn btn-purple btn-xs'><i class='fa fa-eye'></i></a>
     <a  type='button' href='update_lawsuit.php?id=".$row["l_id"]."' class='btn btn-primary btn-xs'><i class='fa fa-edit'></i></a>
     
     <a  type='button' href='delete_lawsuit.php?id=".$row["l_id"]."-".$row["ct_id"]."-".$row["lt_id"]."-".$row["state_id"]."-".$row["stage_id"]."' class='btn btn-danger btn-xs'><i class='fa fa-trash'></i></a>
     
     <a  type='button' href='lawsuit_print.php?id=".$row["l_id"]."' class='btn btn-success btn-xs'><i class='fa fa-print'></i></a></td>";
         echo "<td>" . $row["created_at"]. "</td>";
         echo "<td> Admin</td>";
             echo"</tr>";
        
		
		 
		 
		
		 

		  }
} else {
   
}
						  $conn->close();
   
						?>
                        
                           
                      </tbody>
                    </table>
                  </div>
                  </div>
              </div>
            </div>
                </div>
              </div>

       
            </div>

      
         
          </div>
        </div> 
                 
                   <?php
              }
                else
                {
                ?>
                 
          
          
<div dir="rtl" style="width:100%; text-align:right;" lang="ar" class="right_col" role="main">
 
          <div class=""><div class="row">
              <div class="col-md-12 col-sm-12 ">
                  
      <a style="float:right;" href="add_lawsuit.php" class="btn btn-primary btn-sm">+ إضافة قضية جديدة</a>
               <a style="float:right;" href="add_lawsuittype.php" class="btn btn-dark btn-sm">+ إضافة نوع قضية جديد</a>
              <a style="float:right;" href="add_customer.php" class="btn btn-danger btn-sm">+ إضافة عميل جديد</a>
              <a style="float:right;" href="add_customertype.php" class="btn btn-success btn-sm">+ إضافة نوع عميل جديد</a>
						  <input id="copy_btn" type="button" value="copy">
                
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="float:right;">دعوى قضائية</h2>
                    <ul style="float:left"  class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Settings 1</a>
                            <a class="dropdown-item" href="#">Settings 2</a>
                          </div>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                   
                    <table dir="rtl" id="datatable" class="table table-striped table-bordered table-sm" style="width:100%;text-align:center;">
                      <thead>
                        <tr>
                          <th style="width:4%">رقم ملف القضية</th>
                         <th style="width:4%">فرع</th>
                            <th style="width:4%">عميل</th>
                          <th style="width:4%">نوع/صفة العميل</th>
                             <th style="width:4%">نوع القضية</th>
                             <th style="width:4%">مرحلة التقاضي</th>
                             <th style="width:4%">مكان القضية</th>
                             <th style="width:4%">عدد الجلسات</th>
                            <th style="width:4%">المبلغ</th>
                            <th style="width:4%">مبلغ الضريبة</th>
                            <th style="width:4%">لمبلغ الاجمالي شامل الضريبة</th>
                            <th style="width:4%">المبلغ المدفوع</th>
                            <th style="width:4%">المبلغ الباقي</th>
                            <th style="width:4%">حالة القضية</th>
                            <th style="width:12%">إجراء</th>
                            <th style="width:4%">تاريخ الإنشاء</th>
                            <th style="width:4%">مستخدم</th>
                            
                           
                    
                        </tr>
                      </thead>


            <tbody>
                              <?php
						   
						  
						  
							include_once 'connection.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						  
						  
$sql1="SELECT l.l_id, b.b_en, c.c_name, ct.ct_id, ct.ct_en,lt.lt_en,stg.stage_en, sta.state_backcolor, sta.state_en,l.consultant, l.assistant, l.location, l.no_session,l.amount_contact, l.tax, l.total_amount,l.paid, l.due, l.created_at  from lawsuit l INNER JOIN branch b ON l.b_id=b.b_id INNER Join customer c ON l.c_id=c.c_id INNER Join customer_type ct ON l.ct_id=ct.ct_id INNER Join lawsuit_type lt ON l.lt_id=lt.lt_id INNER Join stage stg ON l.stage_id=stg.stage_id INNER Join state sta ON l.state_id=sta.state_id";
$result = $conn->query($sql1);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
 // <th>Customer ID</th>
                         
   $tax=(int)$row["total_amount"]-(int)$row["amount_contact"];
	   	echo "<tr><td><a style='color:blue;' type='button' href='lawsuit_profile.php?id=".$row["l_id"]."' >" . $row["l_id"]. "</a></td>";
        echo "<td>" . $row["b_en"]. "</td>";
	   echo "<td><a style='color:blue;' type='button' href='lawsuit_profile.php?id=".$row["l_id"]."' >" . $row["c_name"]. "</a></td>";
          echo "<td>" . $row["ct_en"]. "</td>";
	  echo "<td>" . $row["lt_en"]. "</td>";
        echo "<td>" . $row["stage_en"]. "</td>";
          echo "<td>" . $row["location"]. "</td>";
          echo "<td>" . $row["no_session"]. "</td>";
         echo "<td>" . $row["amount_contact"]. "</td>";
         echo "<td>" . $tax. "</td>";
         echo "<td>" . $row["total_amount"]. "</td>";
           echo "<td>" . $row["paid"]. "</td>";
           echo "<td>" . $row["due"]. "</td>";
	 
      
	 
        echo "<td><a style='vertical-align: -webkit-baseline-middle;padding:8px;border-radius:4px;text-decoration:none;color:white; background-color:".$row["state_backcolor"].";'> ".$row["state_en"]." </a></td>";
	 
  
	   
     echo "<td>
     <a  type='button' href='lawsuit_profile.php?id=".$row["l_id"]."' class='btn btn-purple btn-xs'><i class='fa fa-eye'></i></a>
     <a  type='button' href='update_lawsuit.php?id=".$row["l_id"]."' class='btn btn-primary btn-xs'><i class='fa fa-edit'></i></a>
     <a  type='button' href='delete_lawsuit.php?id=".$row["l_id"]."-".$row["ct_id"]."' class='btn btn-danger btn-xs'><i class='fa fa-trash'></i></a>
     <a  type='button' href='lawsuit_print.php?id=".$row["l_id"]."' class='btn btn-success btn-xs'><i class='fa fa-print'></i></a>
     
     </td>";
         echo "<td>" . $row["created_at"]. "</td>";
         echo "<td> Admin</td></tr>";
        
		
		 
		 
		
		 

		  }
} else {
   
}
						  $conn->close();
   
						?>
                        
                           
                      </tbody>
                    </table>
                  </div>
                  </div>
              </div>
            </div>
                </div>
              </div>

       
            </div>

      
         
          </div>
        </div> 
                
                 <?php
                }
            
            ?>
                
                
          
          
        <footer>
          <div class="pull-right">
           </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>
<!---- Copy Functin ---->
<script>
var copyBtn = document.querySelector('#copy_btn');
copyBtn.addEventListener('click', function () {
  var urlField = document.querySelector('table');
   
  // create a Range object
  var range = document.createRange();  
  // set the Node to select the "range"
  range.selectNode(urlField);
  // add the Range to the set of window selections
  window.getSelection().addRange(range);
   
  // execute 'copy', can't 'cut' in this case
  document.execCommand('copy');
}, false);
</script>
<!----End Copy Functin ---->
    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>
    <!-- jQuery Tags Input -->
    <script src="../vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
    <!-- Switchery -->
    <script src="../vendors/switchery/dist/switchery.min.js"></script>
    <!-- Select2 -->
    <script src="../vendors/select2/dist/js/select2.full.min.js"></script>
    <!-- Parsley -->
    <script src="../vendors/parsleyjs/dist/parsley.min.js"></script>
    <!-- Autosize -->
    <script src="../vendors/autosize/dist/autosize.min.js"></script>
    <!-- jQuery autocomplete -->
    <script src="../vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
    <!-- starrr -->
    <script src="../vendors/starrr/dist/starrr.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
    <script src="../vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="../vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="../vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="../vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="../vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="../vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="../vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="../vendors/jszip/dist/jszip.min.js"></script>
    <script src="../vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="../vendors/pdfmake/build/vfs_fonts.js"></script>
  </body>
</html>