<?php
include_once 'connection.php';
$conn;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{
    $logo=basename($_FILES["fileToUpload1"]["name"]);
    $header_logo=basename($_FILES["fileToUpload2"]["name"]);
 
if ($logo=="")
{$logo=$_POST["pre_logo"];     
 }
else{
       
     unlink("uploads/".$_POST["pre_logo"]);

    $target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload1"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload1"]["tmp_name"]);
    if($check !== false) {
       
        $uploadOk = 1;
    } else {
      
        $uploadOk = 0;
    }
}
 
   
    if (move_uploaded_file($_FILES["fileToUpload1"]["tmp_name"], $target_file)) {
       
    } else {
       
    }
    
    
    
   
}
        
if ($header_logo=="")
{$header_logo=$_POST["pre_header"];  
 }
 else{
     unlink("uploads/".$_POST["pre_header"]);
      $target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload2"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload2"]["tmp_name"]);
    if($check !== false) {
       
        $uploadOk = 1;
    } else {
 
        $uploadOk = 0;
    }
}
 
 
 
    if (move_uploaded_file($_FILES["fileToUpload2"]["tmp_name"], $target_file)) {
       
    } else {
      
    }
       
 }
  
   
 $sql = "UPDATE settings SET Office_Name='".$_POST["Office_Name"]."', id_no='".$_POST["id_no"]."', cr_no='".$_POST["cr_no"]."', post_box='".$_POST["post_box"]."', city='".$_POST["city"]."', address='".$_POST["address"]."', email='".$_POST["email"]."', phone='".$_POST["phone"]."', mobile='".$_POST["mobile"]."', whatsapp='".$_POST["whatsapp"]."', currency='".$_POST["currency"]."', tax_value='".$_POST["tax_value"]."', tax_no='".$_POST["tax_no"]."', preface_lawsuits_ar='".$_POST["preface_lawsuits_ar"]."', preface_lawsuits_en='".$_POST["preface_lawsuits_en"]."', fee_lawsuits_ar='".$_POST["fee_lawsuits_ar"]."', fee_lawsuits_en='".$_POST["fee_lawsuits_en"]."',  contract_lawsuits_ar='".$_POST["contract_lawsuits_ar"]."', contract_lawsuits_en='".$_POST["contract_lawsuits_en"]."' , contract_consultations_ar='".$_POST["contract_consultations_ar"]."' , contract_consultations_en='".$_POST["contract_consultations_en"]."',   set_logo='".$logo."', set_header='".$header_logo."' WHERE set_id=1";
  
if ($conn->query($sql) === TRUE) {
     
  
} else {
    echo "Error updating record: " . $conn->error;
}
     header('Location: settings.php');
}

$conn->close();
?>







 