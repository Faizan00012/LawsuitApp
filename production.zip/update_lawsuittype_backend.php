<?php

include_once 'connection.php';
$conn;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{
 
        $id=$_POST["lt_id"];
    $sql = "UPDATE lawsuit_type SET lt_ar='".$_POST["name_ar"]."', lt_en='".$_POST["name_en"]."' WHERE lt_id=".$id;
  
if ($conn->query($sql) === TRUE) {
        header('Location: lawsuit_type.php');
  
} else {
    echo "Error updating record: " . $conn->error;
}
   
 
 

}

$conn->close();
?>