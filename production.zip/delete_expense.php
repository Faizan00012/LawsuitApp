<?php
 
$exp_id = $_GET['id'];

include_once 'connection.php';
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// sql to delete a record
$sql = "DELETE FROM expenses WHERE exp_id = {$exp_id}";

if ($conn->query($sql) === TRUE) {
    
} else {
     
}
 
header("Location: expense.php");

mysqli_close($conn);

?>
