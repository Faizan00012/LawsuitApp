<?php
session_start();
$stu_id = $_GET['id'];

include_once 'connection.php';
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// sql to delete a record
$sql = "DELETE FROM customer WHERE c_id = {$stu_id}";

if ($conn->query($sql) === TRUE) {
   
$_SESSION["alert"]="true";
$_SESSION["alert_msg"]="حذف العميل بنجاح";

} else {
$_SESSION["alert"]="true";
$_SESSION["alert_msg"]="لا يمكن حذف عميل";
}
 
    header('location: customer.php');
mysqli_close($conn);

?>
