<?php
include_once 'connection.php';
$conn;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{
 
    $id=$_POST["l_id"];
 
    $sql = "UPDATE lawsuit SET opp_name='".$_POST["opp_name"]."', opp_contact='".$_POST["opp_phone"]."',  opp_nationality='".$_POST["opp_nationality"]."', opp_address='".$_POST["opp_address"]."', opp_lawyer='".$_POST["opp_lawyer"]."', opp_lawyer_contact='".$_POST["opp_lawyerphone"]."', lawyer='".$_POST["ls_lawyer"]."', subject='".$_POST["ls_subject"]."', consultant='".$_POST["ls_consultant"]."', assistant='".$_POST["ls_assistant"]."', stage_id='".$_POST["ls_stage"]."', state_id='".$_POST["ls_state"]."', amount_contact='".$_POST["ls_amount"]."', tax='".$_POST["ls_tax"]."', total_amount='".$_POST["ls_total"]."', location='".$_POST["ls_location"]."', contract_preamble_ar='".$_POST["cp_ar"]."', contract_preamble_en='".$_POST["cp_en"]."', fee_detail_ar='".$_POST["fee_ar"]."', fee_detail_en='".$_POST["fee_en"]."', contact_ar='".$_POST["contract_ar"]."', contract_en='".$_POST["contract_en"]."', note='".$_POST["note"]."', created_at='".$_POST["created_at"]."' WHERE l_id=".$id;
    
    if ($conn->query($sql) === TRUE) {
       header('Location: lawsuit.php');
  
} else {
    echo "Error updating record: " . $conn->error;
}
   
 
     
}

$conn->close();
?>


  