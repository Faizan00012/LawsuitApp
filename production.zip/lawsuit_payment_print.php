<?php
$lw_id = $_GET['id'];
include_once 'connection.php';
$conn;

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
} 
$payment_date="";
$custome_name="";
$l_id=0;             
             
  $sql = "SELECT * from settings";
 
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
     $owner_header=$row["set_header"];
}
} else {
    echo "No results";
}             

 
?>
     
<!DOCTYPE html>
<!-- saved from url=(0065)https://demo-ar-en.mueen-law.com/en/consultation/print_contract/4 -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <title>Report</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Coderthemes" name="author">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <style>body,h1,h2,h3,h4,h5,h6,p{font-family:Calibri,serif}body{font-size:22px;color:#0b0b0b;text-align:right;direction:rtl}ul{padding-right:20px}</style>

</head>

    <body>
                 
         
    
        
        <div style="background-color: #fafafa;padding:50px;">
         <div>
                 
        <div style="text-align: center;">
                                      <table style="width:100%"><tr>
              <td style="text-align:center;">  <img style="width:100%;" src="uploads/<?php echo $owner_header; ?>"></td>
            </tr></table>
 
                                      
                                    <h3 style="">ســنــد قـبـض - RECEIPT VOUCHER</h3>
                                  
                                </div>
 
                
                                

                                <div style="float: left;padding: 10px;">
                                  
                                        <strong> Payment Date : </strong>
                                        <?php echo $payment_date; ?>
                                  
                                </div>

                                <div style="float-right;padding: 10px;">
                                    <p><strong> Invoice No : </strong> 00<?php echo $l_id; ?></p>
                                </div>

                            </div>
             <div style="width:100%;">
             <table>
                 <th>we received from</th>
                 <th>we received from</th>
                 </table>
             </div>
                       
                         
                           <div style="float:right;color:#0b0b0b;">
            <button onclick="window.print()"><i class="fa fa-print" style="font-size:24px"></i></button><br><br><br></div>
 
                  </div>
 
            
    

</body></html>