<?php

include_once 'connection.php';
$conn;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{
 
    
        $id=$_POST["state_id"];
    $sql = "UPDATE state SET state_ar='".$_POST["name_ar"]."', state_en='".$_POST["name_en"]."', state_backcolor='".$_POST["state_color"]."' WHERE state_id=".$id;
  
if ($conn->query($sql) === TRUE) {
        header('Location: states.php');
  
} else {
    echo "Error updating record: " . $conn->error;
}
   
 
 

}

$conn->close();
?>