<?php
include_once 'header_file.php';
include_once 'connection.php';
$conn;
$id = $_GET['id'];
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php 
                             if($_SESSION["lang_option"]=="en"){
                                echo "App Number";
                            }
                            else{
                                 echo "إضافة رقم جديد";
                            }
                            ?></title>

    <!-- Bootstrap -->
   <?php
    if($_SESSION["lang_option"]=="en"){
        
           ?>
              <link rel="stylesheet" href="navcode1.css">
             <?php
    }
    else{
        
          ?>
              <link rel="stylesheet" href="navcode2.css">
             <?php
    }
    ?>
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

 
        <?php include 'nav.php';  ?>

        <!-- page content -->
          
                 
<?php if(isset($_POST['change_submit'])) {
      $_SESSION["lang_option"]=$_POST["langoption"];}

              if($_SESSION["lang_option"]=="en"){
                  ?>

                  <form action="" method="post">
              
       <div dir="" style="width:100%" lang="ar" class="right_col" role="main">
 
            <div class="clearfix"></div>
          
                
                
            <div class="col-md-12 ">
              <a href="lawsuit_profile.php?id=<?php echo $id; ?>" class="btn btn-dark btn-sm">Lawsuit Profile</a>
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Add New Number </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div dir="ltr" class="x_content">
                    <br />
                    

                        
                      
                      <div class="col-md-6 col-sm-6  form-group">
                          <label>Name</label>
                    <input type="text" name="name" class="form-control" id="inputSuccess2" placeholder="Name">
                          <input type="hidden" name="l_id" value="<?php echo $id; ?>">
                      </div>
                        <div class="col-md-3 col-sm-6  form-group">
                          <label>Number</label>
                    <input type="text" name="number" class="form-control" id="inputSuccess2" placeholder="Number">
                          </div>
                      <div class="col-md-3 col-sm-6  form-group">
                             <label>Created At</label>
                    <input type="date" name="date_create"  class="form-control">
                      </div>
                      
                     
                       <div class="col-md-12 col-sm-6  form-group">
                    <label>Notes</label>
                           <textarea placeholder="Notes" name="notes" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                    
                     <div class="form-group row">
                        <div class="col-md-9 col-sm-9  offset-md-4"><br>
                          <button style="width:30%" type="submit" name="submit" class="btn btn-success">Add Number</button>
                        </div>
                      </div>

                     
                  </div>
                </div>
 
              


          
              
            </div>

              </div>      
           </form>  
                   <?php
              }
                else
                {
                ?>
                 <form style="font-size:20px;" action="" method="post">
              
       <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main"> 
 
 
            <div class="clearfix"></div>
          
                
                
            <div class="col-md-12 ">
            <a style="float:right;font-size:20px;padding-left:20px;padding-right:20px;" href="lawsuit_profile.php?id=<?php echo $id; ?>" class="btn btn-dark btn-sm">القضايا</a>
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="float:right;font-size:24px;" >إضافة رقم جديد </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div dir="rtl" class="x_content">
                    <br />
                    

                        
                      
                      <div class="col-md-6 col-sm-6  form-group">
                          <label>الاسم</label>
                    <input type="text" name="name" class="form-control" id="inputSuccess2" placeholder="الاسم">
                          <input type="hidden" name="l_id" value="<?php echo $id; ?>">
                      </div>
                        <div class="col-md-3 col-sm-6  form-group">
                          <label>الرقم</label>
                    <input type="text" name="number" class="form-control" id="inputSuccess2" placeholder="الرقم">
                          </div>
                      <div class="col-md-3 col-sm-6  form-group">
                             <label>تاريخ الإنشاء</label>
                    <input type="date" name="date_create"  class="form-control">
                      </div>
                      
                     
                       <div class="col-md-12 col-sm-6  form-group">
                    <label>ملاحظات</label>
                           <textarea placeholder="ملاحظات" name="notes" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                    
                     <div class="form-group row">
                        <div class="col-md-9 col-sm-9  offset-md-4"><br>
                          <button style="width:30%" type="submit" name="submit" class="btn btn-success">إضافة رقم جديد</button>
                        </div>
                      </div>

                     
                  </div>
                </div>
 
              


          
              
            </div>

              </div>      
           </form>  
                
                 <?php
                }
            
            ?>
                
          
    
        </div>
         <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
     

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>
    <!-- jQuery Tags Input -->
    <script src="../vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
    <!-- Switchery -->
    <script src="../vendors/switchery/dist/switchery.min.js"></script>
    <!-- Select2 -->
    <script src="../vendors/select2/dist/js/select2.full.min.js"></script>
    <!-- Parsley -->
    <script src="../vendors/parsleyjs/dist/parsley.min.js"></script>
    <!-- Autosize -->
    <script src="../vendors/autosize/dist/autosize.min.js"></script>
    <!-- jQuery autocomplete -->
    <script src="../vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
    <!-- starrr -->
    <script src="../vendors/starrr/dist/starrr.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
	
  </body>
</html>
<?php
include_once 'connection.php';
$conn;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{
      
   $sql = "INSERT INTO numbertbl (l_id, name, num_number, note, created_at) VALUES ('".$_POST["l_id"]."','".$_POST["name"]."','".$_POST["number"]."','".$_POST["notes"]."','".$_POST["date_create"]."')";
  echo $sql;
if ($conn->query($sql) === TRUE) {
  echo "New Number Added";
}else{
	echo "New Number Not Added";
} 

}

$conn->close();
?>