<?php
 session_start();

 
if(empty($_SESSION['username']) || $_SESSION['username'] == ''){
    header("Location: login.php");
    // die();
}
include_once 'langchange.php';
if ($_SESSION["lang_option"]=="en"){
    $langoption="en";
               
}
else{
    $langoption="ar";
   
}
header("Expires: Thu, 19 Nov 1981 08:52:00 GMT"); //Date in the past
header("Cache-Control: no-store, no-cache, must-revalidate"); //HTTP/1.1include_once ( 'con_file.php' );
 $user=$_SESSION['username'];


?>