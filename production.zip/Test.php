<?php
include_once 'header_file.php';
include_once 'connection.php';
$conn;
$no_cons=0;
$no_customer=0;
$no_lawsuit=0;
$no_session=0;
$no_amount=0;
$ls_amount=0;
$con_amount=0;
$ls_recevable=0;
$con_recevable=0;
$ls_contract=0;
$con_contract=0;
$ls_paid=0;
$con_paid=0;
$total_expense=0;
$total_contract=0;
$total_paid=0;
$total_recevable=0;
$dt1 = new DateTime();
$today_date = $dt1->format("Y-m-d");
$dt2 = new DateTime("-1 month");
$dt3 = new DateTime("-1 year");
$new_date = $dt2->format("Y-m-d");
$new_date2 = $dt3->format("Y-m-d");
  

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT COUNT(con_id), SUM(total_amount)  from consultation where start_date between '".$new_date2."' and '".$today_date."'";
 
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $no_cons=$row["COUNT(con_id)"];
        $con_amount=$row["SUM(total_amount)"];
        
       }}  

$sql = "SELECT COUNT(c_id) from customer ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $no_customer=$row["COUNT(c_id)"];
       }}  

$sql = "SELECT COUNT(l_id), SUM(total_amount)from lawsuit where created_at between '".$new_date2."' and '".$today_date."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $no_lawsuit=$row["COUNT(l_id)"];
        $ls_amount=$row["SUM(total_amount)"];
       }} 

$sql = "SELECT COUNT(session_id) from session where session_date between '".$new_date2."' and '".$today_date."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $no_session=$row["COUNT(session_id)"];
       }} 

$sql = "SELECT SUM(exp_amount) from expenses where exp_date between '".$new_date2."' and '".$today_date."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $total_expense=$row["SUM(exp_amount)"];
       }} 

$sql = "SELECT SUM(cled_paid) from consultation_ledger where cled_date between '".$new_date2."' and '".$today_date."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
   $con_paid=$row["SUM(cled_paid)"];
       }
} 

$sql = "SELECT SUM(led_paid) from lawsuit_ledger where led_date between '".$new_date2."' and '".$today_date."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
         $lu_paid=$row["SUM(led_paid)"];
       }}

$total_contract=$ls_amount+$con_amount;
$total_paid=$lu_paid+$con_paid;
$con_recevable=$con_amount-$con_paid;
$ls_recevable=$ls_amount-$lu_paid;
$total_recevable=$con_recevable+$ls_recevable;
                   
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Dashboard</title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">

    <!-- Custom styling plus plugins -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
    <style>
        
        .sidebar{
  background-color: green;
}
    </style>
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
         <?php include 'nav.php';  ?>
                    
<?php if(isset($_POST['change_submit'])) {
      $_SESSION["lang_option"]=$_POST["langoption"];}

              if($_SESSION["lang_option"]=="en"){
                  ?>

                   <div class="right_col" role="main">
          <div class="">

             <script>
              function onChangeNavigate(d) {
  window.top.location = d.value;}
              </script>

            <div class="clearfix"></div>

              <div class="row">
              <div class="col-md-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Dashboard</h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                  
                      
                    <form class="form-label-left input_mask">
                    
                                     <div class="form-group row">
                    <div class="col-md-4 col-sm-4 ">
                         <label>Search for Customer</label>
                              <select class="form-control" onchange="onChangeNavigate(this)">
                             <option>Select Customer Name</option>
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from customer";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='customer.php'>".$row["c_name"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                     </div>
                                            <div class="col-md-4 col-sm-4 ">
                         <label>Search for Consutation ID</label>
                              <select class="form-control" onchange="onChangeNavigate(this)">
                             <option>Select Consutation</option>
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from consultation";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='consultation.php'>".$row["con_id"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                     </div>
                                            <div class="col-md-4 col-sm-4 ">
                         <label>Search for Lawsuit ID</label>
                              <select class="form-control" onchange="onChangeNavigate(this)">
                             <option>Select Customer Name</option>
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from lawsuit";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='lawsuit.php'>".$row["l_id"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                     </div>
                          
                        
                  
                        </div>
                        
 
                    
                   
                    </form>
                  </div>
                </div>

           

            


              </div>

         


        
            </div>
              
<div style="padding-left: 0px;padding-top: 20px;text-align:justify;width:100%;">
    
              
               
               <a style="width:30%;"    href="customer.php" type="button" class="btn btn-success btn-sm">Customers</a>
               <a style="width:30%;"    href="lawsuit.php"  type="button" class="btn btn-danger btn-sm">Lawsuit</a>
               <a style="width:30%;"    href="add_lawsuit.php"  type="button" class="btn btn-primary btn-sm">Add Lawsuit</button>
               <a style="width:30%;"    href="session.php"  type="button" class="btn btn-secondary btn-sm">Sessions</a>
               <a style="width:30%;"    href="paper.php"  type="button" class="btn btn-info btn-sm">Paper</a>
               <a style="width:30%;"    href="payment_lw.php"  type="button" class="btn btn-success btn-sm">Payments Lawsuit</a>
               <a style="width:30%;"    href="consultation_payment.php"  type="button" class="btn btn-danger btn-sm">Payments Consultaion</a>
               <a style="width:30%;"    href="consultation.php"  type="button" class="btn btn-primary btn-sm">Consultaion</a>
               <a style="width:30%;"    href="add_consultation.php"  type="button" class="btn btn-secondary btn-sm">Add new Consultaion</a>
               <a style="width:30%;"    href="branch.php"  type="button" class="btn btn-info btn-sm">Branches</a>
               <a style="width:30%;"    href="expense.php"  type="button" class="btn btn-warning btn-sm">Expenses</a>
               <a style="width:30%;"    href="customer_report.php"  type="button" class="btn btn-success btn-sm">Report Customer</a>
               <a style="width:30%;"    href="lawsuit_report.php"  type="button" class="btn btn-danger btn-sm">Report Lawsuit   </a>
               <a style="width:30%;"    href="consultation_report.php"  type="button" class="btn btn-primary btn-sm">Report Consultation</a>
               <a style="width:30%;"    href="sessions_report.php"  type="button" class="btn btn-secondary btn-sm">Report Session</a>
               <a style="width:30%;"    href="payment_lawsuit_report.php"  type="button" class="btn btn-info btn-sm">Report Payments Lawsuits</a>
               <a style="width:30%;"    href="payments_consultaion_report.php"  type="button" class="btn btn-warning btn-sm">Report Payments Consultation</a>
               <a style="width:30%;"    href="users.php"  type="button" class="btn btn-danger btn-sm">Users</a>
               <a style="width:30%;"    href="role.php"  type="button" class="btn btn-primary btn-sm">Roles Management</a><br><br>
            </div>
                        <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Aggregate Reports</h2>
               
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                        
                          
                <div class="row" style="display: inline-block; width:100%;" >
         
			     <div class="tile_count">
         
            <div class="col-md-3 col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-blue"><?php echo $no_customer; ?></span>
                    <i class="fa fa-users blue"></i><p style="font-size:14px;">Customers</p> 
                  </a>
             </div>   
               <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-green"><?php echo $no_lawsuit; ?></span>
                    <i class="fa fa-legal green"></i> <p style="font-size:14px;">Lawsuits</p> 
                  </a></div>  
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-blue"><?php echo $no_cons; ?></span>
                    <i class="fa fa-book blue"></i> <p style="font-size:14px;">Consultation</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-red"><?php echo $no_session; ?></span>
                    <i class="fa fa-clock-o red"></i> <p style="font-size:14px;">Sessions</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-green"><?php echo $ls_amount; ?></span>
                    <i class="fa fa-money green"></i> <p style="font-size:14px;">Total Lawsuits Contracts</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-blue"><?php echo $con_amount; ?></span>
                    <i class="fa fa-money  blue"></i> <p style="font-size:14px;">Total Consultation Contracts</p> 
                  </a></div>
                 <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-red"><?php echo $total_contract; ?></span>
                    <i class="fa fa-money red"></i> <p style="font-size:14px;">Total Contracts</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-green"><?php echo $lu_paid; ?></span>
                    <i class="fa fa-dollar green"></i> <p style="font-size:14px;">Total Paid From lawsuits</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-blue"><?php echo $con_paid; ?></span>
                    <i class="fa fa-dollar blue"></i> <p style="font-size:14px;">Total Paid From Consultation</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-red"><?php echo $total_paid; ?></span>
                    <i class="fa fa-dollar red"></i> <p style="font-size:14px;">Total Paid</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-green"><?php echo $ls_recevable; ?></span>
                    <i class="fa fa-dollar green"></i> <p style="font-size:14px;">Total Receivable Lawsuits</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-blue"><?php echo $con_recevable; ?></span>
                    <i class="fa fa-dollar blue"></i> <p style="font-size:14px;">Total Receivable Consultation </p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-red"><?php echo $total_recevable; ?></span>
                    <i class="fa fa-dollar red"></i> <p style="font-size:14px;">Total Receivable </p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-red"><?php echo $total_expense; ?></span>
                    <i class="fa fa-line-chart red"></i> <p style="font-size:14px;">Total Expenses </p> 
                  </a></div>
                 
         
          </div>
        </div>
              </div>
            </div>
                </div>
              </div>

       
            </div>

          </div>
        </div>
     
                   <?php
              }
                else
                {
                ?>
                 <div class="right_col" role="main">
          <div class="">

             <script>
              function onChangeNavigate(d) {
  window.top.location = d.value;}
              </script>

            <div class="clearfix"></div>

              <div class="row">
              <div class="col-md-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>الرئيسية</h2>
                      <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                  
                      
                    <form class="form-label-left input_mask">
                    
                                     <div class="form-group row">
                    <div class="col-md-4 col-sm-4 ">
                         <label>بحث عن عميل</label>
                              <select class="form-control" onchange="onChangeNavigate(this)">
                             <option>بحث عن عميل</option>
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from customer";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='customer.php'>".$row["c_id"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                     </div>
                                            <div class="col-md-4 col-sm-4 ">
                         <label>ببحث عن استشارة</label>
                              <select class="form-control" onchange="onChangeNavigate(this)">
                             <option>بحث عن استشارة</option>
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from consultation";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='consultation.php'>".$row["con_id"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                     </div>
                                            <div class="col-md-4 col-sm-4 ">
                         <label>القضايا</label>
                              <select class="form-control" onchange="onChangeNavigate(this)">
                             <option>القضايا</option>
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from lawsuit";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='lawsuit.php'>".$row["l_id"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                     </div>
                          
                        
                  
                        </div>
                        
 
                    
                   
                    </form>
                  </div>
                </div>

           

            


              </div>

         


        
            </div>
              
              
              
              
                <div style="padding-left: 0px;padding-top: 20px;text-align:justify;width:100%;">
    
          <a style="width:30%;"   href="customer.php" type="button" class="btn btn-success btn-sm">عملاء</a>
               <a style="width:30%;"    href="lawsuit.php"  type="button" class="btn btn-danger btn-sm">القضايا</a>
               <a style="width:30%;"    href="add_lawsuit.php" type="button" class="btn btn-primary btn-sm">إضافة قضية جديدة</a>
               <a style="width:30%;"    href="session.php"  type="button" class="btn btn-secondary btn-sm">الجلسات</a>
               <a style="width:30%;"    href="paper.php"  type="button" class="btn btn-info btn-sm">صحائف الدعوى</a>
               <a style="width:30%;"    href="payment_lw.php" type="button" class="btn btn-success btn-sm">مدفوعات القضايا</a>
               <a style="width:30%;"    href="consultation_payment.php"  type="button" class="btn btn-danger btn-sm">مدفوعات الاستشارات</a>
               <a style="width:30%;"    href="consultation.php"  type="button" class="btn btn-primary btn-sm">الاستشارات </a>
               <a style="width:30%;"    href="add_consultation.php"   type="button" class="btn btn-secondary btn-sm">إنشاء استشارة جديدة</a>
               <a style="width:30%;"    href="branch.php" type="button" class="btn btn-info btn-sm">الفروع</a>
               <a style="width:30%;"    href="expense.php" type="button" class="btn btn-warning btn-sm">المصروفات</a>
               <a style="width:30%;"    href="customer_report.php"  type="button" class="btn btn-success btn-sm">تقارير العملاء</a>
               <a style="width:30%;"    href="lawsuit_report.php"   type="button" class="btn btn-danger btn-sm">تقارير القضايا</a>
               <a style="width:30%;"    href="consultation_report.php"  type="button" class="btn btn-primary btn-sm">تقريتقارير الاستشارة</a>
               <a style="width:30%;"    href="sessions_report.php" type="button" class="btn btn-secondary btn-sm"> تقارير الجلسات</a>
               <a style="width:30%;"    href="payment_lawsuit_report.php"  type="button" class="btn btn-info btn-sm">تقارير مدفوعات القضايا</a>
                <a style="width:30%;"   href="payments_consultaion_report.php"  type="button" class="btn btn-warning btn-sm">تقارير مدفوعات الاستشارات</a>
               <a style="width:30%;"   href="users.php"  type="button" class="btn btn-danger btn-sm">المستخدمين</a>
               <a style="width:30%;"   href="role.php"  type="button" class="btn btn-primary btn-sm">الصلاحيات</a><br><br>
                   
                    
                    
                    
              
            </div>
                           <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>التقارير الإجمالية</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Settings 1</a>
                            <a class="dropdown-item" href="#">Settings 2</a>
                          </div>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                        
                          
                <div class="row" style="display: inline-block; width:100%;" >
         
			     <div class="tile_count">
         
            <div class="col-md-3 col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-blue"><?php echo $no_customer; ?></span>
                    <i class="fa fa-users blue"></i><p style="font-size:14px;">عدد العملاء</p> 
                  </a>
             </div>   
               <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-green"><?php echo $no_lawsuit; ?></span>
                    <i class="fa fa-legal green"></i> <p style="font-size:14px;">عدد القضايا</p> 
                  </a></div>  
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-blue"><?php echo $no_cons; ?></span>
                    <i class="fa fa-book blue"></i> <p style="font-size:14px;">عدد الاستشارات</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-red"><?php echo $no_session; ?></span>
                    <i class="fa fa-clock-o red"></i> <p style="font-size:14px;">عدد الجلسات</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-green"><?php echo $ls_amount; ?></span>
                    <i class="fa fa-money green"></i> <p style="font-size:14px;">إجمالي كل عقود القضايا</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-blue"><?php echo $con_amount; ?></span>
                    <i class="fa fa-money  blue"></i> <p style="font-size:14px;">إجمالي كل عقود الاستشارات</p> 
                  </a></div>
                 <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-red"><?php echo $total_contract; ?></span>
                    <i class="fa fa-money red"></i> <p style="font-size:14px;">إجمالي كل العقود</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-green"><?php echo $lu_paid; ?></span>
                    <i class="fa fa-dollar green"></i> <p style="font-size:14px;">جمالي المدفوع من القضايا</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-blue"><?php echo $con_paid; ?></span>
                    <i class="fa fa-dollar blue"></i> <p style="font-size:14px;">إجمالي المدفوع من الاستشارات</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-red"><?php echo $total_paid; ?></span>
                    <i class="fa fa-dollar red"></i> <p style="font-size:14px;">إجمالي المدفوع للكل</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-green"><?php echo $ls_recevable; ?></span>
                    <i class="fa fa-dollar green"></i> <p style="font-size:14px;">إجمالي المتبقي من القضايا</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-blue"><?php echo $con_recevable; ?></span>
                    <i class="fa fa-dollar blue"></i> <p style="font-size:14px;">إجمالي المتبقي من الاستشارات </p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-red"><?php echo $total_recevable; ?></span>
                    <i class="fa fa-dollar red"></i> <p style="font-size:14px;">إجمالي المتبقي من الكل </p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-red"><?php echo $total_expense; ?></span>
                    <i class="fa fa-line-chart red"></i> <p style="font-size:14px;">إجمالي المصروفات </p> 
                  </a></div>
                 
         
          </div>
        </div>
              </div>
            </div>
                </div>
              </div>

       
            </div>

          </div>
        </div>
      
                
                 <?php
                }
            
            ?>
                
                
        <footer>
          <div class="pull-right">
           
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- compose -->
    <div class="compose col-md-6  ">
      <div class="compose-header">
        New Message
        <button type="button" class="close compose-close">
          <span>×</span>
        </button>
      </div>

      <div class="compose-body">
        <div id="alerts"></div>

        <div class="btn-toolbar editor" data-role="editor-toolbar" data-target="#editor">
          <div class="btn-group">
            <a class="btn dropdown-toggle" data-toggle="dropdown" title="Font"><i class="fa fa-font"></i><b class="caret"></b></a>
            <ul class="dropdown-menu">
            </ul>
          </div>

          <div class="btn-group">
            <a class="btn dropdown-toggle" data-toggle="dropdown" title="Font Size"><i class="fa fa-text-height"></i>&nbsp;<b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li>
                <a data-edit="fontSize 5">
                  <p style="font-size:17px">Huge</p>
                </a>
              </li>
              <li>
                <a data-edit="fontSize 3">
                  <p style="font-size:14px">Normal</p>
                </a>
              </li>
              <li>
                <a data-edit="fontSize 1">
                  <p style="font-size:11px">Small</p>
                </a>
              </li>
            </ul>
          </div>

          <div class="btn-group">
            <a class="btn" data-edit="bold" title="Bold (Ctrl/Cmd+B)"><i class="fa fa-bold"></i></a>
            <a class="btn" data-edit="italic" title="Italic (Ctrl/Cmd+I)"><i class="fa fa-italic"></i></a>
            <a class="btn" data-edit="strikethrough" title="Strikethrough"><i class="fa fa-strikethrough"></i></a>
            <a class="btn" data-edit="underline" title="Underline (Ctrl/Cmd+U)"><i class="fa fa-underline"></i></a>
          </div>

          <div class="btn-group">
            <a class="btn" data-edit="insertunorderedlist" title="Bullet list"><i class="fa fa-list-ul"></i></a>
            <a class="btn" data-edit="insertorderedlist" title="Number list"><i class="fa fa-list-ol"></i></a>
            <a class="btn" data-edit="outdent" title="Reduce indent (Shift+Tab)"><i class="fa fa-dedent"></i></a>
            <a class="btn" data-edit="indent" title="Indent (Tab)"><i class="fa fa-indent"></i></a>
          </div>

          <div class="btn-group">
            <a class="btn" data-edit="justifyleft" title="Align Left (Ctrl/Cmd+L)"><i class="fa fa-align-left"></i></a>
            <a class="btn" data-edit="justifycenter" title="Center (Ctrl/Cmd+E)"><i class="fa fa-align-center"></i></a>
            <a class="btn" data-edit="justifyright" title="Align Right (Ctrl/Cmd+R)"><i class="fa fa-align-right"></i></a>
            <a class="btn" data-edit="justifyfull" title="Justify (Ctrl/Cmd+J)"><i class="fa fa-align-justify"></i></a>
          </div>

          <div class="btn-group">
            <a class="btn dropdown-toggle" data-toggle="dropdown" title="Hyperlink"><i class="fa fa-link"></i></a>
            <div class="dropdown-menu input-append">
              <input class="span2" placeholder="URL" type="text" data-edit="createLink" />
              <button class="btn" type="button">Add</button>
            </div>
            <a class="btn" data-edit="unlink" title="Remove Hyperlink"><i class="fa fa-cut"></i></a>
          </div>

          <div class="btn-group">
            <a class="btn" title="Insert picture (or just drag & drop)" id="pictureBtn"><i class="fa fa-picture-o"></i></a>
            <input type="file" data-role="magic-overlay" data-target="#pictureBtn" data-edit="insertImage" />
          </div>

          <div class="btn-group">
            <a class="btn" data-edit="undo" title="Undo (Ctrl/Cmd+Z)"><i class="fa fa-undo"></i></a>
            <a class="btn" data-edit="redo" title="Redo (Ctrl/Cmd+Y)"><i class="fa fa-repeat"></i></a>
          </div>
        </div>

        <div id="editor" class="editor-wrapper"></div>
      </div>

      <div class="compose-footer">
        <button id="send" class="btn btn-sm btn-success" type="button">Send</button>
      </div>
    </div>
    <!-- /compose -->

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>

  </body>
</html>