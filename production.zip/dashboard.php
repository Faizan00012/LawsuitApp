<?php
include_once 'header_file.php';
include_once 'connection.php';
$conn;
$no_cons=0;
$no_customer=0;
$no_lawsuit=0;
$no_session=0;
$no_amount=0;
$ls_amount=0;
$con_amount=0;
$ls_recevable=0;
$con_recevable=0;
$ls_contract=0;
$con_contract=0;
$ls_paid=0;
$con_paid=0;
$total_expense=0;
$total_contract=0;
$total_paid=0;
$total_recevable=0;
$dt1 = new DateTime();
$today_date = $dt1->format("Y-m-d");
$dt2 = new DateTime("-1 month");
$dt3 = new DateTime("-1 year");
$new_date = $dt2->format("Y-m-d");
$new_date2 = $dt3->format("Y-m-d");
  

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT COUNT(con_id), SUM(total_amount)  from consultation where start_date between '".$new_date2."' and '".$today_date."'";
 
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $no_cons=$row["COUNT(con_id)"];
        $con_amount=$row["SUM(total_amount)"];
        
       }}  

$sql = "SELECT COUNT(c_id) from customer ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $no_customer=$row["COUNT(c_id)"];
       }}  

$sql = "SELECT COUNT(l_id), SUM(total_amount)from lawsuit where created_at between '".$new_date2."' and '".$today_date."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $no_lawsuit=$row["COUNT(l_id)"];
        $ls_amount=$row["SUM(total_amount)"];
       }} 

$sql = "SELECT COUNT(session_id) from session where session_date between '".$new_date2."' and '".$today_date."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $no_session=$row["COUNT(session_id)"];
       }} 

$sql = "SELECT SUM(exp_amount) from expenses where exp_date between '".$new_date2."' and '".$today_date."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $total_expense=$row["SUM(exp_amount)"];
       }} 

$sql = "SELECT SUM(cled_paid) from consultation_ledger where cled_date between '".$new_date2."' and '".$today_date."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
   $con_paid=$row["SUM(cled_paid)"];
       }
} 

$sql = "SELECT SUM(led_paid) from lawsuit_ledger where led_date between '".$new_date2."' and '".$today_date."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
         $lu_paid=$row["SUM(led_paid)"];
       }}

$total_contract=$ls_amount+$con_amount;
$total_paid=$lu_paid+$con_paid;
$con_recevable=$con_amount-$con_paid;
$ls_recevable=$ls_amount-$lu_paid;
$total_recevable=$con_recevable+$ls_recevable;
                   
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Dashboard</title>

    <!-- Bootstrap -->
<?php
    if($_SESSION["lang_option"]=="en"){
        
           ?>
              <link rel="stylesheet" href="navcode1.css">
             <?php
    }
    else{
        
          ?>
              <link rel="stylesheet" href="navcode2.css">
             <?php
    }
    ?>
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">

    <!-- Custom styling plus plugins -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
    <style>
    .search-box-Customer input[type="text"], .result{
        width: 100%;
        box-sizing: border-box;
    }
    
    .result-Customer p{
        margin: 0;
    
        padding: 7px 10px;
        border: 1px solid #00504d;
        border-top: none;
        cursor: pointer;
    }
    .result-Customer p:hover{
        background: #00504d;
             color:white;
    }
     .search-box-Consultation input[type="text"], .result{
        width: 100%;
        box-sizing: border-box;
    }
     
    .result-Consultation p{
        margin: 0;
      
        padding: 7px 10px;
        border: 1px solid #00504d;
        border-top: none;
        cursor: pointer;
    }
    .result-Consultation p:hover{
        background: #00504d;
          color:white;
    }
    
     .search-box-Lawsuit input[type="text"], .result{
        width: 100%;
        box-sizing: border-box;
    }
     
    .result-Lawsuit p{
        margin: 0;
      
        padding: 7px 10px;
        border: 1px solid #00504d;
        border-top: none;
        cursor: pointer;
    }
    .result-Lawsuit p:hover{
        background: #00504d;
          color:white;
    }
    
    
    
        
        .sidebar{
  background-color: green;
}
.btn-purple {
    color: #fff;
    background-color: #5b69bc;
    border-color: #5b69bc;
}
.form-control{    display: block;
    width: 100%;
    height: calc(1.5em + 0.9rem + 2px);
    padding: 0.45rem 0.9rem;
    font-size: .9rem;
    font-weight: 400;
    line-height: 1.5;
    color: #6c757d;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    border-radius: 0.2rem;}
.btn-primary {
    color: #fff;
    background-color: #71b6f9;
    border-color: #71b6f9;
}
.btn-danger {
    color: #fff;
    background-color: #ff5b5b;
    border-color: #ff5b5b;
}
.btn-warning {
    color: #343a40;
    background-color: #f9c851;
    border-color: #f9c851;
}
.btn-success {
    color: #fff;
    background-color: #10c469;
    border-color: #10c469;
}
.btn-secondary {
    color: #fff;
    background-color: #6c757d;
    border-color: #6c757d;
}
.form-control-feedback.right {
    border-left: 1px solid #ccc;
    right: 4px;
}
.navbar .nav_title
{background: #ededed;}
 .float{
	position:fixed;
	width:60px;
	height:60px;
	bottom:40px;
	right:40px;
	background-color:#25d366;
	color:#FFF;
	border-radius:50px;
	text-align:center;
  font-size:30px;
	box-shadow: 2px 2px 3px #999;
  z-index:100;
 
}

.my-float{
	margin-top:16px;
}
div.table-responsive>div.dataTables_wrapper>div.row {
    margin: 0;
    text-align: right;
}
body[data-layout=horizontal] .page-title-box .page-title {
    line-height: 50px;
    margin: 0;
    font-size: 14px;
    
}
    </style>
     <script src="jquery-1.12.4.min.js"></script>
<script type="text/javascript">
      //customer function
             function showCustomerName(str) {
                  
		
    if (str.length == 0) { 
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
				var txt =xmlhttp.responseText;
				var str = txt;
				var arr = str.split("|");
	
			     window.location.replace("customerbyid.php?id="+arr[0]);
            }
        };
		
	 
	    
        xmlhttp.open("GET", "getcustomername.php?q=" + str, true);
        xmlhttp.send();
    }
		
}

     // consultation function
        function showConsultation(str) {
		
    if (str.length == 0) { 
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
				var txt =xmlhttp.responseText;
				var str = txt;
		 
	   window.location.replace("consultationbyid.php?id="+str);
            }
        };
		
		
	    
        xmlhttp.open("GET", "getconsultation.php?q=" + str, true);
        xmlhttp.send();
    }
		
}


    // Lawsuit function
        function showLawsuit(str) {
		
    if (str.length == 0) { 
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
				var txt =xmlhttp.responseText;
				var str = txt;
		  
	   window.location.replace("lawsuitbyid.php?id="+str);
            }
        };
		
		
	    
        xmlhttp.open("GET", "getlawsuit.php?q=" + str, true);
        xmlhttp.send();
    }
		
}

    $(document).ready(function(){
              
     // Search for Customer Name          
	 $('.search-box-Customer input[type="text"]').on("keyup input", function(){
	   
        /* Get input value on change */
       
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result-Customer");
        if(inputVal.length){
            $.get("search_customer.php", {term: inputVal}).done(function(data){
                // Display the returned data in browser
                resultDropdown.html(data);
            });
        } else{
            resultDropdown.empty();
        }
    });
   
	$(document).on("click", ".result-Customer p", function(){
        $(this).parents(".search-box-Customer").find('input[type="text"]').val($(this).text());
      
		var x=document.getElementById("customer_name").value;
        $(this).parent(".result-Customer").empty();
		 showCustomerName(x);
    });
    
    
    // Search for Consultation ID
    
     $('.search-box-Consultation input[type="text"]').on("keyup input", function(){
	   
        /* Get input value on change */
       
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result-Consultation");
        if(inputVal.length){
            $.get("search_consultation.php", {term: inputVal}).done(function(data){
                // Display the returned data in browser
                resultDropdown.html(data);
            });
        } else{
            resultDropdown.empty();
        }
    });
   
	$(document).on("click", ".result-Consultation p", function(){
        $(this).parents(".search-box-Consultation").find('input[type="text"]').val($(this).text());
      
		var x=document.getElementById("consultation_id").value;
        $(this).parent(".result-Consultation").empty();
		 showConsultation(x);
    });
    
    // Search for Lawsuit ID
    
     $('.search-box-Lawsuit input[type="text"]').on("keyup input", function(){
	   
        /* Get input value on change */
       
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result-Lawsuit");
        if(inputVal.length){
            $.get("search_lawsuit.php", {term: inputVal}).done(function(data){
                // Display the returned data in browser
                resultDropdown.html(data);
            });
        } else{
            resultDropdown.empty();
        }
    });
   
	$(document).on("click", ".result-Lawsuit p", function(){
        $(this).parents(".search-box-Lawsuit").find('input[type="text"]').val($(this).text());
      
		var x=document.getElementById("lawsuit_id").value;
        $(this).parent(".result-Lawsuit").empty();
		 showLawsuit(x);
    });
    
});
         </script>
  </head>

   
         <?php include 'nav.php';  ?>
       
                    
<?php if(isset($_POST['change_submit'])) {
      $_SESSION["lang_option"]=$_POST["langoption"];}

              if($_SESSION["lang_option"]=="en"){
                  ?>

                   <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main" >
          <div class="">

             <script>
              function onChangeNavigate(d) {
  window.top.location = d.value;}
              </script>

            <div class="clearfix"></div>

              <div class="row">
              <div class="col-md-12 ">
                  <h2 style="color:black;"><b>Dashboard</b></h2>
                <div class="x_panel">
                  <div class="x_title">
                    
                    
                    <div class="clearfix"></div>
                  </div>
                  <div dir="ltr" class="x_content">
                  
                      
                    <form class="form-label-left input_mask">
                    
                                     <div class="form-group row">
                                        
                                          <div class="col-md-4 col-sm-6  form-group has-feedback">
                                        <div class="search-box-Customer">
                                        <span>Customer Name</span>
                        <input style="border-color:#00504d;border-radius:3px" type="text" class="form-control has-feedback-right" id="customer_name" placeholder="Search Customer Name">
                        <!--<span style="color:#00504d;" class="fa fa-search form-control-feedback right" aria-hidden="true"></span>-->
                        <button type="button" class="btn btn-purple form-control-feedback right fa fa-search" style="width: 10%;height: 40px;margin-top: -1px;"></button>
                        <div class="result-Customer"></div></div>
                      </div>
                                 <div class="col-md-4 col-sm-6  form-group has-feedback">
                            <div class="search-box-Consultation">
                        <input style="border-color:#00504d;border-radius:3px" type="text" class="form-control has-feedback-right" id="consultation_id" placeholder="Search Consultation ID">
                        <!--<span style="color:#00504d;" class="fa fa-search form-control-feedback right" aria-hidden="true"></span>-->
                        <button type="button" class="btn btn-purple form-control-feedback right fa fa-search" style="width: 10%;height: 40px;margin-top: -1px;"></button>
                        <div class="result-Consultation"></div></div>
                      </div>
                                 <div class="col-md-4 col-sm-6  form-group has-feedback">
                          <div class="search-box-Lawsuit">   
                        <input style="border-color:#00504d;border-radius:3px" type="text" class="form-control has-feedback-right" id="lawsuit_id" placeholder="Search Lawsuit ID">
                        <!--<span style="color:#00504d;" class="fa fa-search form-control-feedback right" aria-hidden="true"></span>-->
                        <button type="button" class="btn btn-purple  form-control-feedback right fa fa-search" style="width: 10%;height: 40px;margin-top: -1px;"></button>
                        <div class="result-Lawsuit"></div></div>
                      </div>
                   


                  
                        </div>
                        
 
                    
                   
                    </form>
                  </div>
                </div>

           

            


              </div>

         


        
            </div>
              <div class="row">
                  <div class="col-md-2"> <a style="width:100%; " href="customer.php" type="button" class="btn btn-success btn-sm "><i class="fa fa-users white"></i>&nbsp;Customers</a></div>
                  <div class="col-md-2"><a style="width:100%;" href="lawsuit.php"  type="button" class="btn btn-danger btn-sm"><i class="fa fa-legal white"></i>&nbsp;Lawsuit</a></div>
                  <div class="col-md-2"><a style="width:100%;"     href="add_lawsuit.php"  type="button" class="btn btn-primary btn-sm"><i class="fa fa-legal white"></i>&nbsp;Add Lawsuit</a></div>
                  <div class="col-md-2"><a style="width:100%;"     href="session.php"  type="button" class="btn btn-secondary btn-sm"><i class="fa fa-clock-o white"></i>&nbsp;Sessions</a></div>
                  <div class="col-md-2"><a style="width:100%;"   href="paper.php"  type="button" class="btn btn-info btn-sm" ><i class="fa fa-file-o white"></i>&nbsp;Paper</a></div>
                  <div class="col-md-2"><a style="width:100%;" href="payment_lw.php"  type="button" class="btn btn-success btn-sm"><i class="fa fa-money white"></i>&nbsp;Payments Lawsuit</a></div>
                  
              </div>
              <div class="row">
                  <div class="col-md-2"><a style="width:100%;"    href="lawsuit_report.php"  type="button" class="btn btn-danger btn-sm"><i class="fa fa-sort-amount-asc white"></i>&nbsp;Report Lawsuit   </a></div>
                  <div class="col-md-2"><a style="width:100%;"     href="consultation.php"  type="button" class="btn btn-primary btn-sm"><i class="fa fa-book white"></i>&nbsp;Consultaion</a></div>
                  <div class="col-md-2"><a style="width:100%;"     href="add_consultation.php"  type="button" class="btn btn-secondary btn-sm"><i class="fa fa-book white">+</i>&nbsp;Add new Consultaion</a></div>
                  <div class="col-md-2"><a style="width:100%;"    href="branch.php"  type="button" class="btn btn-info btn-sm"><i class="fa fa-building"></i>&nbsp;Branches</a></div>
                  <div class="col-md-2"><a style="width:100%;"   href="expense.php"  type="button" class="btn btn-warning btn-sm"><i class="fa fa-bar-chart-o"></i>&nbsp;Expenses</a></div>
                  <div class="col-md-2"><a style="width:100%;"   href="customer_report.php"  type="button" class="btn btn-success btn-sm"><i class="fa fa-clone"></i>&nbsp;Report Customer</a></div>
                  
              </div>
              
               <div class="row">
                  <div class="col-md-2"><a style="width:100%;"    href="consultation_payment.php"  type="button" class="btn btn-danger btn-sm"><i class="fa fa-dollar white"></i>&nbsp;Payments Consultaion</a></div>
                  <div class="col-md-2"> <a style="width:100%;"     href="consultation_report.php"  type="button" class="btn btn-primary btn-sm"><i class="fa fa-clone"></i>&nbsp;Report Consultation</a></div>
                  <div class="col-md-2"><a style="width:100%;"     href="sessions_report.php"  type="button" class="btn btn-secondary btn-sm"><i class="fa fa-clone"></i>&nbsp;Report Session</a></div>
                  <div class="col-md-2"> <a style="width:100%;"     href="payment_lawsuit_report.php"  type="button" class="btn btn-info btn-sm"><i class="fa fa-clone"></i>&nbsp;Report Payments Lawsuits</a></div>
                  <div class="col-md-2"><a style="width:100%;"     href="payments_consultaion_report.php"  type="button" class="btn btn-warning btn-sm"><i class="fa fa-clone"></i>&nbsp;Report Payments Consultation</a></div>
                  <div class="col-md-2"> <a style="width:100%;"     href="users.php"  type="button" class="btn btn-danger btn-sm"><i class="fa fa-gear"></i>&nbsp;Users</a></div>
                  
              </div>
              
               <div class="row">
                  <div class="col-md-2"><a style="width:100%;"    href="role.php"  type="button" class="btn btn-primary btn-sm"><i class="fa fa-gear"></i>&nbsp;Roles Management</a></div>
                  <div class="col-md-2"><a style="width:100%;"    href="imagefile.php"  type="button" class="btn btn-warning  btn-sm"><i class="fa fa-gear"></i>&nbsp;Images & Files</a></div>
                  <div class="col-md-2"><a style="width:100%;"    href="settings.php"  type="button" class="btn btn-danger  btn-sm"><i class="fa fa-gear"></i>&nbsp;Setting</a></div>
                  <div class="col-md-2"></div>
                  <div class="col-md-2"></div>
                  <div class="col-md-2"> </div>
                  <a href="https://wa.me/+971552066664" target="_blank" class="float"><i class="fa fa-whatsapp my-float"></i></a>
              </div>
<!---<div style="padding-left: 0px;padding-top: 20px;text-align:justify;width:100%;" dir="ltr">
    
              
               
               <a style="width:30%;"    href="customer.php" type="button" class="btn btn-success btn-sm">Customers</a>
               <a style="width:30%;"    href="lawsuit.php"  type="button" class="btn btn-danger btn-sm">Lawsuit</a>
               <a style="width:30%;"    href="add_lawsuit.php"  type="button" class="btn btn-primary btn-sm">Add Lawsuit</button>
               <a style="width:30%;"    href="session.php"  type="button" class="btn btn-secondary btn-sm">Sessions</a>
               <a style="width:30%;"    href="paper.php"  type="button" class="btn btn-info btn-sm">Paper</a>
               <a style="width:30%;"    href="payment_lw.php"  type="button" class="btn btn-success btn-sm">Payments Lawsuit</a>
               <a style="width:30%;"    href="consultation_payment.php"  type="button" class="btn btn-danger btn-sm">Payments Consultaion</a>
               <a style="width:30%;"    href="consultation.php"  type="button" class="btn btn-primary btn-sm">Consultaion</a>
               <a style="width:30%;"    href="add_consultation.php"  type="button" class="btn btn-secondary btn-sm">Add new Consultaion</a>
               <a style="width:30%;"    href="branch.php"  type="button" class="btn btn-info btn-sm">Branches</a>
               <a style="width:30%;"    href="expense.php"  type="button" class="btn btn-warning btn-sm">Expenses</a>
               <a style="width:30%;"    href="customer_report.php"  type="button" class="btn btn-success btn-sm">Report Customer</a>
               <a style="width:30%;"    href="lawsuit_report.php"  type="button" class="btn btn-danger btn-sm">Report Lawsuit   </a>
               <a style="width:30%;"    href="consultation_report.php"  type="button" class="btn btn-primary btn-sm">Report Consultation</a>
               <a style="width:30%;"    href="sessions_report.php"  type="button" class="btn btn-secondary btn-sm">Report Session</a>
               <a style="width:30%;"    href="payment_lawsuit_report.php"  type="button" class="btn btn-info btn-sm">Report Payments Lawsuits</a>
               <a style="width:30%;"    href="payments_consultaion_report.php"  type="button" class="btn btn-warning btn-sm">Report Payments Consultation</a>
               <a style="width:30%;"    href="users.php"  type="button" class="btn btn-danger btn-sm">Users</a>
               <a style="width:30%;"    href="role.php"  type="button" class="btn btn-primary btn-sm">Roles Management</a><br><br>
               <a href="https://wa.me/+971552066664" target="_blank" class="float"><i class="fa fa-whatsapp my-float"></i></a>
               
            </div>--->
                        <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Aggregate Reports</h2>
               
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                        
                          
                <div class="row" style="display: inline-block; width:100%;" >
         
			     <div class="tile_count">
         
            <div class="col-md-3 col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-blue"><?php echo $no_customer; ?></span>
                    <i class="fa fa-users blue"></i><p style="font-size:14px;">Customers</p> 
                  </a>
             </div>   
               <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-green"><?php echo $no_lawsuit; ?></span>
                    <i class="fa fa-legal green"></i> <p style="font-size:14px;">Lawsuits</p> 
                  </a></div>  
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-blue"><?php echo $no_cons; ?></span>
                    <i class="fa fa-book blue"></i> <p style="font-size:14px;">Consultation</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-red"><?php echo $no_session; ?></span>
                    <i class="fa fa-clock-o red"></i> <p style="font-size:14px;">Sessions</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-green"><?php echo $ls_amount; ?></span>
                    <i class="fa fa-money green"></i> <p style="font-size:14px;">Total Lawsuits Contracts</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-blue"><?php echo $con_amount; ?></span>
                    <i class="fa fa-money  blue"></i> <p style="font-size:14px;">Total Consultation Contracts</p> 
                  </a></div>
                 <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-red"><?php echo $total_contract; ?></span>
                    <i class="fa fa-money red"></i> <p style="font-size:14px;">Total Contracts</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-green"><?php echo $lu_paid; ?></span>
                    <i class="fa fa-dollar green"></i> <p style="font-size:14px;">Total Paid From lawsuits</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-blue"><?php echo $con_paid; ?></span>
                    <i class="fa fa-dollar blue"></i> <p style="font-size:14px;">Total Paid From Consultation</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-red"><?php echo $total_paid; ?></span>
                    <i class="fa fa-dollar red"></i> <p style="font-size:14px;">Total Paid</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-green"><?php echo $ls_recevable; ?></span>
                    <i class="fa fa-dollar green"></i> <p style="font-size:14px;">Total Receivable Lawsuits</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-blue"><?php echo $con_recevable; ?></span>
                    <i class="fa fa-dollar blue"></i> <p style="font-size:14px;">Total Receivable Consultation </p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-red"><?php echo $total_recevable; ?></span>
                    <i class="fa fa-dollar red"></i> <p style="font-size:14px;">Total Receivable </p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4">
					<a class="btn btn-app" style="width:100%;height:70px;">
                    <span style="font-size:12px;" class="badge bg-red"><?php echo $total_expense; ?></span>
                    <i class="fa fa-line-chart red"></i> <p style="font-size:14px;">Total Expenses </p> 
                  </a></div>
                 
         
          </div>
        </div>
              </div>
            </div>
                </div>
              </div>

       
            </div>

          </div>
        </div>
     
                   <?php
              }
                else
                {
                ?>
                 <div dir="rtl" style="width:100%" lang="ar" class="right_col" role="main">
          <div class="">

             <script>
              function onChangeNavigate(d) {
  window.top.location = d.value;}
              </script>

            <div class="clearfix" style="text-align:right;"></div>

              <div class="row" style="    text-align: right;">
              <div class="col-md-12 ">
                <div class="x_panel">
                  <div class="x_title" style="    text-align: right; float:right;">
                    <h2>الرئيسية</h2>
                      <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                  
                      
                    <form class="form-label-left input_mask">
                    
                                     <div class="form-group row">
                                         
                    <div class="col-md-4 col-sm-6  form-group has-feedback">
                                        <div class="search-box-Customer">
                        <input style="border-color:#00504d;border-radius:3px" type="text" class="form-control has-feedback-left" id="customer_name" placeholder="بحث عن عميل">
                        <span style="color:#00504d;" class="fa fa-search form-control-feedback left" aria-hidden="true"></span>
                        <div class="result-Customer"></div></div>
                      </div>
                                 <div class="col-md-4 col-sm-6  form-group has-feedback">
                            <div class="search-box-Consultation">
                        <input style="border-color:#00504d;border-radius:3px" type="text" class="form-control has-feedback-left" id="consultation_id" placeholder="ببحث عن استشارة">
                        <span style="color:#00504d;" class="fa fa-search form-control-feedback left" aria-hidden="true"></span>
                        <div class="result-Consultation"></div></div>
                      </div>
                                 <div class="col-md-4 col-sm-6  form-group has-feedback">
                          <div class="search-box-Lawsuit">   
                        <input style="border-color:#00504d;border-radius:3px" type="text" class="form-control has-feedback-left" id="lawsuit_id" placeholder="ببحث عن القضايا">
                        <span style="color:#00504d;" class="fa fa-search form-control-feedback left" aria-hidden="true"></span>
                        <div class="result-Lawsuit"></div></div>
                      </div>
                        
                  
                        </div>
                        
 
                    
                   
                    </form>
                  </div>
                </div>

           

            


              </div>

         


        
            </div>
              
              <!--- Arabic Vers--->
              
               <div class="row">
                  <div class="col-md-2"> <a style="width:100%; " href="customer.php" type="button" class="btn btn-success btn-sm "><i class="fa fa-users white"></i>&nbsp;العملاء</a></div>
                  <div class="col-md-2"><a style="width:100%;" href="lawsuit.php"  type="button" class="btn btn-danger btn-sm"><i class="fa fa-legal white"></i>&nbsp;القضايا</a></div>
                  <div class="col-md-2"><a style="width:100%;"     href="add_lawsuit.php"  type="button" class="btn btn-primary btn-sm"><i class="fa fa-legal white"></i>&nbsp;إضافة قضية جديدة</a></div>
                  <div class="col-md-2"><a style="width:100%;"     href="session.php"  type="button" class="btn btn-secondary btn-sm"><i class="fa fa-clock-o white"></i>&nbsp;الجلسات</a></div>
                  <div class="col-md-2"><a style="width:100%;"   href="paper.php"  type="button" class="btn btn-info btn-sm"><i class="fa fa-file-o white"></i>&nbsp;صحائف الدعوى</a></div>
                  <div class="col-md-2"><a style="width:100%;" href="payment_lw.php"  type="button" class="btn btn-success btn-sm"><i class="fa fa-money white"></i>&nbsp;مدفوعات القضايا</a></div>
                  
              </div>
              <div class="row">
                  <div class="col-md-2"><a style="width:100%;"    href="lawsuit_report.php"  type="button" class="btn btn-danger btn-sm"><i class="fa fa-sort-amount-asc white"></i>&nbsp;مدفوعات الاستشارات</a></div>
                  <div class="col-md-2"><a style="width:100%;"     href="consultation.php"  type="button" class="btn btn-primary btn-sm"><i class="fa fa-book white"></i>&nbsp;الاستشارات</a></div>
                  <div class="col-md-2"><a style="width:100%;"     href="add_consultation.php"  type="button" class="btn btn-secondary btn-sm"><i class="fa fa-book white">+</i>&nbsp;إنشاء استشارة جديدة</a></div>
                  <div class="col-md-2"><a style="width:100%;"    href="branch.php"  type="button" class="btn btn-info btn-sm"><i class="fa fa-building"></i>&nbsp;الفروع</a></div>
                  <div class="col-md-2"><a style="width:100%;"   href="expense.php"  type="button" class="btn btn-warning btn-sm"><i class="fa fa-bar-chart-o"></i>&nbsp;المصروفات</a></div>
                  <div class="col-md-2"><a style="width:100%;"   href="customer_report.php"  type="button" class="btn btn-success btn-sm"><i class="fa fa-clone"></i>&nbsp;تقارير العملاء</a></div>
                  
              </div>
              
               <div class="row">
                  <div class="col-md-2"><a style="width:100%;"    href="consultation_payment.php"  type="button" class="btn btn-danger btn-sm"><i class="fa fa-dollar white"></i>&nbsp;تقارير القضايا</a></div>
                  <div class="col-md-2"> <a style="width:100%;"     href="consultation_report.php"  type="button" class="btn btn-primary btn-sm"><i class="fa fa-clone"></i>&nbsp;تقارير الاستشارة</a></div>
                  <div class="col-md-2"><a style="width:100%;"     href="sessions_report.php"  type="button" class="btn btn-secondary btn-sm"><i class="fa fa-clone"></i>&nbsp;تقارير الجلسات</a></div>
                  <div class="col-md-2"> <a style="width:100%;"     href="payment_lawsuit_report.php"  type="button" class="btn btn-info btn-sm"><i class="fa fa-clone"></i>&nbsp;تقارير مدفوعات القضايا</a></div>
                  <div class="col-md-2"><a style="width:100%;"     href="payments_consultaion_report.php"  type="button" class="btn btn-warning btn-sm"><i class="fa fa-clone"></i>&nbsp;تقارير مدفوعات الاستشارات</a></div>
                  <div class="col-md-2"> <a style="width:100%;"     href="users.php"  type="button" class="btn btn-danger btn-sm"><i class="fa fa-gear"></i>&nbsp;مستخدمين</a></div>
                  
              </div>
              
               <div class="row">
                  <div class="col-md-2"><a style="width:100%;"    href="role.php"  type="button" class="btn btn-primary btn-sm"><i class="fa fa-gear"></i>&nbsp;الصلاحيات</a></div>
                  <div class="col-md-2"> </div>
                  <div class="col-md-2"></div>
                  <div class="col-md-2"> </div>
                  <div class="col-md-2"></div>
                  <div class="col-md-2"> </div>
                  <a href="https://wa.me/+971552066664" target="_blank" class="float"><i class="fa fa-whatsapp my-float"></i></a>
              </div>
                <!--<div style="padding-left: 0px;padding-top: 20px;text-align:justify;width:100%;">
    
          <a style="width:30%;"   href="customer.php" type="button" class="btn btn-success btn-sm">العملاء</a>
               <a style="width:30%;"    href="lawsuit.php"  type="button" class="btn btn-danger btn-sm">القضايا</a>
               <a style="width:30%;"    href="add_lawsuit.php" type="button" class="btn btn-primary btn-sm">إضافة قضية جديدة</a>
               <a style="width:30%;"    href="session.php"  type="button" class="btn btn-secondary btn-sm">الجلسات</a>
               <a style="width:30%;"    href="paper.php"  type="button" class="btn btn-info btn-sm">صحائف الدعوى</a>
               <a style="width:30%;"    href="payment_lw.php" type="button" class="btn btn-success btn-sm">مدفوعات القضايا</a>
               <a style="width:30%;"    href="consultation_payment.php"  type="button" class="btn btn-danger btn-sm">مدفوعات الاستشارات</a>
               <a style="width:30%;"    href="consultation.php"  type="button" class="btn btn-primary btn-sm">الاستشارات </a>
               <a style="width:30%;"    href="add_consultation.php"   type="button" class="btn btn-secondary btn-sm">إنشاء استشارة جديدة</a>
               <a style="width:30%;"    href="branch.php" type="button" class="btn btn-info btn-sm">الفروع</a>
               <a style="width:30%;"    href="expense.php" type="button" class="btn btn-warning btn-sm">المصروفات</a>
               <a style="width:30%;"    href="customer_report.php"  type="button" class="btn btn-success btn-sm">تقارير العملاء</a>
               <a style="width:30%;"    href="lawsuit_report.php"   type="button" class="btn btn-danger btn-sm">تقارير القضايا</a>
               <a style="width:30%;"    href="consultation_report.php"  type="button" class="btn btn-primary btn-sm">تقارير الاستشارة</a>
               <a style="width:30%;"    href="sessions_report.php" type="button" class="btn btn-secondary btn-sm"> تقارير الجلسات</a>
               <a style="width:30%;"    href="payment_lawsuit_report.php"  type="button" class="btn btn-info btn-sm">تقارير مدفوعات القضايا</a>
                <a style="width:30%;"   href="payments_consultaion_report.php"  type="button" class="btn btn-warning btn-sm">تقارير مدفوعات الاستشارات</a>
               <a style="width:30%;"   href="users.php"  type="button" class="btn btn-danger btn-sm">المستخدمين</a>
               <a style="width:30%;"   href="role.php"  type="button" class="btn btn-primary btn-sm">الصلاحيات</a><br><br>
                   
                    
                    
                    
              
            </div>--->
                           <div class="row" style="text-align:right; float:right;>
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title" >
                    <h2 style="text-align:right; float: right;">التقارير الإجمالية</h2>
                    <ul class="nav navbar-right panel_toolbox" style="float: left;" >
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Settings 1</a>
                            <a class="dropdown-item" href="#">Settings 2</a>
                          </div>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row" style="text-align: right;">
                        
                          
                <div class="row" style="display: inline-block; width:100%;float:right;" >
         
			     <div class="tile_count">
         
            <div class="col-md-3 col-sm-4" style="float:right;">
					<a class="btn btn-app" style="width:100%;height:70px;float:right;">
                    <span style="font-size:12px;" class="badge bg-blue"><?php echo $no_customer; ?></span>
                    <i class="fa fa-users blue"></i><p style="font-size:14px;">عدد العملاء</p> 
                  </a>
             </div>   
               <div class="col-md-3  col-sm-4" style="float:right;">
					<a class="btn btn-app" style="width:100%;height:70px;float:right;">
                    <span style="font-size:12px;" class="badge bg-green"><?php echo $no_lawsuit; ?></span>
                    <i class="fa fa-legal green"></i> <p style="font-size:14px;">عدد القضايا</p> 
                  </a></div>  
                  <div class="col-md-3  col-sm-4" style="float:right;">
					<a class="btn btn-app" style="width:100%;height:70px;float:right;">
                    <span style="font-size:12px;" class="badge bg-blue"><?php echo $no_cons; ?></span>
                    <i class="fa fa-book blue"></i> <p style="font-size:14px;">عدد الاستشارات</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4" style="float:right;">
					<a class="btn btn-app" style="width:100%;height:70px;float:right;">
                    <span style="font-size:12px;" class="badge bg-red"><?php echo $no_session; ?></span>
                    <i class="fa fa-clock-o red"></i> <p style="font-size:14px;">عدد الجلسات</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4" style="float:right;">
					<a class="btn btn-app" style="width:100%;height:70px;float:right;">
                    <span style="font-size:12px;" class="badge bg-green"><?php echo $ls_amount; ?></span>
                    <i class="fa fa-money green"></i> <p style="font-size:14px;">إجمالي كل عقود القضايا</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4" style="float:right;">
					<a class="btn btn-app" style="width:100%;height:70px;float:right;">
                    <span style="font-size:12px;" class="badge bg-blue"><?php echo $con_amount; ?></span>
                    <i class="fa fa-money  blue"></i> <p style="font-size:14px;">إجمالي كل عقود الاستشارات</p> 
                  </a></div>
                 <div class="col-md-3  col-sm-4" style="float:right;">
					<a class="btn btn-app" style="width:100%;height:70px;float:right;">
                    <span style="font-size:12px;" class="badge bg-red"><?php echo $total_contract; ?></span>
                    <i class="fa fa-money red"></i> <p style="font-size:14px;">إجمالي كل العقود</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4" style="float:right;">
					<a class="btn btn-app" style="width:100%;height:70px;float:right;">
                    <span style="font-size:12px;" class="badge bg-green"><?php echo $lu_paid; ?></span>
                    <i class="fa fa-dollar green"></i> <p style="font-size:14px;">إجمالي المدفوع من القضايا</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4" style="float:right;">
					<a class="btn btn-app" style="width:100%;height:70px;float:right;">
                    <span style="font-size:12px;" class="badge bg-blue"><?php echo $con_paid; ?></span>
                    <i class="fa fa-dollar blue"></i> <p style="font-size:14px;">إجمالي المدفوع من الاستشارات</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4" style="float:right;">
					<a class="btn btn-app" style="width:100%;height:70px;float:right;">
                    <span style="font-size:12px;" class="badge bg-red"><?php echo $total_paid; ?></span>
                    <i class="fa fa-dollar red"></i> <p style="font-size:14px;">إجمالي المدفوع للكل</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4" style="float:right;">
					<a class="btn btn-app" style="width:100%;height:70px;float:right;">
                    <span style="font-size:12px;" class="badge bg-green"><?php echo $ls_recevable; ?></span>
                    <i class="fa fa-dollar green"></i> <p style="font-size:14px;">إجمالي المتبقي من القضايا</p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4" style="float:right;">
					<a class="btn btn-app" style="width:100%;height:70px;float:right;">
                    <span style="font-size:12px;" class="badge bg-blue"><?php echo $con_recevable; ?></span>
                    <i class="fa fa-dollar blue"></i> <p style="font-size:14px;">إجمالي المتبقي من الاستشارات </p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4" style="float:right;">
					<a class="btn btn-app" style="width:100%;height:70px;float:right;">
                    <span style="font-size:12px;" class="badge bg-red"><?php echo $total_recevable; ?></span>
                    <i class="fa fa-dollar red"></i> <p style="font-size:14px;">إجمالي المتبقي من الكل </p> 
                  </a></div>
                  <div class="col-md-3  col-sm-4" style="float:right;">
					<a class="btn btn-app" style="width:100%;height:70px;float:right;">
                    <span style="font-size:12px;" class="badge bg-red"><?php echo $total_expense; ?></span>
                    <i class="fa fa-line-chart red"></i> <p style="font-size:14px;">إجمالي المصروفات </p> 
                  </a></div>
                 
         
          </div>
        </div>
              </div>
            </div>
                </div>
              </div>

       
            </div>

          </div>
        </div>
      
                
                 <?php
                }
            
            ?>
                
                
        <footer style="background:#00504d;">
          <div class="pull-right">
           
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- compose -->
    <div class="compose col-md-6  ">
      <div class="compose-header">
        New Message
        <button type="button" class="close compose-close">
          <span>×</span>
        </button>
      </div>

      <div class="compose-body">
        <div id="alerts"></div>

        <div class="btn-toolbar editor" data-role="editor-toolbar" data-target="#editor">
          <div class="btn-group">
            <a class="btn dropdown-toggle" data-toggle="dropdown" title="Font"><i class="fa fa-font"></i><b class="caret"></b></a>
            <ul class="dropdown-menu">
            </ul>
          </div>

          <div class="btn-group">
            <a class="btn dropdown-toggle" data-toggle="dropdown" title="Font Size"><i class="fa fa-text-height"></i>&nbsp;<b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li>
                <a data-edit="fontSize 5">
                  <p style="font-size:17px">Huge</p>
                </a>
              </li>
              <li>
                <a data-edit="fontSize 3">
                  <p style="font-size:14px">Normal</p>
                </a>
              </li>
              <li>
                <a data-edit="fontSize 1">
                  <p style="font-size:11px">Small</p>
                </a>
              </li>
            </ul>
          </div>

          <div class="btn-group">
            <a class="btn" data-edit="bold" title="Bold (Ctrl/Cmd+B)"><i class="fa fa-bold"></i></a>
            <a class="btn" data-edit="italic" title="Italic (Ctrl/Cmd+I)"><i class="fa fa-italic"></i></a>
            <a class="btn" data-edit="strikethrough" title="Strikethrough"><i class="fa fa-strikethrough"></i></a>
            <a class="btn" data-edit="underline" title="Underline (Ctrl/Cmd+U)"><i class="fa fa-underline"></i></a>
          </div>

          <div class="btn-group">
            <a class="btn" data-edit="insertunorderedlist" title="Bullet list"><i class="fa fa-list-ul"></i></a>
            <a class="btn" data-edit="insertorderedlist" title="Number list"><i class="fa fa-list-ol"></i></a>
            <a class="btn" data-edit="outdent" title="Reduce indent (Shift+Tab)"><i class="fa fa-dedent"></i></a>
            <a class="btn" data-edit="indent" title="Indent (Tab)"><i class="fa fa-indent"></i></a>
          </div>

          <div class="btn-group">
            <a class="btn" data-edit="justifyleft" title="Align Left (Ctrl/Cmd+L)"><i class="fa fa-align-left"></i></a>
            <a class="btn" data-edit="justifycenter" title="Center (Ctrl/Cmd+E)"><i class="fa fa-align-center"></i></a>
            <a class="btn" data-edit="justifyright" title="Align Right (Ctrl/Cmd+R)"><i class="fa fa-align-right"></i></a>
            <a class="btn" data-edit="justifyfull" title="Justify (Ctrl/Cmd+J)"><i class="fa fa-align-justify"></i></a>
          </div>

          <div class="btn-group">
            <a class="btn dropdown-toggle" data-toggle="dropdown" title="Hyperlink"><i class="fa fa-link"></i></a>
            <div class="dropdown-menu input-append">
              <input class="span2" placeholder="URL" type="text" data-edit="createLink" />
              <button class="btn" type="button">Add</button>
            </div>
            <a class="btn" data-edit="unlink" title="Remove Hyperlink"><i class="fa fa-cut"></i></a>
          </div>

          <div class="btn-group">
            <a class="btn" title="Insert picture (or just drag & drop)" id="pictureBtn"><i class="fa fa-picture-o"></i></a>
            <input type="file" data-role="magic-overlay" data-target="#pictureBtn" data-edit="insertImage" />
          </div>

          <div class="btn-group">
            <a class="btn" data-edit="undo" title="Undo (Ctrl/Cmd+Z)"><i class="fa fa-undo"></i></a>
            <a class="btn" data-edit="redo" title="Redo (Ctrl/Cmd+Y)"><i class="fa fa-repeat"></i></a>
          </div>
        </div>

        <div id="editor" class="editor-wrapper"></div>
      </div>

      <div class="compose-footer">
        <button id="send" class="btn btn-sm btn-success" type="button">Send</button>
      </div>
    </div>
    <!-- /compose -->

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>

  </body>
</html>