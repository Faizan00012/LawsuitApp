
 
<?php
include_once 'connection.php';
$conn;                         
$conn = new mysqli($servername, $username, $password, $dbname);
if($conn->connect_error) {   die("Connection failed: " . $conn->connect_error);
} 
$logo="";
$sql1="SELECT set_logo  from settings";
$result = $conn->query($sql1);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $logo="uploads/".$row["set_logo"];
    }

}
if($_SESSION["customer_lang"]=="en"){
?>
<body class="nav-md">
    <div style="background:#00504d"  class="container body">
      <div style="background:#00504d"  class="main_container">    
<div style="background:#00504d"  class="col-md-3 left_col">

          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="" class="site_title"><i class="fa fa-laptop"></i> <span>Omar Al Shamsi</span></a>
               
            </div>

            <div class="clearfix"></div>

            <br />

            <!-- sidebar menu -->
                <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                 
                   
                <h2 style="color:white">&nbsp;&nbsp;&nbsp;Customer Profile</h2>
                  
                
              </div>
     

            </div>
          

            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
              
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="customer_login.php">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
</div>
<?php
  }
else{
     ?>
<body style="background:#00504d" class="nav-md">
    <div style="background:#00504d"  class="container body">
       <div style="background:#00504d" dir="rtl" class="main_container">
<div style="background:#00504d" class="col-md-3 left_col">
          <div style="background:#00504d" class="left_col scroll-view">
            <div style="background:#ededed;height:130px;"  class="navbar nav_title" style="border: 0;     background: #ededed;">
              <img src="<?php echo $logo; ?>" style="padding:10px;width:220px; height:120px;">
               
            </div>

            <div class="clearfix"></div>

            <br />

            <!-- sidebar menu -->
                 <div style="background:#00504d" id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                 
                   
                <h2 style="color:white">&nbsp;&nbsp;&nbsp; الشخصي عميل</h2>
                  
                
              </div>
     

            </div>
          

            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
              
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="customer_login.php">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
</div>

<?php
    }
?>
        <!-- top navigation -->

        <div class="top_nav">
            <div class="nav_menu">
               
                <div class="nav toggle">
                  <a id="menu_toggle"><i class="fa fa-bars"></i></a>
                </div>
                
                <nav class="nav navbar-nav">
                       
                <ul class=" navbar-right">
                    
                  <li class="nav-item dropdown open" style="padding-left: 15px;">
                    <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                      <b> 
                          <?php if($_SESSION["customer_lang"]=="en"){
                          ?>User: 
                          <?php  
                          }else{?>
                            المستخدمون:
                            <?php
                          }  
                          ?> <?php echo $user; ?></b>
                    </a>
                    <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
                      
                      <a class="dropdown-item"  href="customer_login.php"><i class="fa fa-sign-out pull-right"></i><?php 
                             if($_SESSION["customer_lang"]=="en"){
                                echo "Log Out";
                            }
                            else{
                                 echo "تسجيل خروج";
                            }
                            ?></a>
                    </div>
                  </li>
     
                    
                </ul>
              </nav>
                
              
                
            </div>
          
          </div>
 