<?php
include_once 'header_file.php';
include_once 'connection.php';
$conn;
$id = $_GET['id'];
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  
    <title>Add Payment</title>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="navcode.css">
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <?php include 'nav.php';  ?>

        <!-- page content -->
       
              
        <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
 
            <div class="clearfix"></div>
            <?php
            $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT con.cled_id, con.cled_paid, con.cled_du, c.total_amount from consultation_ledger con INNER JOIN consultation c ON con.con_id=c.con_id where con.con_id=".$id;
       
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      ?>
            
             <form action="" method="post">
            <div class="col-md-12 ">

			 
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Add New Payment </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div dir="ltr" class="x_content">
                    <br />
                    

                      
                      
                      <div class="col-md-4 col-sm-6  form-group">
                          <label><b>Total Amount:</b> <?php echo $row["total_amount"]; ?></label>
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                          <label><b>Paid Amount:</b> <?php echo $row["cled_paid"]; ?></label>
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                          <label><b>Receivable (To be Paid By Customer) Amount: </b><?php echo $row["cled_du"]; ?></label>
                      </div>
                      
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>Pay Amount</label>
                    <input type="text" name="that_about" class="form-control" id="total" placeholder="<?php echo $row["total_amount"]; ?>">
                      </div>
                     
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>That About</label>
                    <input type="text" name="that_about" class="form-control" id="total" placeholder="">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                             <label>Payment Method</label>
                    <input type="text" name="that_about" class="form-control" id="total" placeholder="">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                             <label>Date</label>
                    <input type="date" name="that_about"  class="form-control" id="total" >
                      </div>
                   <div class="form-group row">
                        <div class="col-md-9 col-sm-9  offset-md-4"><br>
                          <button style="width:30%" type="submit" name="submit" class="btn btn-success">Add Payment</button>
                        </div>
                      </div>

                     
                  </div>
                </div>
 
              


          
              
            </div>
            </form>
            <?php
    }
} else {
    echo "0 results";
}
            ?>
                  
            
           
        </div>
        <script>
         
        </script>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
     

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>
    <!-- jQuery Tags Input -->
    <script src="../vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
    <!-- Switchery -->
    <script src="../vendors/switchery/dist/switchery.min.js"></script>
    <!-- Select2 -->
    <script src="../vendors/select2/dist/js/select2.full.min.js"></script>
    <!-- Parsley -->
    <script src="../vendors/parsleyjs/dist/parsley.min.js"></script>
    <!-- Autosize -->
    <script src="../vendors/autosize/dist/autosize.min.js"></script>
    <!-- jQuery autocomplete -->
    <script src="../vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
    <!-- starrr -->
    <script src="../vendors/starrr/dist/starrr.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
	
  </body>
</html>
<?php
include_once 'connection.php';
$conn;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{
 
   
   $sql = "INSERT INTO expenses (b_id, exps_id, exp_name, exp_amount, exp_date, exp_method, exp_about, note) VALUES ('".$_POST["cons_branch"]."','".$_POST["cons_expsection"]."','".$_POST["exp_title"]."','".$_POST["exp_amount"]."','".$_POST["exp_date"]."','".$_POST["exp_paymethod"]."','".$_POST["that_about"]."','".$_POST["note"]."')";
 
if ($conn->query($sql) === TRUE) {
  echo "New Expense Added";
}else{
	echo "New Expense Not Added";
} 

}

$conn->close();
?>