<?php
 
$id = $_GET['id'];

include_once 'connection.php';
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// sql to delete a record

$sql = "DELETE FROM consultation_ledger WHERE con_id = {$id}";

if ($conn->query($sql) === TRUE) {
    
} else {
     
}

$sql = "DELETE FROM consultation WHERE con_id = {$id}";

if ($conn->query($sql) === TRUE) {
    
} else {
     
}
 
header("Location: consultation.php");

mysqli_close($conn);

?>
