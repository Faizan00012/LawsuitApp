<?php


$user_id = $_GET['id'];

include_once 'connection.php';
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// sql to delete a record
$sql = "DELETE FROM users WHERE user_id = {$user_id}";

if ($conn->query($sql) === TRUE) {
    
} else {
     
}
 
header("Location: users.php");

mysqli_close($conn);

?>
