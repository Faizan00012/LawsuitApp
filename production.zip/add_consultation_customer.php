<?php 
include_once 'connection.php';
$conn;
include_once 'header_file.php';
$c_id = $_GET['id'];
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  
    <title>Add Consultation</title>

    <!-- Bootstrap -->
    <?php
    if($_SESSION["lang_option"]=="en"){
        
           ?>
              <link rel="stylesheet" href="navcode1.css">
             <?php
    }
    else{
        
          ?>
              <link rel="stylesheet" href="navcode2.css">
             <?php
    }
    ?>
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
       <?php include 'nav.php';  ?>
    
                               
<?php if(isset($_POST['change_submit'])) {
      $_SESSION["lang_option"]=$_POST["langoption"];}

              if($_SESSION["lang_option"]=="en"){
                  ?>

                  
         <form action="" method="post">
              
        <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
 
            <div class="clearfix"></div>
            
                
            <div class="col-md-12 ">
               
			 <a href="Consultation.php" class="btn btn-dark btn-sm">Consultation</a>		
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Add New Consultation </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div dir="ltr" class="x_content">
                    <br />
                    

                        <div class="col-md-6 col-sm-6  form-group">
                            <select class="form-control" name="cons_branch">
                             <option>Select Branch Name</option>
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from branch";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["b_id"]."'>".$row["b_ar"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                     </div>
                      <div class="col-md-6 col-sm-6  form-group">
                            <select class="form-control" name="cons_customer">
                            <option>Select Customer Name</option>
                                 <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from customer";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["c_id"]."'>".$row["c_name"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                     </div>
                      
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                    <input type="text" required="required"  name="cons_subject" class="form-control" id="inputSuccess2" placeholder="Subject/Title of Consultation">
                      </div>
                      <div class="col-md-2 col-sm-6  form-group">
                    <input type="text" required="required"  name="cons_amount" onkeydown="AmountChange()"  class="form-control" id="amount" placeholder="Amount Contract">
                      </div>
                       <div class="col-md-2 col-sm-6  form-group">
                    <input type="text" required="required"  name="cons_tax" onkeydown="AmountChange()"  class="form-control" id="tax" placeholder="Tax Value">
                      </div>
                      <div class="col-md-2 col-sm-6  form-group">
                    <input type="text" required="required"  name="cons_total" class="form-control" id="total" placeholder="Total Amount incl Tax">
                      </div>
                    <div class="col-md-1 col-sm-6  form-group">
                   <label>Start Date</label>
                       </div>
                      <div class="col-md-2 col-sm-6  form-group">
                    <input type="date" required="required"  name="cons_start" class="form-control" id="inputSuccess2" placeholder="Start Date">
                      </div>
                     <div class="col-md-1 col-sm-6  form-group">
                   <label>End Date</label>
                       </div> 
                    <div class="col-md-2 col-sm-6  form-group">
                    <input type="date" required="required"  name="cons_end" class="form-control" id="inputSuccess2" placeholder="End Date">
                       </div>
                    
                       <div class="col-md-12 col-sm-6  form-group">
                   
                           <textarea placeholder="Contract Details ar" name="cus_detail_ar" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                   
                           <textarea placeholder="Contract Details en" name="cus_detail_en" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                     <div class="form-group row">
                        <div class="col-md-6 col-sm-9  offset-md-4"><br>
                          <button style="width:30%" type="submit" name="submit" class="btn btn-success btn-sm">Add Consultation</button>
                        </div>
                      </div>

                     
                  </div>
                </div>
 
              


          
              
            </div>

            
           </form>  
                   <?php
              }
                else
                {
                ?>
            <form style="font-size:20px;" method="post">
              
        <div dir="" style="width:100%" lang="ar" class="right_col" role="main">
 
            <div class="clearfix"></div>
            
                
            <div class="col-md-12 ">
                <a style="float:right;font-size:20px;padding-left:20px;padding-right:20px;" href="consultation.php" class="btn btn-dark btn-sm">الاستشارات</a></a>
			
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="float:right;font-size:24px;">إنشاء استشارة جديدة</h2>
                 
                    <div class="clearfix"></div>
                  </div>
                   <div dir="rtl" class="x_content">
                    <br />
                    

                        <div class="col-md-6 col-sm-6  form-group">
                            <select style="font-size:20px;" class="form-control" name="cons_branch">
                             <option>اختر فرع</option>
                                <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from branch";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["b_id"]."'>".$row["b_ar"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                     </div>
                      <div class="col-md-6 col-sm-6  form-group">
                            <select   style="font-size:20px;"  class="form-control" name="cons_customer">
                            <option>اختر عميل</option>
                                 <?php 
                            $conn = new mysqli($servername, $username, $password, $dbname);
                             
                                $sql1="SELECT * from customer";
                    $result = $conn->query($sql1);
                    if ($result->num_rows > 0) {
                        
             while($row = $result->fetch_assoc()) {  
          
                 echo "<option  value='".$row["c_id"]."'>".$row["c_name"]."</option>";
             }} else {} $conn->close();?>
                            </select>
                     </div>
                      
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                    <input  dir="rtl"   style="font-size:20px;"  type="text" required="required"  name="cons_subject" class="form-control" id="inputSuccess2" placeholder="موضوع/عنوان الاستشارة">
                      </div>
                      <div class="col-md-2 col-sm-6  form-group">
                    <input  dir="rtl"   style="font-size:20px;"  type="text" required="required"  name="cons_amount" onkeydown="AmountChange()"  class="form-control" id="amount" placeholder="مبلغ العقد">
                      </div>
                       <div class="col-md-2 col-sm-6  form-group">
                    <input  dir="rtl"   style="font-size:20px;"  type="text" required="required"  name="cons_tax" onchange="AmountChange()"  class="form-control" id="tax" placeholder="قيمة الصريبة">
                      </div>
                      <div class="col-md-2 col-sm-6  form-group">
                    <input  dir="rtl"   style="font-size:20px;"  type="text" required="required"  name="cons_total" class="form-control" id="total" placeholder="مبلغ العقد شامل الضريبة">
                      </div>
                    <div class="col-md-1 col-sm-6  form-group">
                   <label>تتاريخ بداية العقد</label>
                       </div>
                      <div class="col-md-2 col-sm-6  form-group">
                    <input   style="font-size:20px;"  type="date" required="required"  name="cons_start" class="form-control" id="inputSuccess2">
                      </div>
                     <div class="col-md-1 col-sm-6  form-group">
                   <label>تاريخ نهاية العقد</label>
                       </div> 
                    <div class="col-md-2 col-sm-6  form-group">
                    <input   style="font-size:20px;"  type="date" required="required"  name="cons_end" class="form-control" id="inputSuccess2">
                       </div>
                    
                       <div class="col-md-12 col-sm-6  form-group">
                   
                           <textarea dir="rtl"   style="font-size:20px;"  placeholder="شروط عقد الاستشارات عربي" name="cus_detail_ar" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                   
                           <textarea   dir="rtl"  style="font-size:20px;"  placeholder="شروط عقد الاستشارات انجليزي" name="cus_detail_en" class="form-control" style="width:100%;height:100px"></textarea>
                      </div>
                     <div class="form-group row">
                        <div class="col-md-9 col-sm-9  offset-md-4"><br>
                          <button   style="font-size:20px;padding-left:20px;padding-right:20px;"   type="submit" name="submit" class="btn btn-success btn-sm">إضافة</button>
                        </div>
                      </div>

                     
                  </div>
                </div>
 
              


          
              
            </div>

            
           </form>
                
                 <?php
                }
            
            ?>
                
                
          
          
         
        </div>
        <script>
        function AmountChange(){
            
       
            var amount=document.getElementById("amount").value;
           var tax=document.getElementById("tax").value;
            var per=parseInt(tax)/100*parseInt(amount);
             
              var total_amount=parseInt(document.getElementById("amount").value)+per;
            document.getElementById("total").value=total_amount;
        }
        </script>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
           
        </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
     

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>
    <!-- jQuery Tags Input -->
    <script src="../vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
    <!-- Switchery -->
    <script src="../vendors/switchery/dist/switchery.min.js"></script>
    <!-- Select2 -->
    <script src="../vendors/select2/dist/js/select2.full.min.js"></script>
    <!-- Parsley -->
    <script src="../vendors/parsleyjs/dist/parsley.min.js"></script>
    <!-- Autosize -->
    <script src="../vendors/autosize/dist/autosize.min.js"></script>
    <!-- jQuery autocomplete -->
    <script src="../vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
    <!-- starrr -->
    <script src="../vendors/starrr/dist/starrr.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
	
  </body>
</html>
<?php
include_once 'connection.php';
$conn;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{
 $con_id=0;
    $sql = "INSERT INTO consultation (b_id, c_id,con_subject, amount_contract, tax, total_amount, start_date, end_date, con_detail_ar, con_detail_en, created_at) VALUES ('".$_POST["cons_branch"]."','".$c_id."','".$_POST["cons_subject"]."','".$_POST["cons_amount"]."','".$_POST["cons_tax"]."','".$_POST["cons_total"]."','".$_POST["cons_start"]."','".$_POST["cons_end"]."','".$_POST["cus_detail_ar"]."','".$_POST["cus_detail_en"]."', '".date('Y-m-d')."')";
 
if ($conn->query($sql) === TRUE) {
  echo "New Consultation Added";
}else{
	echo "New Consultation Not Added";
}
    
$sql = "SELECT con_id FROM consultation";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $con_id= $row["con_id"];
    }
} 
    
     $sql = "INSERT INTO consultation_ledger (con_id, cled_paid, cled_du, cled_method, cled_about, cled_date) VALUES ('".$con_id."','0','".$_POST["cons_total"]."','no Payment','','".date('Y-m-d')."')";
 
if ($conn->query($sql) === TRUE) {
  
}else{
	 
} 

}

$conn->close();
?>