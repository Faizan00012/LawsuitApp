
 
<?php
include_once 'header_file.php';
include_once 'connection.php';
$conn;                         
$conn = new mysqli($servername, $username, $password, $dbname);
if($conn->connect_error) {   die("Connection failed: " . $conn->connect_error);
} 
						  
function function_alert($message) {
      
    // Display the alert box 
}
$role_id="";
$user_id="";
$app_dashboard="";
$app_setting="";
$app_customer="";
$app_customerType="";
$app_lawsuit="";
$app_add_lawsuit="";
$app_lawsuit_type="";
$app_stage="";
$app_state="";
$app_task="";
$app_apeal="";
$app_session="";
$app_pament_ls="";
$app_paper="";
$app_add_consult="";
$app_consultation="";
$app_payment_consult="";
$app_expense="";
$app_expense_Section="";
$app_annual_report="";
$app_monthly_report="";
$app_customer_report="";
$app_lawsuit_report="";
$app_session_report="";
$app_payment_laysuit_report="";
$app_consultation_report="";
$app_payment_consultation_report="";
$app_expernse_report="";
$app_branches="";
$roll_name="";
$logo="";
$sql1="SELECT set_logo  from settings";
$result = $conn->query($sql1);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $logo="uploads/".$row["set_logo"];
    }

}
if ($_SESSION["user_id"]!=""){
$sql1="SELECT user_id, roll from users where user_id=".$_SESSION["user_id"];
$result = $conn->query($sql1);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $role_id=$row["roll"];
        $user_id=$row["user_id"];
    }
}
}
$name_session="";
$session_check=false;
 //echo "<script>alert('".date("Y-m-d")."');</script>";
$sql1="SELECT session_name from session where session_date ='".date("Y-m-d")."'";
$result = $conn->query($sql1);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $name_session=$row["session_name"];
        $session_check=true;
         }
}
$sql1="SELECT * from roll where roll_id=".$role_id;
$result = $conn->query($sql1);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $roll_name=$row["roll_name"];
        $app_dashboard=$row["app_dashboard"];
$app_setting=$row["app_setting"];
$app_customer=$row["app_customer"];
$app_customerType=$row["app_customerType"];
$app_lawsuit=$row["app_lawsuit"];
$app_add_lawsuit=$row["app_add_lawsuit"];
$app_lawsuit_type=$row["app_lawsuit_type"];
$app_stage=$row["app_stage"];
$app_state=$row["app_state"];
$app_task=$row["app_task"];
$app_apeal=$row["app_apeal"];
$app_session=$row["app_session"];
$app_pament_ls=$row["app_pament_ls"];
$app_paper=$row["app_paper"];
$app_add_consult=$row["app_add_consult"];
$app_consultation=$row["app_consultation"];
$app_payment_consult=$row["app_payment_consult"];
$app_expense=$row["app_expense"];
$app_expense_Section=$row["app_expense_Section"];
$app_annual_report=$row["app_annual_report"];
$app_monthly_report=$row["app_monthly_report"];
$app_customer_report=$row["app_customer_report"];
$app_lawsuit_report=$row["app_lawsuit_report"];
$app_session_report=$row["app_session_report"];
$app_payment_laysuit_report=$row["app_payment_laysuit_report"];
$app_consultation_report=$row["app_consultation_report"];
$app_payment_consultation_report=$row["app_payment_consultation_report"];
$app_expernse_report=$row["app_expernse_report"];
$app_branches=$row["app_branches"];

    }
}
   
 
   $alert_color="#00504d";
if($_SESSION["lang_option"]=="en"){
    ?>
<body style="background:#00504d line-height: 1.2;
  
    font-size: .8rem;" class="nav-md">
    <?php if ($session_check==true){
     $alert_color="red";
    ?>
     <div class="callout">
  <div class="callout-header">Alert: Session </div>
  <span class="closebtn" onclick="this.parentElement.style.display='none';">×</span>
   
</div>
    <?php
    }
    else{
        $alert_color="#00504d";
    }
    ?>
    
   
    <div class="container body">
       <div style="" dir="rtl" class="main_container">
           
<div>
    <table  style="width:100%;background: white;">
    <tr>
        <td style="float:left;width: 30%;">
     <img  src="<?php echo $logo; ?>" style="padding-left: 0%;width:120px;height: auto">
        </td>
         <td style="float:right;width: 40%;">
             <table style="float: right;margin-right: 5%;width: 150px;margin-top:52px">
             <tr>
                 <td>         
            <a style="font-size:28px;color:#00504d;padding-bottom:3px;padding-top:3px;padding-left:10px;padding-right:10px;border:transparent;border-radius:4px;text-decoration:none" href="logout.php" ><i class="fa fa-power-off"> </i></a>
            </td>
             <td>         
            <a style="font-size:28px;color:<?php echo $alert_color; ?>;padding-bottom:3px;padding-top:3px;padding-left:10px;padding-right:10px;border:transparent;border-radius:4px;text-decoration:none" href="notification.php" ><i class="fa fa-bell"> </i></a>
            </td>
                 <td>
                 <form action="" method="post">
                <input type="submit" name="change_submit_en" value="English" style="color:white;width:180px;border:transparent;border-radius:4px;background:#00504d">
                </form></td>
                 
                 </tr>
             
             </table>
             
             
           
        
            
             
         </td>
        
    </tr>
    </table>
    </div>
<!--- navbar--->
  <div class="topnav1" id="myTopnav1">
  <?php if($app_dashboard=="1"){?>
               <a href="dashboard.php"><i class="fa fa-home"> Dashboard</i> </a>
                    <?php }
                    else{ ?>
                      <a href="screen.php"><i class="fa fa-home"> Dashboard</i> </a>  
                   <?php } 
        if($app_customer=="1" || $app_customerType=="1"){?>
    <div class="dropdown1"><button class="dropbtn"><i class="fa fa-users"> Customer</i></button><div class="dropdown1-content">
                        <?php if($app_customer=="1"){?>
                 <a href="customer.php">Customer</a>  <?php }?>
                      <?php if($app_customer=="1"){?>
                    <a href="customertype.php">Customer Type</a> <?php }?>
                      
                    </div>
  </div> 
                    <?php }    
            
                 if($app_lawsuit=="1" || $app_add_lawsuit=="1" || $app_lawsuit_type=="1" || $app_stage=="1" || $app_state=="1" || $app_task=="1" || $app_apeal=="1" || $app_session=="1" || $app_payment_laysuit_report=="1" || $app_paper=="1"){?>
    <div class="dropdown1"><button class="dropbtn"><i class="fa fa-legal"> Lawsuits</i></button><div class="dropdown1-content">
                        <div class=row>
                             <div class="col-lg-6 col-md-6">
                                <?php if($app_session=="1"){?>
                        <a href="session.php">Session</a>
                        <a href="imagefile.php">Image and File</a><hr><?php }
                        else{
                            echo '<a style="background-color:#f9f9f9;">Session</a>';
                             echo '<a style="background-color:#f9f9f9;">Image and File</a><hr>';
                        }
                         ?>
                         <?php if($app_payment_laysuit_report=="1"){?>
                         <a href="payment_lw.php">Payments Lawsuit</a><?php }
                        else{
                            echo '<a style="background-color:#f9f9f9;">Payments Lawsuit</a>';
                        }
                         ?>
                        <?php if($app_paper=="1"){?>
                        <a href="paper.php">Paper</a><?php }
                        else{
                            echo '<a style="background-color:#f9f9f9;">Paper</a>';
                        }
                         ?>
                        </div>
                            <div class="col-lg-6 col-md-6">
                                 <?php if($app_lawsuit=="1"){?>
                        <a href="lawsuit.php">Lawsuit</a><?php }
                        else{
                            echo '<a style="background-color:#f9f9f9;">Lawsuit</a>';
                        }
                         ?>
                        <?php if($app_add_lawsuit=="1"){?>
                        <a href="add_lawsuit.php">Add Lawsuit</a><?php }
                        else{
                            echo '<a style="background-color:#f9f9f9;">AddLawsuit</a>';
                        }
                         ?>
                        <?php if($app_lawsuit_type=="1"){?>
                                <hr>
                        <a href="lawsuit_type.php">Lawsuit Type</a><?php }
                        else{
                            
                            echo '<hr><a style="background-color:#f9f9f9;">Lawsuit Type</a>';
                        }
                         ?>
                        <?php if($app_state=="1"){?>
                        <a href="states.php">States</a><?php }
                        else{
                            echo '<a style="background-color:#f9f9f9;">States</a>';
                        }
                         ?>
                        <?php if($app_stage=="1"){?>
                        <a href="stages.php">Stages</a><?php }
                        else{
                            echo '<a style="background-color:#f9f9f9;">Stages</a>';
                        }
                         ?>
                        <?php if($app_stage=="1"){?>
                        
                                <hr><a href="notification.php">All Notification</a><?php }
                        else{
                            echo '<hr><a style="background-color:#f9f9f9;">All Notification</a>';
                        }
                         ?>
                                <?php if($app_task=="1"){?>
                        <a href="task.php">Task</a><?php }
                        else{
                            echo '<a style="background-color:#f9f9f9;">Task</a>';
                        }
                         ?>
                                <?php if($app_apeal=="1"){?>
                        <a href="apeal_date.php">Apeal Date</a><?php }
                        else{
                            echo '<a style="background-color:#f9f9f9;">Apeal Date</a>';
                        }
                         ?>
                            </div>
                            
                           </div>
        
        
        <?php } ?>
                          
                          
                            </div>
                            
                        </div>
                        
                        
                       
                       
  
                     
                         
                        
                      <?php   if($app_add_consult=="1" || $app_consultation=="1" || $app_payment_consult=="1"){?>
                            <div class="dropdown1"><button class="dropbtn"><i class="fa fa-book"> Consultation</i></button><div class="dropdown1-content"> 
 
                         <?php if($app_add_consult=="1"){ ?>
                      <a href="add_consultation.php">Add New Consultation</a><?php }?>
                         <?php if($app_consultation=="1"){?>
                      <a href="consultation.php">Consultations</a><?php }?>
                         <?php if($app_payment_consult=="1"){?>
                      <a href="consultation_payment.php">Payment Consultations</a> <?php }?>
                       </div></div> <?php } ?>
                       
                        <?php   if($app_expense=="1" || $app_expense_Section=="1"){?>
                            <div class="dropdown1"><button class="dropbtn"><i class="fa fa-bar-chart-o"> Expenses</i></button><div class="dropdown1-content"> 
 
                         <?php if($app_expense=="1"){ ?>
                      <a href="expense.php">Expenses</a><?php }?>
                         <?php if($app_expense_Section=="1"){?>
                      <a href="expense_section.php">Expense Sections</a><?php }?>
                         </div></div> <?php } ?>
                         
                             <?php   if($app_annual_report=="1" || $app_monthly_report=="1"|| $app_customer_report=="1"|| $app_lawsuit_report=="1"|| $app_session_report=="1"|| $app_payment_laysuit_report=="1"|| $app_consultation_report=="1"|| $app_payment_consultation_report=="1" || $app_expernse_report=="1" ){?>              
              
                            <div class="dropdown1"><button class="dropbtn"><i class="fa fa-clone"> Reports</i></button><div class="dropdown1-content"> 
 
                       <?php if($app_annual_report=="1"){?>
                      <a href="annual_report.php">Annual Report</a><?php }?>
                        <?php if($app_monthly_report=="1"){?>
                      <a href="monthly_report.php">Monthly Report</a><?php }?>
                        <?php if($app_customer_report=="1"){?>
                      <a href="customer_report.php">Customer Report</a><?php }?>
                        <?php if($app_lawsuit_report=="1"){?>
                      <a href="lawsuit_report.php">Lawsuit Report</a><?php }?>
                        <?php if($app_session_report=="1"){?>
                      <a href="sessions_report.php">Sessions Report</a><?php }?>
                        <?php if($app_payment_laysuit_report=="1"){?>
                      <a href="payment_lawsuit_report.php">Payments Lawsuit Report</a><?php }?>
                        <?php if($app_consultation_report=="1"){?>
                     <a href="consultation_report.php">Consultation Report</a><?php }?>
                        <?php if($app_payment_consultation_report=="1"){?>
                    <a href="payments_consultaion_report.php">Payments Consultaion Report</a><?php }?>
                        <?php if($app_expernse_report=="1"){?>
                         <a href="expense_report.php">Expense Report</a><?php }?>
                         </div></div> <?php } ?>
                         
 
                         
                           
   <?php if($app_branches=="1"){?>
               <a href="branch.php"><i class="fa fa-building"> Branches</i> </a>
                    <?php } ?>
       
              <?php if($role_id==16){?> 
       <div class="dropdown1"><button class="dropbtn"><i class="fa fa-gear"> Settings</i></button><div class="dropdown1-content"> 
                    <a href="settings.php">Setting</a>
                         <a href="users.php">Users</a>
                         <a href="role.php">Role</a>
                   
               </div>
               </div>
                 <?php } ?>
  
  
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction1()">&#9776;</a>
</div>
 

<script>
function myFunction1() {
  var x = document.getElementById("myTopnav1");
  if (x.className === "topnav1") {
    x.className += " responsive";
  } else {
    x.className = "topnav1";
  }
}
</script>  
<?php
  }
else{
     ?>
     
<body style="background:#00504d" class="nav-md">
    <div class="container body">
       <div style="" dir="rtl" class="main_container">
           
<div>
    <table  style="width:100%;background: white;">
    <tr>
        <td style="float:left;width: 30%;margin-top:5px">
        <img  src="<?php echo $logo; ?>" style="padding-left: 0%;width:120px;height: auto">
        </td>
         <td style="float:right;width: 40%;">
             <table style="float: right;margin-right: 5%;width: 150px;margin-top:52px">
             <tr>
                   <td>         
            <a style="font-size:28px;color:#00504d;padding-bottom:3px;padding-top:3px;padding-left:10px;padding-right:10px;border:transparent;border-radius:4px;text-decoration:none" href="logout.php" ><i class="fa fa-power-off"> </i></a>
            </td>
             <td>         
            <a style="font-size:28px;color:#00504d;padding-bottom:3px;padding-top:3px;padding-left:10px;padding-right:10px;border:transparent;border-radius:4px;text-decoration:none" href="notification.php" ><i class="fa fa-bell"> </i></a>
            </td>
                 
                 
                <td>
                     
                      <form action="" method="post">
                <input type="submit" name="change_submit_ar" value="تغيير اللغة"     style="color:white;width:180px;border:transparent;border-radius:4px;background:#00504d">
                </form>
                 </td>
                
                 </tr>
             
             </table>
             
             
           
        
            
             
         </td>
        
    </tr>
    </table>
    </div>
<!--- navbar--->
 
  <div class="topnav1" id="myTopnav1">
      
   <?php if($app_dashboard=="1"){?>
               <a href="dashboard.php" ><i class="fa fa-home"> الرئيسية</i> </a>
                <?php }
                    else{ ?>
                      <a href="screen.php"><i class="fa fa-home"> الرئيسية</i> </a>  
                   <?php } 
               
    
    
    
    
        if($app_customer=="1" || $app_customerType=="1"){?>
    <div class="dropdown1"><button class="dropbtn" ><i class="fa fa-users"> العملاء</i></button><div class="dropdown1-content">
                        <?php if($app_customer=="1"){?>
                 <a href="customer.php">العملاء</a>  <?php }?>
                      <?php if($app_customer=="1"){?>
                    <a href="customertype.php"> أنواع  العملاء</a> <?php }?>
                      
                    </div>
  </div> 
                    <?php }    
                    
                    
      
                 if($app_lawsuit=="1" || $app_add_lawsuit=="1" || $app_lawsuit_type=="1" || $app_stage=="1" || $app_state=="1" || $app_task=="1" || $app_apeal=="1" || $app_session=="1" || $app_payment_laysuit_report=="1" || $app_paper=="1"){?>
    <div class="dropdown1"><button class="dropbtn"><i class="fa fa-legal"> القضايا</i></button><div class="dropdown1-content">
                         <div class=row>
                            <div class="col-lg-6 col-md-6">
                                 <?php if($app_lawsuit=="1"){?>
                        <a href="lawsuit.php">القضايا</a><?php }
                        else{ echo '<a style="background-color:#f9f9f9;">القضايا</a>';    } ?>
                        <?php if($app_add_lawsuit=="1"){?>
                        <a href="add_lawsuit.php">إضافة قضية جديدة</a><?php }
                        else{ echo '<a style="background-color:#f9f9f9;">إضافة قضية جديدة</a>';    } ?>
                        <?php if($app_lawsuit_type=="1"){?>
                        <a href="lawsuit_type.php">أنواع القضايا</a><?php }
                        else{ echo '<a style="background-color:#f9f9f9;">أنواع القضايا</a>';    } ?>
                        <?php if($app_state=="1"){?>
                        <a href="states.php">حالات القضية</a><?php }
                        else{ echo '<a style="background-color:#f9f9f9;">حالات القضية</a>';    } ?>
                        <?php if($app_stage=="1"){?>
                        <a href="stages.php">مراحل التقاضي</a><?php }
                        else{ echo '<a style="background-color:#f9f9f9;">مراحل التقاضي</a>';    } ?>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <?php if($app_task=="1"){?>
                        <a href="task.php">مهمة</a><?php }
                        else{ echo '<a style="background-color:#f9f9f9;">مهمة</a>';    } ?>
                        <?php if($app_apeal=="1"){?>
                        <a href="apeal_date.php">مواعيد الاستئناف</a><?php }
                        else{ echo '<a style="background-color:#f9f9f9;">مواعيد الاستئناف</a>';    } ?>
                        <?php if($app_session=="1"){?>
                        <a href="session.php">عرض جميع الجلسات</a>
                        <a href="imagefile.php">صورة وملفات القضية</a><?php }
                        else{ echo '<a style="background-color:#f9f9f9;">عرض جميع الجلسات</a>';
                            echo '<a style="background-color:#f9f9f9;">صورة وملفات القضية</a>'; } ?>
                        <?php if($app_payment_laysuit_report=="1"){?>
                         <a href="payment_lw.php">مدفوعات القضايا</a><?php }
                        else{ echo '<a style="background-color:#f9f9f9;">مدفوعات القضايا</a>';    } ?>
                        <?php if($app_paper=="1"){?>
                        <a href="paper.php">صحائف الدعوى</a><?php }
                        else{ echo '<a style="background-color:#f9f9f9;">صحائف الدعوى</a>';    } ?>
                        </div></div> <?php } ?>
                            </div>
                            
                        </div>
                       
                       
  
                     
                         
                        
                      <?php   if($app_add_consult=="1" || $app_consultation=="1" || $app_payment_consult=="1"){?>
                            <div class="dropdown1"><button class="dropbtn"><i class="fa fa-book"> استشارات</i></button><div class="dropdown1-content"> 
 
                         <?php if($app_add_consult=="1"){ ?>
                      <a href="add_consultation.php">إنشاء استشارة جديدة</a><?php }?>
                         <?php if($app_consultation=="1"){?>
                      <a href="consultation.php">لاستشارات</a><?php }?>
                         <?php if($app_payment_consult=="1"){?>
                      <a href="consultation_payment.php">مدفوعات الاستشارات</a> <?php }?>
                       </div></div> <?php } ?>
                       
                        <?php   if($app_expense=="1" || $app_expense_Section=="1"){?>
                            <div class="dropdown1"><button class="dropbtn"><i class="fa fa-bar-chart-o"> المصروفات</i></button><div class="dropdown1-content"> 
 
                         <?php if($app_expense=="1"){ ?>
                      <a href="expense.php">المصروفات</a><?php }?>
                         <?php if($app_expense_Section=="1"){?>
                      <a href="expense_section.php">أقسام المصروفات</a><?php }?>
                         </div></div> <?php } ?>
                         
                             <?php   if($app_annual_report=="1" || $app_monthly_report=="1"|| $app_customer_report=="1"|| $app_lawsuit_report=="1"|| $app_session_report=="1"|| $app_payment_laysuit_report=="1"|| $app_consultation_report=="1"|| $app_payment_consultation_report=="1" || $app_expernse_report=="1" ){?>              
              
                            <div class="dropdown1"><button class="dropbtn"><i class="fa fa-clone"> التقارير</i></button><div class="dropdown1-content"> 
 
                       <?php if($app_annual_report=="1"){?>
                      <a href="annual_report.php" >التقرير السنوي</a><?php }?>
                        <?php if($app_monthly_report=="1"){?>
                      <a href="monthly_report.php">التقرير الشهري</a><?php }?>
                        <?php if($app_customer_report=="1"){?>
                      <a href="customer_report.php" >تقارير العملاء</a><?php }?>
                        <?php if($app_lawsuit_report=="1"){?>
                      <a href="lawsuit_report.php" >تقارير القضايا</a><?php }?>
                        <?php if($app_session_report=="1"){?>
                      <a href="sessions_report.php" >تقارير الجلسات</a><?php }?>
                        <?php if($app_payment_laysuit_report=="1"){?>
                      <a href="payment_lawsuit_report.php" >تقارير مدفوعات القضايا</a><?php }?>
                        <?php if($app_consultation_report=="1"){?>
                     <a href="consultation_report.php" >تقارير الاستشارة</a><?php }?>
                        <?php if($app_payment_consultation_report=="1"){?>
                    <a href="payments_consultaion_report.php" >تقارير مدفوعات الاستشارات</a><?php }?>
                        <?php if($app_expernse_report=="1"){?>
                         <a href="expense_report.php" >تقارير المصروفات</a><?php }?>
                         </div></div> <?php } ?>
                           
   <?php if($app_branches=="1"){?>
               <a href="branch.php" ><i class="fa fa-building"> الفروع</i> </a>
                    <?php } ?>
       
              <?php if($role_id==16){?> 
       <div class="dropdown1" ><button class="dropbtn"><i class="fa fa-gear"> الإعدادات</i></button>
       <div class="dropdown1-content"> 
                    <a href="settings.php" >الإعدادات</a>
                         <a href="users.php" >المستخدمين</a>
                         <a href="role.php" >الصلاحيات</a>
                   
               </div>
               </div>
                 <?php } ?>
  
  
  <a href="javascript:void(0);" style="font-size:15px; " class="icon" onclick="myFunction1()">&#9776;</a>
</div>

  
<script>
function myFunction1() {
  var x = document.getElementById("myTopnav1");
  if (x.className === "topnav1") {
    x.className += " responsive";
  } else {
    x.className = "topnav1";
  }
}
</script>  

<?php
    }
?>
        <!-- top navigation -->

      
 