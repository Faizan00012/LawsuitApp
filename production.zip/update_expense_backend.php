<?php
include_once 'connection.php';
$conn;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{

    $id=$_POST["exp_id"];
    $sql = "UPDATE expenses SET exp_name='".$_POST["exp_name"]."', exp_amount='".$_POST["exp_amount"]."', exp_date='".$_POST["exp_date"]."', exp_method='".$_POST["exp_method"]."', exp_about='".$_POST["exp_about"]."', note='".$_POST["note"]."' WHERE exp_id=".$id;
  
if ($conn->query($sql) === TRUE) {
        header('Location: expense.php');
  
} else {
    echo "Error updating record: " . $conn->error;
}
   
 
 

}

$conn->close();
?>