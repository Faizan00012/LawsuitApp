<?php
include_once 'connection.php';
$conn;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{

    $id=$_POST["task_id"];
    $sql = "UPDATE task SET completion_date='".$_POST["com_date"]."', task_status='".$_POST["status"]."', status_note='".$_POST["taskstatus"]."', note='".$_POST["note"]."' WHERE task_id=".$id;
  
if ($conn->query($sql) === TRUE) {
        header('Location: task.php');
  
} else {
    echo "Error updating record: " . $conn->error;
}
   
 
 

}

$conn->close();
?>