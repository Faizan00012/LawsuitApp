<?php 
include_once 'connection.php';
include_once 'header_file.php';
$conn;
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  
    <title>Update Consultation</title>

    <!-- Bootstrap -->
<?php
    if($_SESSION["lang_option"]=="en"){
        
           ?>
              <link rel="stylesheet" href="navcode1.css">
             <?php
    }
    else{
        
          ?>
              <link rel="stylesheet" href="navcode2.css">
             <?php
    }
    ?>
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
         <?php include 'nav.php';  ?>
        <!-- /top navigation -->


          <?php
          
          $c_id = $_GET['id'];

    $conn = new mysqli($servername, $username, $password, $dbname);
$sql = "SELECT * FROM consultation where con_id= {$c_id}";
$result = $conn->query($sql);
          
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
          
     
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                 $langoption=$_POST["langoption"];
                }
              if($langoption=="en"){
                  ?>
                 <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
 
            <div class="clearfix"></div>
             <form action="update_consultation_backend.php" method="post">
                
            <div class="col-md-12 ">
	
			
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Update Consultation </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div dir="ltr" class="x_content">
                    <br />
                    <div class="col-md-12 col-sm-6  form-group">
                        <label>Subject/Title of Consultation</label>
                    <input type="text"  value="<?php echo $row["con_subject"]; ?>" name="cons_subject" class="form-control" id="inputSuccess2" placeholder="Subject/Title of Consultation" >
                         <input type="hidden"  value="<?php echo $row["con_id"]; ?>" name="con_id" >
                        
                      </div>
                      
                      <div class="col-md-2 col-sm-6  form-group">
                            <label>Amount Contract</label>
                    <input type="text"  value="<?php echo $row["amount_contract"]; ?>" name="cons_amount"  class="form-control" id="amount" placeholder="Amount Contract">
                      </div>
                       <div class="col-md-2 col-sm-6  form-group">
                            <label>Tax Value</label>
                    <input type="text" name="cons_tax"  value="<?php echo $row["tax"]; ?>"  class="form-control" id="tax" placeholder="Tax Value">
                      </div>
                      <div class="col-md-2 col-sm-6  form-group">
                           <label>Total Amount incl Tax</label>
                    <input type="text" name="cons_total"  value="<?php echo $row["total_amount"]; ?>" class="form-control" id="total" placeholder="Total Amount incl Tax">
                      </div>
                
                      <div class="col-md-3 col-sm-6  form-group">
                            <label>Start Date</label>
                    <input type="date"  value="<?php echo $row["start_date"]; ?>" name="cons_start" class="form-control" id="inputSuccess2" placeholder="Start Date">
                      </div>
                   
                    <div class="col-md-3 col-sm-6  form-group">
                           <label>End Date</label>
                    <input type="date" name="cons_end" value="<?php echo $row["end_date"]; ?>" class="form-control" id="inputSuccess2" placeholder="End Date">
                       </div>
                    
                       <div class="col-md-12 col-sm-6  form-group">
                   <label>Contract Details AR</label>
                           <textarea placeholder="Contract Details ar" name="cus_detail_ar" class="form-control" style="width:100%;height:100px"><?php echo $row["con_detail_ar"]; ?></textarea>
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                   <label>Contract Details EN</label>
                           <textarea   placeholder="Contract Details en" name="cus_detail_en" class="form-control" style="width:100%;height:100px"><?php echo $row["con_detail_en"]; ?></textarea>
                      </div>
                     <div class="form-group row">
                        <div class="col-md-9 col-sm-9  offset-md-4"><br>
                          <button style="width:30%" type="submit" name="submit" class="btn btn-success">Update Consultation</button>
                        </div>
                      </div>

                       </div>
                  </div>
                </div>
            </form>
            </div>
              
                   <?php
              }
                else
                {
                ?>
      <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
 
            <div class="clearfix"></div>
             <form action="update_consultation_backend.php" method="post">
                
            <div class="col-md-12 ">
	
			
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Update Consultation </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
                    <div class="col-md-12 col-sm-6  form-group">
                        <label>موضوع/عنوان الاستشارة</label>
                    <input type="text"  value="<?php echo $row["con_subject"]; ?>" name="cons_subject" class="form-control" id="inputSuccess2" placeholder="Subject/Title of Consultation" >
                     <input type="hidden"  value="<?php echo $row["con_id"]; ?>" name="con_id" >
                        
                      </div>
                      
                      <div class="col-md-2 col-sm-6  form-group">
                            <label>مبلغ العقد</label>
                    <input type="text"  value="<?php echo $row["amount_contract"]; ?>" name="cons_amount"  class="form-control" id="amount" placeholder="Amount Contract">
                      </div>
                       <div class="col-md-2 col-sm-6  form-group">
                            <label>قيمة الصريبة</label>
                    <input type="text" name="cons_tax"  value="<?php echo $row["tax"]; ?>"  class="form-control" id="tax" placeholder="Tax Value">
                      </div>
                      <div class="col-md-2 col-sm-6  form-group">
                           <label>مبلغ العقد شامل الضريبة</label>
                    <input type="text" name="cons_total"  value="<?php echo $row["total_amount"]; ?>" class="form-control" id="total" placeholder="Total Amount incl Tax">
                      </div>
                
                      <div class="col-md-3 col-sm-6  form-group">
                            <label>تاريخ بداية العقد</label>
                    <input type="date"  value="<?php echo $row["start_date"]; ?>" name="cons_start" class="form-control" id="inputSuccess2" placeholder="Start Date">
                      </div>
                   
                    <div class="col-md-3 col-sm-6  form-group">
                           <label>تاريخ نهاية العقد</label>
                    <input type="date" name="cons_end" value="<?php echo $row["end_date"]; ?>" class="form-control" id="inputSuccess2" placeholder="End Date">
                       </div>
                    
                       <div class="col-md-12 col-sm-6  form-group">
                   <label>شروط عقد الاستشارات عربي</label>
                           <textarea placeholder="Contract Details ar" name="cus_detail_ar" class="form-control" style="width:100%;height:100px"><?php echo $row["con_detail_ar"]; ?></textarea>
                      </div>
                      <div class="col-md-12 col-sm-6  form-group">
                   <label>شروط عقد الاستشارات انجليزي</label>
                           <textarea   placeholder="Contract Details en" name="cus_detail_en" class="form-control" style="width:100%;height:100px"><?php echo $row["con_detail_en"]; ?></textarea>
                      </div>
                     <div class="form-group row">
                        <div class="col-md-9 col-sm-9  offset-md-4"><br>
                          <button style="width:30%" type="submit" name="submit" class="btn btn-success">تعديل استشارة</button>
                        </div>
                      </div>

                       </div>
                  </div>
                </div>
            </form>
            </div>
                
                 <?php
                }
            
            } } else {}?>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
     

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>
    <!-- jQuery Tags Input -->
    <script src="../vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
    <!-- Switchery -->
    <script src="../vendors/switchery/dist/switchery.min.js"></script>
    <!-- Select2 -->
    <script src="../vendors/select2/dist/js/select2.full.min.js"></script>
    <!-- Parsley -->
    <script src="../vendors/parsleyjs/dist/parsley.min.js"></script>
    <!-- Autosize -->
    <script src="../vendors/autosize/dist/autosize.min.js"></script>
    <!-- jQuery autocomplete -->
    <script src="../vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
    <!-- starrr -->
    <script src="../vendors/starrr/dist/starrr.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
	
  </body>
</html>
