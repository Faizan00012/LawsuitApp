<?php
include_once 'connection.php';
$conn;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{
 
        $id=$_POST["cus_id"];
    $sql = "UPDATE customer SET c_name='".$_POST["cus_name"]."', c_company='".$_POST["cus_company"]."', c_passport='".$_POST["cus_passport"]."', c_cr='".$_POST["cus_cr"]."', c_city='".$_POST["cus_city"]."', c_address='".$_POST["cus_address"]."', c_postbox='".$_POST["cus_post"]."', c_phone='".$_POST["cus_phone"]."', c_mobile='".$_POST["cus_mobile"]."', c_email='".$_POST["cus_email"]."', c_nationality='".$_POST["cus_nationality"]."', c_username='".$_POST["cus_username"]."', c_password='".$_POST["cus_password"]."', c_notes='".$_POST["cus_note"]."' WHERE c_id=".$id;
  
if ($conn->query($sql) === TRUE) {
        header('Location: customer.php');
  
} else {
    echo "Error updating record: " . $conn->error;
}
   
 
 

}

$conn->close();
?>