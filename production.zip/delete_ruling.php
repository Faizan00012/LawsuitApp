<?php

 
$id = $_GET['id'];

include_once 'connection.php';
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


$sql = "DELETE FROM ruling WHERE rl_id = {$id}";
 
if ($conn->query($sql) === TRUE) {
    
} else {
     
}
 
header("Location: apeal_date.php");

mysqli_close($conn);
 
?>
