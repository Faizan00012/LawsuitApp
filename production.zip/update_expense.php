<?php 
include_once 'connection.php';
include_once 'header_file.php';
$conn;
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  
    <title>Update Expense</title>

    <!-- Bootstrap -->
    <?php
    if($_SESSION["lang_option"]=="en"){
        
           ?>
              <link rel="stylesheet" href="navcode1.css">
             <?php
    }
    else{
        
          ?>
              <link rel="stylesheet" href="navcode2.css">
             <?php
    }
    ?>
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
         <?php include 'nav.php';  ?>
        <!-- /top navigation -->


          <?php
          
          $exp_id = $_GET['id'];

    $conn = new mysqli($servername, $username, $password, $dbname);
$sql = "SELECT * FROM expenses where exp_id= {$exp_id}";
$result = $conn->query($sql);
          
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
          ?>
          <?php
     
          if ($_SERVER["REQUEST_METHOD"] == "POST") {
                 $_SESSION["lang_option"]=$_POST["langoption"];
                }
              if($_SESSION["lang_option"]=="en"){
                  ?>
                   <form action="update_expense_backend.php" method="post">
        <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
 
            <div class="clearfix"></div>
            
                
                   <div class="col-md-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Update Expense </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div dir="ltr" class="x_content">
                    <br />

                        <div class="col-md-12 col-sm-6  form-group">
                            <label>The name of the expense is from him</label>
                    <input type="text" name="exp_name" value="<?php echo $row['exp_name']; ?>" class="form-control" id="inputSuccess2" placeholdeer="The name of the expense is from him">
                            <input type="hidden" name="exp_id" value="<?php echo $exp_id; ?>"> 
                      </div>
                      <div class="col-md-8 col-sm-6  form-group">
                          <label>Expense Amount</label>
                    <input type="text" name="exp_amount" value="<?php echo $row['exp_amount']; ?>" class="form-control" id="inputSuccess2" placeholdeer="Expense Amount">
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                          <label>Expense Date</label>
                    <input type="text" name="exp_date" value="<?php echo $row['exp_date']; ?>" class="form-control" id="inputSuccess2">
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                          <label>Payment Method</label>
                    <input type="text" name="exp_method" value="<?php echo $row['exp_method']; ?>"  class="form-control" id="inputSuccess2" placeholdeer="CR.No">
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                          <label>That About</label>
                    <input type="text" name="exp_about" value="<?php echo $row['exp_about']; ?>"  class="form-control" id="inputSuccess2" placeholdeer="City">
                      </div>
                       
                       <div class="col-md-12 col-sm-6  form-group">
                   <label>Notes</label>
                           <textarea placeholdeer="Note" name="note" class="form-control" style="width:100%;height:100px"><?php echo $row['note']; ?></textarea>
                      </div>
                     <div class="form-group row">
                        <div class="col-md-9 col-sm-9  offset-md-4"><br>
                          <button style="width:30%" type="submit" name="submit" class="btn btn-success">Update Customer</button>
                        </div>
                      </div>

                     
                  </div>
                </div>
 
              


              </div>
              
            </div>

            
           </form> 
              
                   <?php
              }
                else
                {
                ?>
             <form action="update_expense_backend.php" method="post">
       <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
 
            <div class="clearfix"></div>
            
                
                         <div class="col-md-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>إضافة مصروف جديد</h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />

                        <div class="col-md-12 col-sm-6  form-group">
                            <label>اسم المصروف له</label>
                    <input type="text" name="exp_name" value="<?php echo $row['exp_name']; ?>" class="form-control" id="inputSuccess2" placeholdeer="The name of the expense is from him">
                            <input type="hidden" name="exp_id" value="<?php echo $exp_id; ?>"> 
                      </div>
                      <div class="col-md-8 col-sm-6  form-group">
                          <label>المبلغ</label>
                    <input type="text" name="exp_amount" value="<?php echo $row['exp_amount']; ?>" class="form-control" id="inputSuccess2" placeholdeer="Expense Amount">
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                          <label>تاريخ الصرف</label>
                    <input type="text" name="exp_date" value="<?php echo $row['exp_date']; ?>" class="form-control" id="inputSuccess2">
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                          <label>طريقة الدفع</label>
                    <input type="text" name="exp_method" value="<?php echo $row['exp_method']; ?>"  class="form-control" id="inputSuccess2" placeholdeer="CR.No">
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                          <label>وذلك عن</label>
                    <input type="text" name="exp_about" value="<?php echo $row['exp_about']; ?>"  class="form-control" id="inputSuccess2" placeholdeer="City">
                      </div>
                       
                       <div class="col-md-12 col-sm-6  form-group">
                   <label>ملاحظات</label>
                           <textarea placeholdeer="Note" name="note" class="form-control" style="width:100%;height:100px"><?php echo $row['note']; ?></textarea>
                      </div>
                     <div class="form-group row">
                        <div class="col-md-9 col-sm-9  offset-md-4"><br>
                          <button style="width:30%" type="submit" name="submit" class="btn btn-success">إضافة</button>
                        </div>
                      </div>

                     
                  </div>
                </div>
 
              


              </div>
              
            </div>

            
           </form>  
                
                 <?php
                }
            
            } } else {}?>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
     

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>
    <!-- jQuery Tags Input -->
    <script src="../vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
    <!-- Switchery -->
    <script src="../vendors/switchery/dist/switchery.min.js"></script>
    <!-- Select2 -->
    <script src="../vendors/select2/dist/js/select2.full.min.js"></script>
    <!-- Parsley -->
    <script src="../vendors/parsleyjs/dist/parsley.min.js"></script>
    <!-- Autosize -->
    <script src="../vendors/autosize/dist/autosize.min.js"></script>
    <!-- jQuery autocomplete -->
    <script src="../vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
    <!-- starrr -->
    <script src="../vendors/starrr/dist/starrr.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
	
  </body>
</html>
