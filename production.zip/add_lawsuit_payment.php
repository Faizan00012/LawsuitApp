<?php
include_once 'header_file.php';
include_once 'connection.php';
$conn;
$id = $_GET['id'];
$conn = new mysqli($servername, $username, $password, $dbname);
$total_amount=0;
$paid=0;
$due=0;
$c_id=0;
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT l.c_id, con.led_id, con.led_paid, con.led_du, l.total_amount from lawsuit_ledger con INNER JOIN lawsuit l ON con.l_id=l.l_id where con.l_id=".$id;

//$sql = "SELECT led_id, led_paid, led_du from lawsuit_ledger where l_id=".$id;
 
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $c_id=$row["c_id"];
        $total_amount=$row["total_amount"];
        $paid=$paid+$row["led_paid"];
      }
} else {
   
}
            $due=$total_amount-$paid;
            ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  
    <title><?php 
                             if($_SESSION["lang_option"]=="en"){
                                echo "App New Payments";
                            }
                            else{
                                 echo "اضافة دفعة مالية جديدة";
                            }
                            ?></title>

    <!-- Bootstrap -->
    <?php
    if($_SESSION["lang_option"]=="en"){
        
           ?>
              <link rel="stylesheet" href="navcode1.css">
             <?php
    }
    else{
        
          ?>
              <link rel="stylesheet" href="navcode2.css">
             <?php
    }
    ?>
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  
      <div class="main_container">
        <?php include 'nav.php';  ?>

                
<?php if(isset($_POST['change_submit'])) {
      $_SESSION["lang_option"]=$_POST["langoption"];}

              if($_SESSION["lang_option"]=="en"){
                  ?>

                  
             <div dir="" style="width:100%" lang="ar" class="right_col" role="main">
 
            <div class="clearfix"></div>
            <form action="" method="post">
            <div class="col-md-12 ">
  <a href="lawsuit_profile.php?id=<?php echo $id; ?>" class="btn btn-dark btn-sm">Lawsuit Profile</a>
			 
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Add New Payment </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
                   <div class="col-md-4 col-sm-6  form-group">
                          <label><b>Total Amount:</b> <?php echo $total_amount; ?></label>
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                          <label><b>Paid Amount:</b> <?php echo $paid; ?></label>
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                          <label><b>Receivable (To be Paid By Customer) Amount: </b><?php echo $due; ?></label>
                      </div>
                      
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>Pay Amount</label>
                    <input type="text" name="pay_paid" class="form-control" id="total" placeholder="<?php echo $due; ?>">
                      </div>
                     
                      <div class="col-md-6 col-sm-6  form-group">
                           <label>That About</label>
                    <input type="text" name="pay_about" class="form-control" id="total" placeholder="">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                             <label>Payment Method</label>
                    <input type="text" name="pay_method" class="form-control" id="total" placeholder="">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                             <label>Date</label>
                    <input type="date" name="pay_date"  class="form-control" id="total" >
                      </div>
                   <div class="form-group row">
                        <div class="col-md-9 col-sm-9  offset-md-4"><br>
                          <button style="width:30%" type="submit" name="submit" class="btn btn-success">Add Payment</button>
                        </div>
                      </div>

                     
                  </div>
                </div>
 
              


          
              
            </div>
            </form> 
                
                

           
        </div> 
                   <?php
              }
                else
                {
                ?>
        <div dir="ltr" style="width:100%" lang="ar" class="right_col" role="main">
 
            <div class="clearfix"></div>
            <form style="font-size:20px;" action="" method="post">
            <div class="col-md-12 ">

			 <a style="float:right;font-size:20px;padding-left:20px;padding-right:20px;" href="lawsuit_profile.php?id=<?php echo $id; ?>" class="btn btn-dark btn-sm">القضايا</a>
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="float:right;font-size:24px;">اضافة دفعة مالية جديدة </h2>
                 
                    <div class="clearfix"></div>
                  </div>
                  <div dir="rtl" class="x_content">
                    <br />
                   <div class="col-md-4 col-sm-6  form-group">
                          <label dir="rtl"  style="float:right;"><b>المبلغ الإجمالي</b> <?php echo $total_amount; ?></label>
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                          <label dir="rtl"  style="float:right;"><b>المبلغ المدفوع:</b> <?php echo $paid; ?></label>
                      </div>
                      <div class="col-md-4 col-sm-6  form-group">
                          <label dir="rtl"  style="float:right;"><b>المبلغ الباقي </b><?php echo $due; ?></label>
                      </div>
                      
                        <div class="col-md-6 col-sm-6  form-group">
                           <label  dir="rtl"  style="float:right;">المبلغ</label>
                    <input type="text" name="pay_paid" class="form-control" id="total" placeholder="<?php echo $due; ?>">
                      </div>
                     
                      <div class="col-md-6 col-sm-6  form-group">
                           <label  dir="rtl"  style="float:right;">وذلك عن</label>
                    <input type="text" name="pay_about" class="form-control" id="total" placeholder="">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                              <label  dir="rtl"  style="float:right;">طريقة الدفع</label>
                    <input type="text" name="pay_method" class="form-control" id="total" placeholder="">
                      </div>
                      <div class="col-md-6 col-sm-6  form-group">
                             <label  dir="rtl"  style="float:right;">تاريخ الدفع</label>
                    <input type="date" name="pay_date"  class="form-control" id="total" >
                      </div>
                   <div class="form-group row">
                        <div class="col-md-9 col-sm-9  offset-md-4"><br>
                          <button style="width:30%" type="submit" name="submit" class="btn btn-success">اضافة دفعة مالية جديدة</button>
                        </div>
                      </div>

                     
                  </div>
                </div>
 
              


          
              
            </div>
            </form> 
                
                

           
        </div>   
                
                 <?php
                }
            
            ?>
                
                
              
      
        <script>
         
        </script>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
     

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>
    <!-- jQuery Tags Input -->
    <script src="../vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
    <!-- Switchery -->
    <script src="../vendors/switchery/dist/switchery.min.js"></script>
    <!-- Select2 -->
    <script src="../vendors/select2/dist/js/select2.full.min.js"></script>
    <!-- Parsley -->
    <script src="../vendors/parsleyjs/dist/parsley.min.js"></script>
    <!-- Autosize -->
    <script src="../vendors/autosize/dist/autosize.min.js"></script>
    <!-- jQuery autocomplete -->
    <script src="../vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
    <!-- starrr -->
    <script src="../vendors/starrr/dist/starrr.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
      </div>
  </body>
</html>
<?php
include_once 'connection.php';
$conn;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{
 $paid=$paid+$_POST["pay_paid"];
    $due=$total_amount-$paid;
   if ($paid>$total_amount){
       echo "<script>alert('Paid amount is greater then Total Amount');</script>";
   }
    else{
    $sql = "INSERT INTO lawsuit_ledger (l_id, led_paid, led_du, led_method, led_about,led_date) VALUES ('".$id."', '".$_POST["pay_paid"]."', '".$due."', '".$_POST["pay_method"]."', '".$_POST["pay_about"]."', '".$_POST["pay_date"]."')";
 echo $sql;
if ($conn->query($sql) === TRUE) {
  echo "New Payment Added";
}else{
	echo "New Payment Not Added";
}
        
             $sql = "UPDATE customer SET  paid=paid+".$_POST["pay_paid"].", due=due-".$_POST["pay_paid"]." WHERE c_id=".$c_id;
echo $sql;
if (mysqli_query($conn, $sql)) {
     
} else {
   
}

    }
   
}

$conn->close();
?>